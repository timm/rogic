%%%% OMO Support code
%%% Multis/2
%Fast, named, assertions
%<
multis(Stuff,All) :-
	bagof(One,Stuff^multi(Stuff,One),All).

multi((Heads :- Tail),(Head :- Tail)) :-
	d2l(Heads,List),
	member(Head,List).
%>
%%% Labels/3
%Very simple access scheme to terms with names args.
%<
defs(T,Defs) :- bagof(Def,T^defs1(T,Def),Defs).

defs1(T,(Access :- Get,Sub)) :-
	functor(T,  F,A),
	functor(Get,F,A),
	arg(N,T,Label : Type),
	arg(N,Get,X),
	Label =.. List0,
	append(List0,[X],List),
	Type =.. TypeList0,
	append(TypeList0,[X],TypeList),
	Access =.. List,
	Sub =.. TypeList.
%>
%%% Fields/3
%Poke some values into the named fields.
%<
fields(Fields,Functor,Term) :-
	fields1(Fields,Functor,Term),!.
fields(_,_,[]).

fields1([],_,_).
fields1([Field|Fields],Functor,Term) :-
	fields2(Field,Functor,Term),
	fields1(Fields,Functor,Term).

fields2(Field,Functor,Term) :-
	clause(Field,(Term,_)),
	functor(Term,Functor,_),!.
fields2(Field,Functor,_) :-
	barph(badField(Functor is [Field])).
%>
%%% w/2
%Convert scores to numeric weights
%<
w(A,W) :-
	s(A,S),
	postArch(A,S,W),
	num10(W).

postArch(A,S,W) :-
	cocomo(When),
	call(lookUp(postArch(When,_),A,S,W)).
%>
%%% Random types
%% Random strings
%<
rsym(X)  :- nonvar(X),!.
rsym(X)  :- gensym(g,X).

rsym(_,X)  :- nonvar(X),!.
rsym(A,X)  :- gensym(A,X).
%>
%% Random number within a range %<
rin(M,N,_,X) :- nonvar(X),!, number(X),M =< X, X =< N.
rin(M,N,O,X) :- Steps is integer((N-M)/O),
	        between(1,Steps,_),
		Y is random(Steps+1),
		X is min(M + Y*O,N).
%>
%% Random value of a list %<
%TODO: migrate random values into lib
rin(M,N,X) :- nonvar(X),!, number(X),M =< X, X =< N.
rin(M,N,X) :- Steps is integer(N-M),
	      between(1,Steps,_),
	      Y is random(Steps+1),
	      X is min(M + Y,N).

rin(X,L) :- number(X),!, member(Y,L), X =:= Y.
rin(X,L) :- nonvar(X),!, member(X,L).
rin(X,L) :- length(L,N), rmember1(L,N,X,_).

rone(X,Rest,L) :- length(L,N), rmember1(L,N,X,Rest).

rmember1([H],_,H,[])   :- !.
rmember1([H|T],N,X,Rest) :-
	Pos is random(N) + 1,
        lessN(Pos,Y,[H|T],L),
        ( X=Y,
	  Rest=L
        ; Rest=[Y|Rest1],
	  N1 is N - 1,
          rmember1(L,N1,X,Rest1)).

lessN(1,H,[H|T],T) :- !.
lessN(N0,X,[H|T],[H|L]) :-  N is N0 - 1, lessN(N,X,T,L).
						%>

