whatever(vlvh(_)).
whatever(lvh(_)).
whatever(vlxh(_)).
whatever(lxh(_)).
whatever(nxh(_)).

whatevered(fib(X,Y), fib(X), continuous, Y).
whatevered(s(X,Y),     s(X),   discrete, Y).
whatevered(cocomoP(Y), cocomoP,discrete, Y).
whatevered(oneOf(X,Y), oneOf(X),discrete,Y).

