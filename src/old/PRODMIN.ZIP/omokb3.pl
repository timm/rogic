%%%% Knowledge base
%%% Sample project %<

scores(_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_).
	
project is [label('eg#1')
           ,language(prolog)
           ,revl(10)
           ,newKsloc(100)
           ,adaptedKsloc(0)
           ,cm(0)     % new code
           ,dm(0)     % new code
           ,im(0)     % new code
           ,aa(2)     % basic module search + docu \cite[p24]{boehm00b}
           ,unfm(0.4) % somewhat familiar
           ,su(30)    % nominal value \cite[p23]{boehm00b}
           ,at(0)
           ,atKprod(2.4)
           ,scedPercent(100)
           ].

:- discontiguous(oneOf/2).
:- discontiguous(goal/2).
:- dynamic(goal/2).

term_expansion(iwants(L0),L) :-
	iws(L0,L).

iws(L,All) :- bagof(One,L^iw(L,One),All).

iw(L,Pred) :-
	member(X=Values,L),
	member(Value,Values),
	iw1(Value,X,Pred).

iw1(+Value,X,oneOf(X,Value)).
iw1(+Value,X,goal(X,Value)).
iw1(Value,X,oneOf(X,Value)) :- atomic(Value).

iwants(
[prec=[vl,l]
,flex=[+l,n,h,vh]
,arch=[vl,l, +n] 
,team=[l, +n]        
,pmat=[vl,l,n, +h]
,rely=[vh]      
,data=[n]       
,cplx=[vh,xh]   
,ruse=[l,n,+h] 
,docu=[l,n,+h]
,time=[n,h,vh]
,stor=[+n,h,vh]  
,pvol=[l]       
,acap=[l,+n]     
,pcap=[n]	
,pcon=[l,+n]     
,aexp=[l,n]     
,pexp=[n]       
,ltex=[l,n,+h]   
,tool=[l,n]     
,site=[n]       
,sced=[vl,l,+n]  
]).


%>
%%% LOC per Function points
/* Also loaded, but not shown due to size,
are tables showing producitivity in different 482 different
programming systems.
It tables a {\em lot} of code to get anything done in
binary, but less code as the language matures. So:

\begin{LISTING}
upf2sloc('1st generation default',320).
upf2sloc('2nd generation default',107).
upf2sloc('3rd generation default',80).
upf2sloc('4th generation default',20).
upf2sloc('5th generation default',5).
\end{LISTING}

The units here are lines of code per function point. For more details,
	see Boehm.
*/


