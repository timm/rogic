%%%%Pre-load actions
%%%Flags
%<
:- discontiguous def/3.
:- index(def(1,1,1)).
%>
%%%Hooks
/* Fast assertions of named variables. */
%<
term_expansion((X;Y :- Z),Out) :-
	multis(((X;Y) :- Z),Out).
%>
%Instantiate named fields
%<
term_expansion(Functor is Fields,Out) :-
	fields(Fields,Functor,Out).
%>
%Defined some numbered fields
%<
term_expansion(def(T),Defs) :- defs(T,Defs).
%>