:- forall(predicate_property(X,built_in),
	  ensure(knownBuiltIn(X)))x.