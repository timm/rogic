%%%%LURCH start-up actions
%<
builtIns:- 
    forall(predicate_property(X,built_in),
    ensure(knownBuiltIn(X))).

:- builtIns.

:- ensure(knownBuiltIn(!)).          % not sure why the above
:- ensure(knownBuiltIn(integer(_))). % dont do this automatically.

:- sneak(
        ['defaults.lurch' % see \fig{defaults.lurch}
        ,'config.lurch'   % see \fig{config.lurch}
        ]).

:- commandLine.
:- ?verbose -> hello ; true.
%>
