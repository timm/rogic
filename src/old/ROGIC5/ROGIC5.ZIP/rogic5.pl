:- [lib], 
   -[ops,xpand,run,wme,demos].
