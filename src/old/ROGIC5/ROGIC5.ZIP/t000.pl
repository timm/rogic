% simplest

range1(trust,[tim,dave]).

0*start if b.
1*b     if not c and d.
2*b     if c and a and e.
3*claim(2) if trust=dave.
