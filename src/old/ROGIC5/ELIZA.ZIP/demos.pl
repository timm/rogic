 demo(1) :-
 	th(t000),
 	forall(do([
                     %a=1,c=1],[start=1],W),
 		    d=1],[start=1],W),
 	
 	       show(W)).
