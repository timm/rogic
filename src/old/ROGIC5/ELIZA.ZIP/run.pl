 val(1).
 val(-1).
 
 neg(1, -1).
 neg(-1, 1).
 
 do(Context0,Goals,W) :-
 	context(Context0,_,W0), % 1. intialize working memory
 	                        % with the supplied context vars
 	do1(Goals,W0,W).        % 2. try and prove stuff
 
 % prove things in a random order
 do1([],W,W).
 do1(L,W0,W) :- pop(L,X=V,L1), do2(X=V,W0,W1), do1(L1,W1,W).
 
 % if provable, backtrack thru all methods
 do2(X=V,W0,W) :- bagof(W1,X^V^W0^q(X,V,W0,W1),Ws),!,member(W,Ws).
 % if not provable, just skip it (yes, this a hard-wired rors)
 do2(_,  W, W).
 
 % core query predicate
 q(X,New) -->
 	context(X,Old), % get the old value
 	% now set some control vars
 	{(var(Old) -> Var=new   ; Var=old), 
 	 (ab(X)    -> Todo=whatever; Todo=infer)
         },
 	q1(Var,Todo,X,Old,New).
 
 % helper predicate for q
 q1(old,_,        _,Old,Old,W, W).  % Old must match New  
 q1(new,infer,    X,New,New,W0,W) :-  p(X,New,W0,W). % work it out
 q1(new,whatever, _,New,New,W, W) :-  val(New). % whatever
 
 % pop a random item off a list
 pop([X],X,[]) :- !.
 pop([H|T],One,L) :-
 	length([H|T],N),
 	X is random(N)+1,
 	pop1(X,[H|T],One,L).
 
 pop1(1, [H|T],H,T) :- !.
 pop1(N0,[H|T0],X,[H|T]) :- N is N0 - 1, pop1(N,T0,X,T).
