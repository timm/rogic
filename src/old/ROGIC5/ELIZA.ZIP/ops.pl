 
 
 :- op(699,xfy,or).
 :- op(698,xfy,and).
 :- op(697, fy,not).
