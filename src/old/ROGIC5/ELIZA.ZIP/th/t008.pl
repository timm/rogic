% 60 or 40 % explicable

cc <- aa.
cc <- - bb.
ee <- cc.
ff <- cc.
dd <- cc.
gg <- zz.
zz <- dd.
hh <- dd.
ii <- dd.

[rx =  [[], [aa, bb]]
,ii = [10,       5]
,gg = [ 5,      10]
,hh = [ 5,      10]
,ee = [ 5,      10]
,ff = [10,       5]
].
