%ands + assumptions (with 1 explicable steady)'.

gg <- hh.  
gg <- - ii.
aa <- gg.  
bb <- gg.  
bb <- kk.  
jj <- aa.  
jj <- bb.  

[rx= [   [kk], [hh, ii]]
,jj= [    10,   10]
].