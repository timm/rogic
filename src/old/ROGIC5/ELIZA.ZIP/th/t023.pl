*wonderlust ++ gas.
*if no roadworks then gas +-+ mileage.

[rx=     [[],[wonderlust,roadworks],[wonderlust],[roadworks]]
,mileage=[10,                    20,          20,          5]
].