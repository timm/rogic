% can xplain dd, not bb
cc <- aa,kk,ll.
dd <- - cc.
dd <- ff.
bb <- dd.

[rx= [[],    [aa,ff]]
,bb= [10,      10]
,dd= [10,      10]
].