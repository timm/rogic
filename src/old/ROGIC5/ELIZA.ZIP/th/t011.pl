%'(generates 4 worlds, ignores 2)'

cc <- aa.  
cc <- - bb.
ee <- cc.  
ff <- cc.  
dd <- cc.  
gg <- dd.  
ll <- dd. 
jj <- hh. 
jj <- - ii.
gg <- jj. 
kk <- jj.

[rx = [   [], [aa,bb,hh,ii]]
,ee = [10,            5]
,kk = [10,            5]
,ff = [10,            5]
,gg = [10,           15]
,ll = [10,            5]
].