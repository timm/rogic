
bb <- aa.

[rx= [ [], [aa]]
,bb= [ 10,   5]
].