% simplest

0*start = b.
1*b     = not c and d.
2*b     = c and a and e.

