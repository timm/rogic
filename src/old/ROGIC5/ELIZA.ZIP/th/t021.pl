
*bucket ++ tank.
*if no switch then tank ++ spoutFlow.

[rx       =[[], [switch,bucket], [bucket], [switch]]
,spoutFlow=[10,              20,       20,       5]
].
