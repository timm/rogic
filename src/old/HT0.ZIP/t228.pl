*[a2c2u2t2Ed2e2x2,a2d2r2x2,c2h2r2o2n2i2Cd2e2x2
		,c2h2r2o2n2i2Cd2i2a2z2,c2h2r2o2n2i2Cg2l2u2c2o2s2e2,c2h2r2o2n2i2Ci2n2s2u2l2i2n2
		,c2h2r2o2n2i2Ct2o2l2b2u2t2,d2e2x2,d2i2a2z2
		,e2t2h2e2r2s2t2r2,g2e2n2t2l2e2,g2u2a2n2
		,h2g2h2In2j2,h2y2p2o2x2,i2n2s2u2l2i2n210
		,i2n2s2u2l2i2n230,i2n2s2u2l2i2n2Bo2l2i2s2,m2s2g2
		,p2a2r2g2,p2t2u2,s2t2r2e2s2s2
		,s2w2i2m2s2t2r2,t2o2l2b2u2t210,t2o2l2b2u2t220
		,t2o2l2b2u2t230,t2w2o2Dg2,y2o2h2
                ,a2c2t2h2,a2c2t2h2Pr2o2d2u2c2t2i2o2n2,a2l2u2m2i2n2i2u2m2,b2r2a2i2n2Gl2u2c2o2s2e2
		,b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2,c2a2t2e2c2h2o2l2e2,c2a2t2e2c2h2o2l2e2Di2s2p2
		,c2a2t2e2c2h2o2l2e2Pr2o2d2,c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2,c2o2r2t2i2s2o2l2
		,c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2,c2r2f2,d2a2
		,d2a22Hv2a2,d2a2Pr2o2d2u2c2t2i2o2n2,d2h2p2g2
		,f2i2v2e2HIAA,f2r2o2m2Gu2t2,f2r2o2m2Li2v2e2r2
		,f2r2o2m2Pa2n2c2r2e2a2s2,g2h2Pr2o2d2u2c2t2i2o2n2,g2h2r2h2
		,g2l2u2c2a2g2o2n2,g2l2u2c2a2g2o2n2Di2s2,g2l2u2c2a2g2o2n2Pr2o2d2
		,g2l2u2c2o2c2o2r2t2i2c2o2i2d2,g2l2u2c2o2s2e2,h2g2h2
		,h2v2a2,i2n2s2u2l2i2n2,n2e2
		,n2e22d2h2p2g2,n2e22Ep2i2n2,n2e2Co2n2t2r2o2l2
		,n2e2Pr2o2d2u2c2t2i2o2n2,p2Hg2h2,p2n2s2
		,p2Pr2l2,p2r2l2,p2r2l2Re2l2e2a2s2e2
		,s2a2t2e2i2t2y2,s2e2r2o2t2o2n2i2n2,s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2
		,s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA,s2n2s2,s2r2if
		,t24,t2e2m2p21,t2e2m2p22
		,t2e2m2p23,t2o2Ki2d2n2e2y2s2,t2o2Ti2s2s2u2e2
		,v2a2g2u2s2].
 

*c2r2f2  ++  a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*a2c2t2h2Pr2o2d2u2c2t2i2o2n2  +-+  a2c2t2h2.
*h2y2p2o2x2  --  a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*a2c2t2h2  ++  c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2.
*if no g2u2a2n2 then   s2n2s2  ++  c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2.
*if no a2d2r2x2 then c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2  +-+  c2o2r2t2i2s2o2l2.
*c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2  +--  c2o2r2t2i2s2o2l2.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2  --  a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2  +-+  g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*d2e2x2  ++  g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*a2c2u2t2Ed2e2x2  ++  g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*c2h2r2o2n2i2Cd2e2x2  ++  g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*if no a2d2r2x2 then c2a2t2e2c2h2o2l2e2Pr2o2d2  +-+  c2a2t2e2c2h2o2l2e2.
*c2a2t2e2c2h2o2l2e2Di2s2p2  +--  c2a2t2e2c2h2o2l2e2.
*if no g2u2a2n2 then s2n2s2  ++  c2a2t2e2c2h2o2l2e2Pr2o2d2.
*d2a2Pr2o2d2u2c2t2i2o2n2  +-+  d2a2.
*d2a22Hv2a2  +--  d2a2.
*p2r2l2  ++  d2a2.
*a2l2u2m2i2n2i2u2m2  --  d2a2Pr2o2d2u2c2t2i2o2n2.
*if no m2s2g2 then d2a22Hv2a2  +-+  h2v2a2.
*p2a2r2g2  --  d2a22Hv2a2.
*g2l2u2c2a2g2o2n2Pr2o2d2  +-+  g2l2u2c2a2g2o2n2.
*g2l2u2c2a2g2o2n2Di2s2  +--  g2l2u2c2a2g2o2n2.
*if no g2u2a2n2 then s2n2s2  ++  g2l2u2c2a2g2o2n2Pr2o2d2.
*g2l2u2c2o2s2e2  --  g2l2u2c2a2g2o2n2Pr2o2d2.
*i2n2s2u2l2i2n2  --  g2l2u2c2a2g2o2n2Pr2o2d2.
*c2h2r2o2n2i2Cg2l2u2c2o2s2e2  ++  g2l2u2c2o2s2e2.
*f2r2o2m2Gu2t2  +-+  g2l2u2c2o2s2e2.
*f2r2o2m2Li2v2e2r2  +-+  g2l2u2c2o2s2e2.
*b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2  +--  g2l2u2c2o2s2e2.
*g2l2u2c2o2s2e2  ++  b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2.
*t2o2Ti2s2s2u2e2  +--  g2l2u2c2o2s2e2.
*b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2  +-+  b2r2a2i2n2Gl2u2c2o2s2e2.
*t2e2m2p21  ++  t2o2Ti2s2s2u2e2.
*g2l2u2c2o2s2e2  ++  t2e2m2p21.
*i2n2s2u2l2i2n2  ++  t2e2m2p21.
*t2e2m2p22  ++  f2r2o2m2Li2v2e2r2.
*i2n2s2u2l2i2n2  --  t2e2m2p22.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2  ++  t2e2m2p22.
*p2n2s2  --  t2e2m2p22.
*c2a2t2e2c2h2o2l2e2  ++  t2e2m2p22.
*if no g2u2a2n2 then s2n2s2  --  t2e2m2p22.
*g2l2u2c2a2g2o2n2  ++  t2e2m2p22.
*t2w2o2Dg2  --  b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2.
*f2r2o2m2Pa2n2c2r2e2a2s2  +-+  i2n2s2u2l2i2n2.
*t2o2Ki2d2n2e2y2s2  +--  i2n2s2u2l2i2n2.
*i2n2s2u2l2i2n2  ++  t2o2Ki2d2n2e2y2s2.
*if g2u2a2n2 then  s2n2s2  --  t2e2m2p23.
*c2a2t2e2c2h2o2l2e2  --  t2e2m2p23.
*g2l2u2c2a2g2o2n2  ++  t2e2m2p23.
*g2l2u2c2o2s2e2  ++  t2e2m2p23.
*p2n2s2  ++  t2e2m2p23.
*t2e2m2p23  ++  f2r2o2m2Pa2n2c2r2e2a2s2.
*i2n2s2u2l2i2n2Bo2l2i2s2  ++  i2n2s2u2l2i2n2.
*i2n2s2u2l2i2n210  ++  i2n2s2u2l2i2n2.
*i2n2s2u2l2i2n230  ++  i2n2s2u2l2i2n2.
*c2h2r2o2n2i2Ci2n2s2u2l2i2n2  ++  i2n2s2u2l2i2n2.
*t2o2l2b2u2t210  ++  f2r2o2m2Pa2n2c2r2e2a2s2.
*t2o2l2b2u2t220  ++  f2r2o2m2Pa2n2c2r2e2a2s2.
*t2o2l2b2u2t230  ++  f2r2o2m2Pa2n2c2r2e2a2s2.
*c2h2r2o2n2i2Ct2o2l2b2u2t2  ++  f2r2o2m2Pa2n2c2r2e2a2s2.
*n2e2Pr2o2d2u2c2t2i2o2n2  +--  d2a2.
*if no m2s2g2 then n2e2Pr2o2d2u2c2t2i2o2n2  +-+  n2e2.
*n2e22d2h2p2g2  +--  n2e2.
*n2e22Ep2i2n2  +--  n2e2.
*if no m2s2g2 then   n2e22d2h2p2g2  +-+  d2h2p2g2.
*d2h2p2g2  ++  c2r2f2.
*d2h2p2g2  ++  s2n2s2.
*s2t2r2e2s2s2  ++  n2e2Co2n2t2r2o2l2.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2  --  n2e2Co2n2t2r2o2l2.
*b2r2a2i2n2Gl2u2c2o2s2e2  --  n2e2Co2n2t2r2o2l2.
*n2e2Co2n2t2r2o2l2  ++  n2e2Pr2o2d2u2c2t2i2o2n2.
*n2e2Co2n2t2r2o2l2  ++  n2e22d2h2p2g2.
*n2e2  ++  n2e22d2h2p2g2.
*a2l2u2m2i2n2i2u2m2  --  n2e22d2h2p2g2.
*n2e2  +-+  n2e22Ep2i2n2.
*h2g2h2  ++  n2e2Pr2o2d2u2c2t2i2o2n2.
*i2n2s2u2l2i2n2  --  n2e2Pr2o2d2u2c2t2i2o2n2.
*s2w2i2m2s2t2r2  ++  s2t2r2e2s2s2.
*e2t2h2e2r2s2t2r2  ++  s2t2r2e2s2s2.
*y2o2h2  ++  n2e2Pr2o2d2u2c2t2i2o2n2.
*p2a2r2g2  --  n2e22d2h2p2g2.
*g2e2n2t2l2e2  ++  s2t2r2e2s2s2.
*d2i2a2z2  --  n2e2Co2n2t2r2o2l2.
*c2h2r2o2n2i2Cd2i2a2z2  --  n2e2Co2n2t2r2o2l2.
*p2n2s2  ++  v2a2g2u2s2.
*i2n2s2u2l2i2n2  ++  p2n2s2.
*f2i2v2e2HIAA  ++  p2n2s2.
*s2n2s2  --  p2n2s2.
*d2a2  --  p2r2l2Re2l2e2a2s2e2.
*d2a2  --  p2Pr2l2.
*p2r2l2Re2l2e2a2s2e2  +--  p2Pr2l2.
*if no h2y2p2o2x2 then p2r2l2Re2l2e2a2s2e2  +-+  p2r2l2.
*f2i2v2e2HIAA  ++  s2a2t2e2i2t2y2.
*b2r2a2i2n2Gl2u2c2o2s2e2  --  s2a2t2e2i2t2y2.
*if no m2s2g2 then s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2  +-+  s2e2r2o2t2o2n2i2n2.
*s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA  +--  s2e2r2o2t2o2n2i2n2.
*s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA  +-+  f2i2v2e2HIAA.
*h2g2h2  --  s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*t24  --  s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*t24  ++  s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*s2e2r2o2t2o2n2i2n2  ++  s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*b2r2a2i2n2Gl2u2c2o2s2e2  ++  s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*i2n2s2u2l2i2n2  ++  s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*p2n2s2  ++  s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*p2n2s2  ++  s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*p2a2r2g2  --  s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*m2s2g2  --  s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*p2n2s2  --  s2n2s2.
*g2h2Pr2o2d2u2c2t2i2o2n2  +--  p2Hg2h2.
*if h2y2p2o2x2 then  g2h2Pr2o2d2u2c2t2i2o2n2  +-+  h2g2h2.
*h2g2h2In2j2  ++  h2g2h2.
*f2i2v2e2HIAA  ++  g2h2r2h2.
*g2h2r2h2  --  p2Hg2h2.
*g2h2r2h2  ++  g2h2Pr2o2d2u2c2t2i2o2n2.
*g2l2u2c2o2s2e2  ++  g2h2Pr2o2d2u2c2t2i2o2n2.
*g2l2u2c2o2s2e2  ++  p2Hg2h2.
*s2r2if  --  p2Hg2h2.
*s2r2if  --  g2h2Pr2o2d2u2c2t2i2o2n2.
*c2r2f2  ++  s2r2if.

*r2x2= [[], [m2s2g2], [d2i2a2z2], [g2u2a2n2], [p2a2r2g2], [h2y2p2o2x2], [t2w2o2Dg2], [a2c2u2t2Ed2e2x2],
 [g2e2n2t2l2e2],[c2h2r2o2n2i2Cd2e2x2], [s2w2i2m2s2t2r2 ], [  e2t2h2e2r2s2t2r2 ], [  p2t2u2,  y2o2h2 ], [  t2o2l2b2u2t210 ],
 [  t2o2l2b2u2t220 ], [  i2n2s2u2l2i2n210 ], [  i2n2s2u2l2i2n230 ], [  m2s2g2,  p2a2r2g2 ], [  c2h2r2o2n2i2Ct2o2l2b2u2t2 ], 
[  c2h2r2o2n2i2Cg2l2u2c2o2s2e2 ], [  c2h2r2o2n2i2Ci2n2s2u2l2i2n2 ], [  g2e2n2t2l2e2 , y2o2h2 ], [  g2u2a2n2 , t2w2o2Dg2 ],
 [p2t2u2 , s2w2i2m2s2t2r2 ], [  p2t2u2,  e2t2h2e2r2s2t2r2 ], [  d2i2a2z2,  c2h2r2o2n2i2Cd2i2a2z2 ], [  h2y2p2o2x2 , h2g2h2In2j2 ], 
[  a2c2u2t2Ed2e2x2 , s2w2i2m2s2t2r2 ], [c2h2r2o2n2i2Cd2e2x2 , s2w2i2m2s2t2r2 ], [  c2h2r2o2n2i2Cg2l2u2c2o2s2e2 , c2h2r2o2n2i2Ct2o2l2b2u2t2]].

*d2a2=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n2e2=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h2g2h2=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h2v2a2=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a2c2t2h2=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d2h2p2g2=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g2l2u2c2o2s2e2=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i2n2s2u2l2i2n2=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c2o2r2t2i2s2o2l2=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f2i2v2e2HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g2l2u2c2a2g2o2n2=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s2e2r2o2t2o2n2i2n2=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d2o2n2e2.
