*[a3c3u3t3Ed3e3x3,a3d3r3x3,c3h3r3o3n3i3Cd3e3x3
		,c3h3r3o3n3i3Cd3i3a3z3,c3h3r3o3n3i3Cg3l3u3c3o3s3e3,c3h3r3o3n3i3Ci3n3s3u3l3i3n3
		,c3h3r3o3n3i3Ct3o3l3b3u3t3,d3e3x3,d3i3a3z3
		,e3t3h3e3r3s3t3r3,g3e3n3t3l3e3,g3u3a3n3
		,h3g3h3In3j3,h3y3p3o3x3,i3n3s3u3l3i3n310
		,i3n3s3u3l3i3n330,i3n3s3u3l3i3n3Bo3l3i3s3,m3s3g3
		,p3a3r3g3,p3t3u3,s3t3r3e3s3s3
		,s3w3i3m3s3t3r3,t3o3l3b3u3t310,t3o3l3b3u3t320
		,t3o3l3b3u3t330,t3w3o3Dg3,y3o3h3
                ,a3c3t3h3,a3c3t3h3Pr3o3d3u3c3t3i3o3n3,a3l3u3m3i3n3i3u3m3,b3r3a3i3n3Gl3u3c3o3s3e3
		,b3r3a3i3n3Gl3u3c3o3s3e3Up3t3a3k3e3,c3a3t3e3c3h3o3l3e3,c3a3t3e3c3h3o3l3e3Di3s3p3
		,c3a3t3e3c3h3o3l3e3Pr3o3d3,c3o3r3t3i3c3o3i3d3Pr3o3d3u3c3t3i3o3n3,c3o3r3t3i3s3o3l3
		,c3o3r3t3i3s3o3l3Pr3o3d3u3c3t3i3o3n3,c3r3f3,d3a3
		,d3a32Hv3a3,d3a3Pr3o3d3u3c3t3i3o3n3,d3h3p3g3
		,f3i3v3e3HIAA,f3r3o3m3Gu3t3,f3r3o3m3Li3v3e3r3
		,f3r3o3m3Pa3n3c3r3e3a3s3,g3h3Pr3o3d3u3c3t3i3o3n3,g3h3r3h3
		,g3l3u3c3a3g3o3n3,g3l3u3c3a3g3o3n3Di3s3,g3l3u3c3a3g3o3n3Pr3o3d3
		,g3l3u3c3o3c3o3r3t3i3c3o3i3d3,g3l3u3c3o3s3e3,h3g3h3
		,h3v3a3,i3n3s3u3l3i3n3,n3e3
		,n3e32d3h3p3g3,n3e32Ep3i3n3,n3e3Co3n3t3r3o3l3
		,n3e3Pr3o3d3u3c3t3i3o3n3,p3Hg3h3,p3n3s3
		,p3Pr3l3,p3r3l3,p3r3l3Re3l3e3a3s3e3
		,s3a3t3e3i3t3y3,s3e3r3o3t3o3n3i3n3,s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3
		,s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA,s3n3s3,s3r3if
		,t34,t3e3m3p31,t3e3m3p32
		,t3e3m3p33,t3o3Ki3d3n3e3y3s3,t3o3Ti3s3s3u3e3
		,v3a3g3u3s3].
 

*c3r3f3  ++  a3c3t3h3Pr3o3d3u3c3t3i3o3n3.
*a3c3t3h3Pr3o3d3u3c3t3i3o3n3  +-+  a3c3t3h3.
*h3y3p3o3x3  --  a3c3t3h3Pr3o3d3u3c3t3i3o3n3.
*a3c3t3h3  ++  c3o3r3t3i3s3o3l3Pr3o3d3u3c3t3i3o3n3.
*if no g3u3a3n3 then   s3n3s3  ++  c3o3r3t3i3s3o3l3Pr3o3d3u3c3t3i3o3n3.
*if no a3d3r3x3 then c3o3r3t3i3s3o3l3Pr3o3d3u3c3t3i3o3n3  +-+  c3o3r3t3i3s3o3l3.
*c3o3r3t3i3c3o3i3d3Pr3o3d3u3c3t3i3o3n3  +--  c3o3r3t3i3s3o3l3.
*g3l3u3c3o3c3o3r3t3i3c3o3i3d3  --  a3c3t3h3Pr3o3d3u3c3t3i3o3n3.
*c3o3r3t3i3c3o3i3d3Pr3o3d3u3c3t3i3o3n3  +-+  g3l3u3c3o3c3o3r3t3i3c3o3i3d3.
*d3e3x3  ++  g3l3u3c3o3c3o3r3t3i3c3o3i3d3.
*a3c3u3t3Ed3e3x3  ++  g3l3u3c3o3c3o3r3t3i3c3o3i3d3.
*c3h3r3o3n3i3Cd3e3x3  ++  g3l3u3c3o3c3o3r3t3i3c3o3i3d3.
*if no a3d3r3x3 then c3a3t3e3c3h3o3l3e3Pr3o3d3  +-+  c3a3t3e3c3h3o3l3e3.
*c3a3t3e3c3h3o3l3e3Di3s3p3  +--  c3a3t3e3c3h3o3l3e3.
*if no g3u3a3n3 then s3n3s3  ++  c3a3t3e3c3h3o3l3e3Pr3o3d3.
*d3a3Pr3o3d3u3c3t3i3o3n3  +-+  d3a3.
*d3a32Hv3a3  +--  d3a3.
*p3r3l3  ++  d3a3.
*a3l3u3m3i3n3i3u3m3  --  d3a3Pr3o3d3u3c3t3i3o3n3.
*if no m3s3g3 then d3a32Hv3a3  +-+  h3v3a3.
*p3a3r3g3  --  d3a32Hv3a3.
*g3l3u3c3a3g3o3n3Pr3o3d3  +-+  g3l3u3c3a3g3o3n3.
*g3l3u3c3a3g3o3n3Di3s3  +--  g3l3u3c3a3g3o3n3.
*if no g3u3a3n3 then s3n3s3  ++  g3l3u3c3a3g3o3n3Pr3o3d3.
*g3l3u3c3o3s3e3  --  g3l3u3c3a3g3o3n3Pr3o3d3.
*i3n3s3u3l3i3n3  --  g3l3u3c3a3g3o3n3Pr3o3d3.
*c3h3r3o3n3i3Cg3l3u3c3o3s3e3  ++  g3l3u3c3o3s3e3.
*f3r3o3m3Gu3t3  +-+  g3l3u3c3o3s3e3.
*f3r3o3m3Li3v3e3r3  +-+  g3l3u3c3o3s3e3.
*b3r3a3i3n3Gl3u3c3o3s3e3Up3t3a3k3e3  +--  g3l3u3c3o3s3e3.
*g3l3u3c3o3s3e3  ++  b3r3a3i3n3Gl3u3c3o3s3e3Up3t3a3k3e3.
*t3o3Ti3s3s3u3e3  +--  g3l3u3c3o3s3e3.
*b3r3a3i3n3Gl3u3c3o3s3e3Up3t3a3k3e3  +-+  b3r3a3i3n3Gl3u3c3o3s3e3.
*t3e3m3p31  ++  t3o3Ti3s3s3u3e3.
*g3l3u3c3o3s3e3  ++  t3e3m3p31.
*i3n3s3u3l3i3n3  ++  t3e3m3p31.
*t3e3m3p32  ++  f3r3o3m3Li3v3e3r3.
*i3n3s3u3l3i3n3  --  t3e3m3p32.
*g3l3u3c3o3c3o3r3t3i3c3o3i3d3  ++  t3e3m3p32.
*p3n3s3  --  t3e3m3p32.
*c3a3t3e3c3h3o3l3e3  ++  t3e3m3p32.
*if no g3u3a3n3 then s3n3s3  --  t3e3m3p32.
*g3l3u3c3a3g3o3n3  ++  t3e3m3p32.
*t3w3o3Dg3  --  b3r3a3i3n3Gl3u3c3o3s3e3Up3t3a3k3e3.
*f3r3o3m3Pa3n3c3r3e3a3s3  +-+  i3n3s3u3l3i3n3.
*t3o3Ki3d3n3e3y3s3  +--  i3n3s3u3l3i3n3.
*i3n3s3u3l3i3n3  ++  t3o3Ki3d3n3e3y3s3.
*if g3u3a3n3 then  s3n3s3  --  t3e3m3p33.
*c3a3t3e3c3h3o3l3e3  --  t3e3m3p33.
*g3l3u3c3a3g3o3n3  ++  t3e3m3p33.
*g3l3u3c3o3s3e3  ++  t3e3m3p33.
*p3n3s3  ++  t3e3m3p33.
*t3e3m3p33  ++  f3r3o3m3Pa3n3c3r3e3a3s3.
*i3n3s3u3l3i3n3Bo3l3i3s3  ++  i3n3s3u3l3i3n3.
*i3n3s3u3l3i3n310  ++  i3n3s3u3l3i3n3.
*i3n3s3u3l3i3n330  ++  i3n3s3u3l3i3n3.
*c3h3r3o3n3i3Ci3n3s3u3l3i3n3  ++  i3n3s3u3l3i3n3.
*t3o3l3b3u3t310  ++  f3r3o3m3Pa3n3c3r3e3a3s3.
*t3o3l3b3u3t320  ++  f3r3o3m3Pa3n3c3r3e3a3s3.
*t3o3l3b3u3t330  ++  f3r3o3m3Pa3n3c3r3e3a3s3.
*c3h3r3o3n3i3Ct3o3l3b3u3t3  ++  f3r3o3m3Pa3n3c3r3e3a3s3.
*n3e3Pr3o3d3u3c3t3i3o3n3  +--  d3a3.
*if no m3s3g3 then n3e3Pr3o3d3u3c3t3i3o3n3  +-+  n3e3.
*n3e32d3h3p3g3  +--  n3e3.
*n3e32Ep3i3n3  +--  n3e3.
*if no m3s3g3 then   n3e32d3h3p3g3  +-+  d3h3p3g3.
*d3h3p3g3  ++  c3r3f3.
*d3h3p3g3  ++  s3n3s3.
*s3t3r3e3s3s3  ++  n3e3Co3n3t3r3o3l3.
*g3l3u3c3o3c3o3r3t3i3c3o3i3d3  --  n3e3Co3n3t3r3o3l3.
*b3r3a3i3n3Gl3u3c3o3s3e3  --  n3e3Co3n3t3r3o3l3.
*n3e3Co3n3t3r3o3l3  ++  n3e3Pr3o3d3u3c3t3i3o3n3.
*n3e3Co3n3t3r3o3l3  ++  n3e32d3h3p3g3.
*n3e3  ++  n3e32d3h3p3g3.
*a3l3u3m3i3n3i3u3m3  --  n3e32d3h3p3g3.
*n3e3  +-+  n3e32Ep3i3n3.
*h3g3h3  ++  n3e3Pr3o3d3u3c3t3i3o3n3.
*i3n3s3u3l3i3n3  --  n3e3Pr3o3d3u3c3t3i3o3n3.
*s3w3i3m3s3t3r3  ++  s3t3r3e3s3s3.
*e3t3h3e3r3s3t3r3  ++  s3t3r3e3s3s3.
*y3o3h3  ++  n3e3Pr3o3d3u3c3t3i3o3n3.
*p3a3r3g3  --  n3e32d3h3p3g3.
*g3e3n3t3l3e3  ++  s3t3r3e3s3s3.
*d3i3a3z3  --  n3e3Co3n3t3r3o3l3.
*c3h3r3o3n3i3Cd3i3a3z3  --  n3e3Co3n3t3r3o3l3.
*p3n3s3  ++  v3a3g3u3s3.
*i3n3s3u3l3i3n3  ++  p3n3s3.
*f3i3v3e3HIAA  ++  p3n3s3.
*s3n3s3  --  p3n3s3.
*d3a3  --  p3r3l3Re3l3e3a3s3e3.
*d3a3  --  p3Pr3l3.
*p3r3l3Re3l3e3a3s3e3  +--  p3Pr3l3.
*if no h3y3p3o3x3 then p3r3l3Re3l3e3a3s3e3  +-+  p3r3l3.
*f3i3v3e3HIAA  ++  s3a3t3e3i3t3y3.
*b3r3a3i3n3Gl3u3c3o3s3e3  --  s3a3t3e3i3t3y3.
*if no m3s3g3 then s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3  +-+  s3e3r3o3t3o3n3i3n3.
*s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA  +--  s3e3r3o3t3o3n3i3n3.
*s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA  +-+  f3i3v3e3HIAA.
*h3g3h3  --  s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3.
*t34  --  s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3.
*t34  ++  s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA.
*s3e3r3o3t3o3n3i3n3  ++  s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA.
*b3r3a3i3n3Gl3u3c3o3s3e3  ++  s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3.
*i3n3s3u3l3i3n3  ++  s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3.
*p3n3s3  ++  s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3.
*p3n3s3  ++  s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA.
*p3a3r3g3  --  s3e3r3o3t3o3n3i3n3TOf3i3v3e3HIAA.
*m3s3g3  --  s3e3r3o3t3o3n3i3n3Pr3o3d3u3c3t3i3o3n3.
*p3n3s3  --  s3n3s3.
*g3h3Pr3o3d3u3c3t3i3o3n3  +--  p3Hg3h3.
*if h3y3p3o3x3 then  g3h3Pr3o3d3u3c3t3i3o3n3  +-+  h3g3h3.
*h3g3h3In3j3  ++  h3g3h3.
*f3i3v3e3HIAA  ++  g3h3r3h3.
*g3h3r3h3  --  p3Hg3h3.
*g3h3r3h3  ++  g3h3Pr3o3d3u3c3t3i3o3n3.
*g3l3u3c3o3s3e3  ++  g3h3Pr3o3d3u3c3t3i3o3n3.
*g3l3u3c3o3s3e3  ++  p3Hg3h3.
*s3r3if  --  p3Hg3h3.
*s3r3if  --  g3h3Pr3o3d3u3c3t3i3o3n3.
*c3r3f3  ++  s3r3if.

*r3x3= [[], [m3s3g3], [d3i3a3z3], [g3u3a3n3], [p3a3r3g3], [h3y3p3o3x3], [t3w3o3Dg3], [a3c3u3t3Ed3e3x3],
 [g3e3n3t3l3e3],[c3h3r3o3n3i3Cd3e3x3], [s3w3i3m3s3t3r3 ], [  e3t3h3e3r3s3t3r3 ], [  p3t3u3,  y3o3h3 ], [  t3o3l3b3u3t310 ],
 [  t3o3l3b3u3t320 ], [  i3n3s3u3l3i3n310 ], [  i3n3s3u3l3i3n330 ], [  m3s3g3,  p3a3r3g3 ], [  c3h3r3o3n3i3Ct3o3l3b3u3t3 ], 
[  c3h3r3o3n3i3Cg3l3u3c3o3s3e3 ], [  c3h3r3o3n3i3Ci3n3s3u3l3i3n3 ], [  g3e3n3t3l3e3 , y3o3h3 ], [  g3u3a3n3 , t3w3o3Dg3 ],
 [p3t3u3 , s3w3i3m3s3t3r3 ], [  p3t3u3,  e3t3h3e3r3s3t3r3 ], [  d3i3a3z3,  c3h3r3o3n3i3Cd3i3a3z3 ], [  h3y3p3o3x3 , h3g3h3In3j3 ], 
[  a3c3u3t3Ed3e3x3 , s3w3i3m3s3t3r3 ], [c3h3r3o3n3i3Cd3e3x3 , s3w3i3m3s3t3r3 ], [  c3h3r3o3n3i3Cg3l3u3c3o3s3e3 , c3h3r3o3n3i3Ct3o3l3b3u3t3]].

*d3a3=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n3e3=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h3g3h3=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h3v3a3=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a3c3t3h3=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d3h3p3g3=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g3l3u3c3o3s3e3=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i3n3s3u3l3i3n3=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c3o3r3t3i3s3o3l3=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f3i3v3e3HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g3l3u3c3a3g3o3n3=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s3e3r3o3t3o3n3i3n3=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d3o3n3e3.
