%name = '6. x-shape with strings (1 of 3 inexplicable)'.

*[aa,mm,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk,ll,nn].

*aa ++ ll. 
*ll ++ bb.                             
*mm ++ nn. 
*nn ++ bb.                             
*bb ++ cc. 
*cc ++ dd. 
*dd ++ ee.                             
*bb ++ ff. 
*ff ++ gg. 
*gg ++ hh.
*bb ++ ii. 
*ii ++ jj. 
*jj ++ kk.

* rx= [[mm], [aa]].
* ee = [10,  15].
* hh = [10,  15].
* kk = [10,   5].

*done.

