%ands + assumptions (with 1 explicable steady)'.

*[ii,kk,hh,aa,bb,cc,dd,ee,ff,gg,hh,jj,xx].  %addit

*hh ++ gg .
*ii -- gg .
*gg ++ aa .
*gg ++ bb.
*kk ++ bb.
*aa ++ jj.
*bb ++ jj.

*rx= [   [kk], [hh, ii]].
*jj= [10,   10].

*done.