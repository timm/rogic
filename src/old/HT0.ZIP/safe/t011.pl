%'(generates 4 worlds, ignores 2)'
*[aa,bb,hh,ii,cc,dd,ee,ff,gg,jj,kk,ll].

*aa ++ cc .
*bb -- cc .
*cc ++ ee .
*cc ++ ff .
*cc ++ dd .
*dd ++ gg .
*dd ++ ll.
*hh ++ jj.
*ii -- jj.
*jj ++ gg.
*jj ++ kk.

*rx = [   [], [aa,bb,hh,ii]].
*ee = [10,            5].
*kk = [10,            5].
*ff = [10,            5].
*gg = [10,           15].
*ll = [10,            5].

*done.











