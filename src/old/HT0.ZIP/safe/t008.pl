% 60 or 40 % explicable
*[aa,bb,cc,dd,ee,ff,gg,hh,ii].

*aa ++ cc.
*bb -- cc.
*cc ++ ee.
*cc ++ ff.
*cc ++ dd.
*dd ++ gg.
*dd ++ hh.
*dd ++ ii.

*rx =  [[], [aa, bb]].
*ee = [ 5,      10].
*ff = [10,       5].
*gg = [ 5,      10].
*hh = [ 5,      10].
*ii = [10,       5].

*done.


