%name = '23. travel (disabler +-+)'.

*[wonderlust,roadworks,gas,mileage].

*wonderlust ++ gas.
*if no roadworks then gas +-+ mileage.

*rx=     [[],[wonderlust,roadworks],[wonderlust],[roadworks]].
*mileage=[10,                    20,          10,          5].

*done.