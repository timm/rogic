*[acutEdex, adrx, chroniCdex, chroniCdiaz, chroniCglucose, chroniCinsulin, chroniCtolbut, dex, diaz, etherstr, gentle, guan, hghInj, hypox, insulin10, insulin30, insulinBolis, msg, parg, ptu, stress, swimstr, tolbut10, tolbut20, tolbut30, twoDg, yoh, acth, acthProduction, aluminium, brainGlucose, brainGlucoseUptake, catechole, catecholeDisp, catecholeProd, corticoidProduction, cortisol, cortisolProduction, crf, da, da2Hva, daProduction, dhpg, fiveHIAA, fromGut, fromLiver, fromPancreas, ghProduction, ghrh, glucagon, glucagonDis, glucagonProd, glucocorticoid, glucose, hgh, hva, insulin, ne, ne2dhpg, ne2Epin, neControl, neProduction, pHgh, pns, pPrl, prl, prlRelease, sateity, serotonin, serotoninProduction, serotoninTOfiveHIAA, sns, srif, t4, temp1, temp2, temp3, toKidneys, toTissue, vagus, a9c9u9t9Ed9e9x9, a9d9r9x9, c9h9r9o9n9i9Cd9e9x9, c9h9r9o9n9i9Cd9i9a9z9, c9h9r9o9n9i9Cg9l9u9c9o9s9e9, c9h9r9o9n9i9Ci9n9s9u9l9i9n9, c9h9r9o9n9i9Ct9o9l9b9u9t9, d9e9x9, d9i9a9z9, e9t9h9e9r9s9t9r9, g9e9n9t9l9e9, g9u9a9n9, h9g9h9In9j9, h9y9p9o9x9, i9n9s9u9l9i9n910, i9n9s9u9l9i9n930, i9n9s9u9l9i9n9Bo9l9i9s9, m9s9g9, p9a9r9g9, p9t9u9, s9t9r9e9s9s9, s9w9i9m9s9t9r9, t9o9l9b9u9t910, t9o9l9b9u9t920, t9o9l9b9u9t930, t9w9o9Dg9, y9o9h9, a9c9t9h9, a9c9t9h9Pr9o9d9u9c9t9i9o9n9, a9l9u9m9i9n9i9u9m9, b9r9a9i9n9Gl9u9c9o9s9e9, b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9, c9a9t9e9c9h9o9l9e9, c9a9t9e9c9h9o9l9e9Di9s9p9, c9a9t9e9c9h9o9l9e9Pr9o9d9, c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9, c9o9r9t9i9s9o9l9, c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9, c9r9f9, d9a9, d9a92Hv9a9, d9a9Pr9o9d9u9c9t9i9o9n9, d9h9p9g9, f9i9v9e9HIAA, f9r9o9m9Gu9t9, f9r9o9m9Li9v9e9r9, f9r9o9m9Pa9n9c9r9e9a9s9, g9h9Pr9o9d9u9c9t9i9o9n9, g9h9r9h9, g9l9u9c9a9g9o9n9, g9l9u9c9a9g9o9n9Di9s9, g9l9u9c9a9g9o9n9Pr9o9d9, g9l9u9c9o9c9o9r9t9i9c9o9i9d9, g9l9u9c9o9s9e9, h9g9h9, h9v9a9, i9n9s9u9l9i9n9, n9e9, n9e92d9h9p9g9, n9e92Ep9i9n9, n9e9Co9n9t9r9o9l9, n9e9Pr9o9d9u9c9t9i9o9n9, p9Hg9h9, p9n9s9, p9Pr9l9, p9r9l9, p9r9l9Re9l9e9a9s9e9, s9a9t9e9i9t9y9, s9e9r9o9t9o9n9i9n9, s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9, s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA, s9n9s9, s9r9if, t94, t9e9m9p91, t9e9m9p92, t9e9m9p93, t9o9Ki9d9n9e9y9s9, t9o9Ti9s9s9u9e9, v9a9g9u9s9].
*rx=[[],[crf]].
*acth=[0,0].

*crf++acthProduction.
*acthProduction+-+acth.
*hypox--acthProduction.
*acth++cortisolProduction.
*if no guan then sns++cortisolProduction.
*if no adrx then cortisolProduction+-+cortisol.
*corticoidProduction+--cortisol.
*glucocorticoid--acthProduction.
*corticoidProduction+-+glucocorticoid.
*dex++glucocorticoid.
*acutEdex++glucocorticoid.
*chroniCdex++glucocorticoid.
*if no adrx then catecholeProd+-+catechole.
*catecholeDisp+--catechole.
*if no guan then sns++catecholeProd.
*daProduction+-+da.
*da2Hva+--da.
*prl++da.
*aluminium--daProduction.
*if no msg then da2Hva+-+hva.
*parg--da2Hva.
*glucagonProd+-+glucagon.
*glucagonDis+--glucagon.
*if no guan then sns++glucagonProd.
*glucose--glucagonProd.
*insulin--glucagonProd.
*chroniCglucose++glucose.
*fromGut+-+glucose.
*fromLiver+-+glucose.
*brainGlucoseUptake+--glucose.
*glucose++brainGlucoseUptake.
*toTissue+--glucose.
*brainGlucoseUptake+-+brainGlucose.
*temp1++toTissue.
*glucose++temp1.
*insulin++temp1.
*temp2++fromLiver.
*insulin--temp2.
*glucocorticoid++temp2.
*pns--temp2.
*catechole++temp2.
*if no guan then sns--temp2.
*glucagon++temp2.
*twoDg--brainGlucoseUptake.
*fromPancreas+-+insulin.
*toKidneys+--insulin.
*insulin++toKidneys.
*if guan then sns--temp3.
*catechole--temp3.
*glucagon++temp3.
*glucose++temp3.
*pns++temp3.
*temp3++fromPancreas.
*insulinBolis++insulin.
*insulin10++insulin.
*insulin30++insulin.
*chroniCinsulin++insulin.
*tolbut10++fromPancreas.
*tolbut20++fromPancreas.
*tolbut30++fromPancreas.
*chroniCtolbut++fromPancreas.
*neProduction+--da.
*if no msg then neProduction+-+ne.
*ne2dhpg+--ne.
*ne2Epin+--ne.
*if no msg then ne2dhpg+-+dhpg.
*dhpg++crf.
*dhpg++sns.
*stress++neControl.
*glucocorticoid--neControl.
*brainGlucose--neControl.
*neControl++neProduction.
*neControl++ne2dhpg.
*ne++ne2dhpg.
*aluminium--ne2dhpg.
*ne+-+ne2Epin.
*hgh++neProduction.
*insulin--neProduction.
*swimstr++stress.
*etherstr++stress.
*yoh++neProduction.
*parg--ne2dhpg.
*gentle++stress.
*diaz--neControl.
*chroniCdiaz--neControl.
*pns++vagus.
*insulin++pns.
*fiveHIAA++pns.
*sns--pns.
*da--prlRelease.
*da--pPrl.
*prlRelease+--pPrl.
*if no hypox then prlRelease+-+prl.
*fiveHIAA++sateity.
*brainGlucose--sateity.
*if no msg then serotoninProduction+-+serotonin.
*serotoninTOfiveHIAA+--serotonin.
*serotoninTOfiveHIAA+-+fiveHIAA.
*hgh--serotoninProduction.
*t4--serotoninProduction.
*t4++serotoninTOfiveHIAA.
*serotonin++serotoninTOfiveHIAA.
*brainGlucose++serotoninProduction.
*insulin++serotoninProduction.
*pns++serotoninProduction.
*pns++serotoninTOfiveHIAA.
*parg--serotoninTOfiveHIAA.
*msg--serotoninProduction.
*pns--sns.
*ghProduction+--pHgh.
*if hypox then ghProduction+-+hgh.
*hghInj++hgh.
*fiveHIAA++ghrh.
*ghrh--pHgh.
*ghrh++ghProduction.
*glucose++ghProduction.
*glucose++pHgh.
*srif--pHgh.
*srif--ghProduction.
*crf++srif.
*c9r9f9++a9c9t9h9Pr9o9d9u9c9t9i9o9n9.
*a9c9t9h9Pr9o9d9u9c9t9i9o9n9+-+a9c9t9h9.
*h9y9p9o9x9--a9c9t9h9Pr9o9d9u9c9t9i9o9n9.
*a9c9t9h9++c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9.
*if no g9u9a9n9 then s9n9s9++c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9.
*if no a9d9r9x9 then c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9+-+c9o9r9t9i9s9o9l9.
*c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9+--c9o9r9t9i9s9o9l9.
*g9l9u9c9o9c9o9r9t9i9c9o9i9d9--a9c9t9h9Pr9o9d9u9c9t9i9o9n9.
*c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9+-+g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*d9e9x9++g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*a9c9u9t9Ed9e9x9++g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*c9h9r9o9n9i9Cd9e9x9++g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*if no a9d9r9x9 then c9a9t9e9c9h9o9l9e9Pr9o9d9+-+c9a9t9e9c9h9o9l9e9.
*c9a9t9e9c9h9o9l9e9Di9s9p9+--c9a9t9e9c9h9o9l9e9.
*if no g9u9a9n9 then s9n9s9++c9a9t9e9c9h9o9l9e9Pr9o9d9.
*d9a9Pr9o9d9u9c9t9i9o9n9+-+d9a9.
*d9a92Hv9a9+--d9a9.
*p9r9l9++d9a9.
*a9l9u9m9i9n9i9u9m9--d9a9Pr9o9d9u9c9t9i9o9n9.
*if no m9s9g9 then d9a92Hv9a9+-+h9v9a9.
*p9a9r9g9--d9a92Hv9a9.
*g9l9u9c9a9g9o9n9Pr9o9d9+-+g9l9u9c9a9g9o9n9.
*g9l9u9c9a9g9o9n9Di9s9+--g9l9u9c9a9g9o9n9.
*if no g9u9a9n9 then s9n9s9++g9l9u9c9a9g9o9n9Pr9o9d9.
*g9l9u9c9o9s9e9--g9l9u9c9a9g9o9n9Pr9o9d9.
*i9n9s9u9l9i9n9--g9l9u9c9a9g9o9n9Pr9o9d9.
*c9h9r9o9n9i9Cg9l9u9c9o9s9e9++g9l9u9c9o9s9e9.
*f9r9o9m9Gu9t9+-+g9l9u9c9o9s9e9.
*f9r9o9m9Li9v9e9r9+-+g9l9u9c9o9s9e9.
*b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9+--g9l9u9c9o9s9e9.
*g9l9u9c9o9s9e9++b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9.
*t9o9Ti9s9s9u9e9+--g9l9u9c9o9s9e9.
*b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9+-+b9r9a9i9n9Gl9u9c9o9s9e9.
*t9e9m9p91++t9o9Ti9s9s9u9e9.
*g9l9u9c9o9s9e9++t9e9m9p91.
*i9n9s9u9l9i9n9++t9e9m9p91.
*t9e9m9p92++f9r9o9m9Li9v9e9r9.
*i9n9s9u9l9i9n9--t9e9m9p92.
*g9l9u9c9o9c9o9r9t9i9c9o9i9d9++t9e9m9p92.
*p9n9s9--t9e9m9p92.
*c9a9t9e9c9h9o9l9e9++t9e9m9p92.
*if no g9u9a9n9 then s9n9s9--t9e9m9p92.
*g9l9u9c9a9g9o9n9++t9e9m9p92.
*t9w9o9Dg9--b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9.
*f9r9o9m9Pa9n9c9r9e9a9s9+-+i9n9s9u9l9i9n9.
*t9o9Ki9d9n9e9y9s9+--i9n9s9u9l9i9n9.
*i9n9s9u9l9i9n9++t9o9Ki9d9n9e9y9s9.
*if g9u9a9n9 then s9n9s9--t9e9m9p93.
*c9a9t9e9c9h9o9l9e9--t9e9m9p93.
*g9l9u9c9a9g9o9n9++t9e9m9p93.
*g9l9u9c9o9s9e9++t9e9m9p93.
*p9n9s9++t9e9m9p93.
*t9e9m9p93++f9r9o9m9Pa9n9c9r9e9a9s9.
*i9n9s9u9l9i9n9Bo9l9i9s9++i9n9s9u9l9i9n9.
*i9n9s9u9l9i9n910++i9n9s9u9l9i9n9.
*i9n9s9u9l9i9n930++i9n9s9u9l9i9n9.
*c9h9r9o9n9i9Ci9n9s9u9l9i9n9++i9n9s9u9l9i9n9.
*t9o9l9b9u9t910++f9r9o9m9Pa9n9c9r9e9a9s9.
*t9o9l9b9u9t920++f9r9o9m9Pa9n9c9r9e9a9s9.
*t9o9l9b9u9t930++f9r9o9m9Pa9n9c9r9e9a9s9.
*c9h9r9o9n9i9Ct9o9l9b9u9t9++f9r9o9m9Pa9n9c9r9e9a9s9.
*n9e9Pr9o9d9u9c9t9i9o9n9+--d9a9.
*if no m9s9g9 then n9e9Pr9o9d9u9c9t9i9o9n9+-+n9e9.
*n9e92d9h9p9g9+--n9e9.
*n9e92Ep9i9n9+--n9e9.
*if no m9s9g9 then n9e92d9h9p9g9+-+d9h9p9g9.
*d9h9p9g9++c9r9f9.
*d9h9p9g9++s9n9s9.
*s9t9r9e9s9s9++n9e9Co9n9t9r9o9l9.
*g9l9u9c9o9c9o9r9t9i9c9o9i9d9--n9e9Co9n9t9r9o9l9.
*b9r9a9i9n9Gl9u9c9o9s9e9--n9e9Co9n9t9r9o9l9.
*n9e9Co9n9t9r9o9l9++n9e9Pr9o9d9u9c9t9i9o9n9.
*n9e9Co9n9t9r9o9l9++n9e92d9h9p9g9.
*n9e9++n9e92d9h9p9g9.
*a9l9u9m9i9n9i9u9m9--n9e92d9h9p9g9.
*n9e9+-+n9e92Ep9i9n9.
*h9g9h9++n9e9Pr9o9d9u9c9t9i9o9n9.
*i9n9s9u9l9i9n9--n9e9Pr9o9d9u9c9t9i9o9n9.
*s9w9i9m9s9t9r9++s9t9r9e9s9s9.
*e9t9h9e9r9s9t9r9++s9t9r9e9s9s9.
*y9o9h9++n9e9Pr9o9d9u9c9t9i9o9n9.
*p9a9r9g9--n9e92d9h9p9g9.
*g9e9n9t9l9e9++s9t9r9e9s9s9.
*d9i9a9z9--n9e9Co9n9t9r9o9l9.
*c9h9r9o9n9i9Cd9i9a9z9--n9e9Co9n9t9r9o9l9.
*p9n9s9++v9a9g9u9s9.
*i9n9s9u9l9i9n9++p9n9s9.
*f9i9v9e9HIAA++p9n9s9.
*s9n9s9--p9n9s9.
*d9a9--p9r9l9Re9l9e9a9s9e9.
*d9a9--p9Pr9l9.
*p9r9l9Re9l9e9a9s9e9+--p9Pr9l9.
*if no h9y9p9o9x9 then p9r9l9Re9l9e9a9s9e9+-+p9r9l9.
*f9i9v9e9HIAA++s9a9t9e9i9t9y9.
*b9r9a9i9n9Gl9u9c9o9s9e9--s9a9t9e9i9t9y9.
*if no m9s9g9 then s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9+-+s9e9r9o9t9o9n9i9n9.
*s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA+--s9e9r9o9t9o9n9i9n9.
*s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA+-+f9i9v9e9HIAA.
*h9g9h9--s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*t94--s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*t94++s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*s9e9r9o9t9o9n9i9n9++s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*b9r9a9i9n9Gl9u9c9o9s9e9++s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*i9n9s9u9l9i9n9++s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*p9n9s9++s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*p9n9s9++s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*p9a9r9g9--s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*m9s9g9--s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*p9n9s9--s9n9s9.
*g9h9Pr9o9d9u9c9t9i9o9n9+--p9Hg9h9.
*if h9y9p9o9x9 then g9h9Pr9o9d9u9c9t9i9o9n9+-+h9g9h9.
*h9g9h9In9j9++h9g9h9.
*f9i9v9e9HIAA++g9h9r9h9.
*g9h9r9h9--p9Hg9h9.
*g9h9r9h9++g9h9Pr9o9d9u9c9t9i9o9n9.
*g9l9u9c9o9s9e9++g9h9Pr9o9d9u9c9t9i9o9n9.
*g9l9u9c9o9s9e9++p9Hg9h9.
*s9r9if--p9Hg9h9.
*s9r9if--g9h9Pr9o9d9u9c9t9i9o9n9.
*c9r9f9++s9r9if.
*fromLiver--+c9r9f9.
*serotoninTOfiveHIAA--a9d9r9x9.
*ghrh--b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9.
*catechole++d9a9.
*msg+--d9h9p9g9.
*chroniCtolbut++b9r9a9i9n9Gl9u9c9o9s9e9.
*toKidneys--+s9n9s9.
*prl--+f9r9o9m9Li9v9e9r9.
*serotoninProduction--+g9u9a9n9.
*ne---n9e92d9h9p9g9.
*h9g9h9In9j9--+ne2Epin.
*i9n9s9u9l9i9n9+--insulin10.
*g9l9u9c9a9g9o9n9Di9s9--+glucagon.
*g9l9u9c9o9s9e9+--dex.
*a9d9r9x9--crf.
*f9r9o9m9Gu9t9--+aluminium.
*s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA--+ne.
*h9g9h9--pPrl.
*t9o9Ki9d9n9e9y9s9--+chroniCtolbut.
*s9t9r9e9s9s9---swimstr.
*if serotoninProduction then a9c9t9h9--+s9e9r9o9t9o9n9i9n9.
*if adrx then e9t9h9e9r9s9t9r9--f9i9v9e9HIAA.
*if chroniCdex then c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9--+c9h9r9o9n9i9Cg9l9u9c9o9s9e9.
*if f9r9o9m9Li9v9e9r9 then chroniCtolbut+--ne2dhpg.
*if s9a9t9e9i9t9y9 then insulinBolis--+daProduction.
*if a9d9r9x9 then glucagonProd++da2Hva.
*done.
