*[switch,rats,power,light].

*switch  ++  power.
*if no rats then power ++ light.

*rx = [  [], [switch,rats], [rats], [switch]].
*power = [10,            17,     15,      25].
*light = [11,            18,     15,      25].

*done.

