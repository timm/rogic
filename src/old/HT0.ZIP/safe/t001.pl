*[aa,bb].

*aa ++ bb.

*rx= [ [], [aa]].
*bb= [  5,   10].

*done.