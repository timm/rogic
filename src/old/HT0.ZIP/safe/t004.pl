% can xplain dd, not bb
*[aa,ff,bb,cc,dd].

*aa ++ cc.
*cc -- dd.
*ff ++ dd.
*dd ++ bb.

*rx= [[], [aa,ff]].
*bb= [10,      10].
*dd= [10,      10].

*done.

