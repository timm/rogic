*[aa,bb,cc].

*aa ++ cc.
*bb ++ cc.

*rx= [[aa],   [bb]].
*cc= [  10,    10 ].

*done.