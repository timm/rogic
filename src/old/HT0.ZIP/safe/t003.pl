% everything inexplicable
*[aa,bb].

*aa ++ bb.

*rx= [ [], [aa]].
*bb= [ 10,   5].

*done.