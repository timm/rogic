*[aacauataEdaeaxa,aadaraxa,caharaoanaiaCdaeaxa
		,caharaoanaiaCdaiaaaza,caharaoanaiaCgalauacaoasaea,caharaoanaiaCianasaualaiana
		,caharaoanaiaCtaoalabauata,daeaxa,daiaaaza
		,eatahaearasatara,gaeanatalaea,gauaaana
		,hagahaInaja,hayapaoaxa,ianasaualaiana10
		,ianasaualaiana30,ianasaualaianaBoalaiasa,masaga
		,paaaraga,pataua,sataraeasasa
		,sawaiamasatara,taoalabauata10,taoalabauata20
		,taoalabauata30,tawaoaDga,yaoaha
                ,aacataha,aacatahaPraoadauacataiaoana,aalauamaianaiauama,baraaaianaGlauacaoasaea
		,baraaaianaGlauacaoasaeaUpataaakaea,caaataeacahaoalaea,caaataeacahaoalaeaDiasapa
		,caaataeacahaoalaeaPraoada,caoarataiacaoaiadaPraoadauacataiaoana,caoarataiasaoala
		,caoarataiasaoalaPraoadauacataiaoana,carafa,daaa
		,daaa2Hvaaa,daaaPraoadauacataiaoana,dahapaga
		,faiavaeaHIAA,faraoamaGuata,faraoamaLiavaeara
		,faraoamaPaanacaraeaaasa,gahaPraoadauacataiaoana,gaharaha
		,galauacaaagaoana,galauacaaagaoanaDiasa,galauacaaagaoanaPraoada
		,galauacaoacaoarataiacaoaiada,galauacaoasaea,hagaha
		,havaaa,ianasaualaiana,naea
		,naea2dahapaga,naea2Epaiana,naeaCoanataraoala
		,naeaPraoadauacataiaoana,paHgaha,panasa
		,paPrala,parala,paralaRealaeaaasaea
		,saaataeaiataya,saearaoataoanaiana,saearaoataoanaianaPraoadauacataiaoana
		,saearaoataoanaianaTOfaiavaeaHIAA,sanasa,saraiafa
		,ta4,taeamapa1,taeamapa2
		,taeamapa3,taoaKiadanaeayasa,taoaTiasasauaea
		,vaaagauasa].
 

*carafa  ++  aacatahaPraoadauacataiaoana.
*aacatahaPraoadauacataiaoana  +-+  aacataha.
*hayapaoaxa  --  aacatahaPraoadauacataiaoana.
*aacataha  ++  caoarataiasaoalaPraoadauacataiaoana.
*iafa naoa gauaaana tahaeana   sanasa  ++  caoarataiasaoalaPraoadauacataiaoana.
*iafa naoa aadaraxa tahaeana caoarataiasaoalaPraoadauacataiaoana  +-+  caoarataiasaoala.
*caoarataiacaoaiadaPraoadauacataiaoana  +--  caoarataiasaoala.
*galauacaoacaoarataiacaoaiada  --  aacatahaPraoadauacataiaoana.
*caoarataiacaoaiadaPraoadauacataiaoana  +-+  galauacaoacaoarataiacaoaiada.
*daeaxa  ++  galauacaoacaoarataiacaoaiada.
*aacauataEdaeaxa  ++  galauacaoacaoarataiacaoaiada.
*caharaoanaiaCdaeaxa  ++  galauacaoacaoarataiacaoaiada.
*iafa naoa aadaraxa tahaeana caaataeacahaoalaeaPraoada  +-+  caaataeacahaoalaea.
*caaataeacahaoalaeaDiasapa  +--  caaataeacahaoalaea.
*iafa naoa gauaaana tahaeana sanasa  ++  caaataeacahaoalaeaPraoada.
*daaaPraoadauacataiaoana  +-+  daaa.
*daaa2Hvaaa  +--  daaa.
*parala  ++  daaa.
*aalauamaianaiauama  --  daaaPraoadauacataiaoana.
*iafa naoa masaga tahaeana daaa2Hvaaa  +-+  havaaa.
*paaaraga  --  daaa2Hvaaa.
*galauacaaagaoanaPraoada  +-+  galauacaaagaoana.
*galauacaaagaoanaDiasa  +--  galauacaaagaoana.
*iafa naoa gauaaana tahaeana sanasa  ++  galauacaaagaoanaPraoada.
*galauacaoasaea  --  galauacaaagaoanaPraoada.
*ianasaualaiana  --  galauacaaagaoanaPraoada.
*caharaoanaiaCgalauacaoasaea  ++  galauacaoasaea.
*faraoamaGuata  +-+  galauacaoasaea.
*faraoamaLiavaeara  +-+  galauacaoasaea.
*baraaaianaGlauacaoasaeaUpataaakaea  +--  galauacaoasaea.
*galauacaoasaea  ++  baraaaianaGlauacaoasaeaUpataaakaea.
*taoaTiasasauaea  +--  galauacaoasaea.
*baraaaianaGlauacaoasaeaUpataaakaea  +-+  baraaaianaGlauacaoasaea.
*taeamapa1  ++  taoaTiasasauaea.
*galauacaoasaea  ++  taeamapa1.
*ianasaualaiana  ++  taeamapa1.
*taeamapa2  ++  faraoamaLiavaeara.
*ianasaualaiana  --  taeamapa2.
*galauacaoacaoarataiacaoaiada  ++  taeamapa2.
*panasa  --  taeamapa2.
*caaataeacahaoalaea  ++  taeamapa2.
*iafa naoa gauaaana tahaeana sanasa  --  taeamapa2.
*galauacaaagaoana  ++  taeamapa2.
*tawaoaDga  --  baraaaianaGlauacaoasaeaUpataaakaea.
*faraoamaPaanacaraeaaasa  +-+  ianasaualaiana.
*taoaKiadanaeayasa  +--  ianasaualaiana.
*ianasaualaiana  ++  taoaKiadanaeayasa.
*iafa gauaaana tahaeana  sanasa  --  taeamapa3.
*caaataeacahaoalaea  --  taeamapa3.
*galauacaaagaoana  ++  taeamapa3.
*galauacaoasaea  ++  taeamapa3.
*panasa  ++  taeamapa3.
*taeamapa3  ++  faraoamaPaanacaraeaaasa.
*ianasaualaianaBoalaiasa  ++  ianasaualaiana.
*ianasaualaiana10  ++  ianasaualaiana.
*ianasaualaiana30  ++  ianasaualaiana.
*caharaoanaiaCianasaualaiana  ++  ianasaualaiana.
*taoalabauata10  ++  faraoamaPaanacaraeaaasa.
*taoalabauata20  ++  faraoamaPaanacaraeaaasa.
*taoalabauata30  ++  faraoamaPaanacaraeaaasa.
*caharaoanaiaCtaoalabauata  ++  faraoamaPaanacaraeaaasa.
*naeaPraoadauacataiaoana  +--  daaa.
*iafa naoa masaga tahaeana naeaPraoadauacataiaoana  +-+  naea.
*naea2dahapaga  +--  naea.
*naea2Epaiana  +--  naea.
*iafa naoa masaga tahaeana   naea2dahapaga  +-+  dahapaga.
*dahapaga  ++  carafa.
*dahapaga  ++  sanasa.
*sataraeasasa  ++  naeaCoanataraoala.
*galauacaoacaoarataiacaoaiada  --  naeaCoanataraoala.
*baraaaianaGlauacaoasaea  --  naeaCoanataraoala.
*naeaCoanataraoala  ++  naeaPraoadauacataiaoana.
*naeaCoanataraoala  ++  naea2dahapaga.
*naea  ++  naea2dahapaga.
*aalauamaianaiauama  --  naea2dahapaga.
*naea  +-+  naea2Epaiana.
*hagaha  ++  naeaPraoadauacataiaoana.
*ianasaualaiana  --  naeaPraoadauacataiaoana.
*sawaiamasatara  ++  sataraeasasa.
*eatahaearasatara  ++  sataraeasasa.
*yaoaha  ++  naeaPraoadauacataiaoana.
*paaaraga  --  naea2dahapaga.
*gaeanatalaea  ++  sataraeasasa.
*daiaaaza  --  naeaCoanataraoala.
*caharaoanaiaCdaiaaaza  --  naeaCoanataraoala.
*panasa  ++  vaaagauasa.
*ianasaualaiana  ++  panasa.
*faiavaeaHIAA  ++  panasa.
*sanasa  --  panasa.
*daaa  --  paralaRealaeaaasaea.
*daaa  --  paPrala.
*paralaRealaeaaasaea  +--  paPrala.
*iafa naoa hayapaoaxa tahaeana paralaRealaeaaasaea  +-+  parala.
*faiavaeaHIAA  ++  saaataeaiataya.
*baraaaianaGlauacaoasaea  --  saaataeaiataya.
*iafa naoa masaga tahaeana saearaoataoanaianaPraoadauacataiaoana  +-+  saearaoataoanaiana.
*saearaoataoanaianaTOfaiavaeaHIAA  +--  saearaoataoanaiana.
*saearaoataoanaianaTOfaiavaeaHIAA  +-+  faiavaeaHIAA.
*hagaha  --  saearaoataoanaianaPraoadauacataiaoana.
*ta4  --  saearaoataoanaianaPraoadauacataiaoana.
*ta4  ++  saearaoataoanaianaTOfaiavaeaHIAA.
*saearaoataoanaiana  ++  saearaoataoanaianaTOfaiavaeaHIAA.
*baraaaianaGlauacaoasaea  ++  saearaoataoanaianaPraoadauacataiaoana.
*ianasaualaiana  ++  saearaoataoanaianaPraoadauacataiaoana.
*panasa  ++  saearaoataoanaianaPraoadauacataiaoana.
*panasa  ++  saearaoataoanaianaTOfaiavaeaHIAA.
*paaaraga  --  saearaoataoanaianaTOfaiavaeaHIAA.
*masaga  --  saearaoataoanaianaPraoadauacataiaoana.
*panasa  --  sanasa.
*gahaPraoadauacataiaoana  +--  paHgaha.
*iafa hayapaoaxa tahaeana  gahaPraoadauacataiaoana  +-+  hagaha.
*hagahaInaja  ++  hagaha.
*faiavaeaHIAA  ++  gaharaha.
*gaharaha  --  paHgaha.
*gaharaha  ++  gahaPraoadauacataiaoana.
*galauacaoasaea  ++  gahaPraoadauacataiaoana.
*galauacaoasaea  ++  paHgaha.
*saraiafa  --  paHgaha.
*saraiafa  --  gahaPraoadauacataiaoana.
*carafa  ++  saraiafa.

*raxa= [[], [masaga], [daiaaaza], [gauaaana], [paaaraga], [hayapaoaxa], [tawaoaDga], [aacauataEdaeaxa],
 [gaeanatalaea],[caharaoanaiaCdaeaxa], [sawaiamasatara ], [  eatahaearasatara ], [  pataua,  yaoaha ], [  taoalabauata10 ],
 [  taoalabauata20 ], [  ianasaualaiana10 ], [  ianasaualaiana30 ], [  masaga,  paaaraga ], [  caharaoanaiaCtaoalabauata ], 
[  caharaoanaiaCgalauacaoasaea ], [  caharaoanaiaCianasaualaiana ], [  gaeanatalaea , yaoaha ], [  gauaaana , tawaoaDga ],
 [pataua , sawaiamasatara ], [  pataua,  eatahaearasatara ], [  daiaaaza,  caharaoanaiaCdaiaaaza ], [  hayapaoaxa , hagahaInaja ], 
[  aacauataEdaeaxa , sawaiamasatara ], [caharaoanaiaCdaeaxa , sawaiamasatara ], [  caharaoanaiaCgalauacaoasaea , caharaoanaiaCtaoalabauata]].

*daaa=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*naea=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*hagaha=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*havaaa=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*aacataha=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*dahapaga=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*galauacaoasaea=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*ianasaualaiana=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*caoarataiasaoala=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*faiavaeaHIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*galauacaaagaoana=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*saearaoataoanaiana=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*daoanaea.
