*[a1c1u1t1Ed1e1x1,a1d1r1x1,c1h1r1o1n1i1Cd1e1x1
		,c1h1r1o1n1i1Cd1i1a1z1,c1h1r1o1n1i1Cg1l1u1c1o1s1e1,c1h1r1o1n1i1Ci1n1s1u1l1i1n1
		,c1h1r1o1n1i1Ct1o1l1b1u1t1,d1e1x1,d1i1a1z1
		,e1t1h1e1r1s1t1r1,g1e1n1t1l1e1,g1u1a1n1
		,h1g1h1In1j1,h1y1p1o1x1,i1n1s1u1l1i1n110
		,i1n1s1u1l1i1n130,i1n1s1u1l1i1n1Bo1l1i1s1,m1s1g1
		,p1a1r1g1,p1t1u1,s1t1r1e1s1s1
		,s1w1i1m1s1t1r1,t1o1l1b1u1t110,t1o1l1b1u1t120
		,t1o1l1b1u1t130,t1w1o1Dg1,y1o1h1
                ,a1c1t1h1,a1c1t1h1Pr1o1d1u1c1t1i1o1n1,a1l1u1m1i1n1i1u1m1,b1r1a1i1n1Gl1u1c1o1s1e1
		,b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1,c1a1t1e1c1h1o1l1e1,c1a1t1e1c1h1o1l1e1Di1s1p1
		,c1a1t1e1c1h1o1l1e1Pr1o1d1,c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1,c1o1r1t1i1s1o1l1
		,c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1,c1r1f1,d1a1
		,d1a12Hv1a1,d1a1Pr1o1d1u1c1t1i1o1n1,d1h1p1g1
		,f1i1v1e1HIAA,f1r1o1m1Gu1t1,f1r1o1m1Li1v1e1r1
		,f1r1o1m1Pa1n1c1r1e1a1s1,g1h1Pr1o1d1u1c1t1i1o1n1,g1h1r1h1
		,g1l1u1c1a1g1o1n1,g1l1u1c1a1g1o1n1Di1s1,g1l1u1c1a1g1o1n1Pr1o1d1
		,g1l1u1c1o1c1o1r1t1i1c1o1i1d1,g1l1u1c1o1s1e1,h1g1h1
		,h1v1a1,i1n1s1u1l1i1n1,n1e1
		,n1e12d1h1p1g1,n1e12Ep1i1n1,n1e1Co1n1t1r1o1l1
		,n1e1Pr1o1d1u1c1t1i1o1n1,p1Hg1h1,p1n1s1
		,p1Pr1l1,p1r1l1,p1r1l1Re1l1e1a1s1e1
		,s1a1t1e1i1t1y1,s1e1r1o1t1o1n1i1n1,s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1
		,s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA,s1n1s1,s1r1if
		,t14,t1e1m1p11,t1e1m1p12
		,t1e1m1p13,t1o1Ki1d1n1e1y1s1,t1o1Ti1s1s1u1e1
		,v1a1g1u1s1].
 

*c1r1f1  ++  a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*a1c1t1h1Pr1o1d1u1c1t1i1o1n1  +-+  a1c1t1h1.
*h1y1p1o1x1  --  a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*a1c1t1h1  ++  c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1.
*if no g1u1a1n1 then   s1n1s1  ++  c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1.
*if no a1d1r1x1 then c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1  +-+  c1o1r1t1i1s1o1l1.
*c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1  +--  c1o1r1t1i1s1o1l1.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1  --  a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1  +-+  g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*d1e1x1  ++  g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*a1c1u1t1Ed1e1x1  ++  g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*c1h1r1o1n1i1Cd1e1x1  ++  g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*if no a1d1r1x1 then c1a1t1e1c1h1o1l1e1Pr1o1d1  +-+  c1a1t1e1c1h1o1l1e1.
*c1a1t1e1c1h1o1l1e1Di1s1p1  +--  c1a1t1e1c1h1o1l1e1.
*if no g1u1a1n1 then s1n1s1  ++  c1a1t1e1c1h1o1l1e1Pr1o1d1.
*d1a1Pr1o1d1u1c1t1i1o1n1  +-+  d1a1.
*d1a12Hv1a1  +--  d1a1.
*p1r1l1  ++  d1a1.
*a1l1u1m1i1n1i1u1m1  --  d1a1Pr1o1d1u1c1t1i1o1n1.
*if no m1s1g1 then d1a12Hv1a1  +-+  h1v1a1.
*p1a1r1g1  --  d1a12Hv1a1.
*g1l1u1c1a1g1o1n1Pr1o1d1  +-+  g1l1u1c1a1g1o1n1.
*g1l1u1c1a1g1o1n1Di1s1  +--  g1l1u1c1a1g1o1n1.
*if no g1u1a1n1 then s1n1s1  ++  g1l1u1c1a1g1o1n1Pr1o1d1.
*g1l1u1c1o1s1e1  --  g1l1u1c1a1g1o1n1Pr1o1d1.
*i1n1s1u1l1i1n1  --  g1l1u1c1a1g1o1n1Pr1o1d1.
*c1h1r1o1n1i1Cg1l1u1c1o1s1e1  ++  g1l1u1c1o1s1e1.
*f1r1o1m1Gu1t1  +-+  g1l1u1c1o1s1e1.
*f1r1o1m1Li1v1e1r1  +-+  g1l1u1c1o1s1e1.
*b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1  +--  g1l1u1c1o1s1e1.
*g1l1u1c1o1s1e1  ++  b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1.
*t1o1Ti1s1s1u1e1  +--  g1l1u1c1o1s1e1.
*b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1  +-+  b1r1a1i1n1Gl1u1c1o1s1e1.
*t1e1m1p11  ++  t1o1Ti1s1s1u1e1.
*g1l1u1c1o1s1e1  ++  t1e1m1p11.
*i1n1s1u1l1i1n1  ++  t1e1m1p11.
*t1e1m1p12  ++  f1r1o1m1Li1v1e1r1.
*i1n1s1u1l1i1n1  --  t1e1m1p12.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1  ++  t1e1m1p12.
*p1n1s1  --  t1e1m1p12.
*c1a1t1e1c1h1o1l1e1  ++  t1e1m1p12.
*if no g1u1a1n1 then s1n1s1  --  t1e1m1p12.
*g1l1u1c1a1g1o1n1  ++  t1e1m1p12.
*t1w1o1Dg1  --  b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1.
*f1r1o1m1Pa1n1c1r1e1a1s1  +-+  i1n1s1u1l1i1n1.
*t1o1Ki1d1n1e1y1s1  +--  i1n1s1u1l1i1n1.
*i1n1s1u1l1i1n1  ++  t1o1Ki1d1n1e1y1s1.
*if g1u1a1n1 then  s1n1s1  --  t1e1m1p13.
*c1a1t1e1c1h1o1l1e1  --  t1e1m1p13.
*g1l1u1c1a1g1o1n1  ++  t1e1m1p13.
*g1l1u1c1o1s1e1  ++  t1e1m1p13.
*p1n1s1  ++  t1e1m1p13.
*t1e1m1p13  ++  f1r1o1m1Pa1n1c1r1e1a1s1.
*i1n1s1u1l1i1n1Bo1l1i1s1  ++  i1n1s1u1l1i1n1.
*i1n1s1u1l1i1n110  ++  i1n1s1u1l1i1n1.
*i1n1s1u1l1i1n130  ++  i1n1s1u1l1i1n1.
*c1h1r1o1n1i1Ci1n1s1u1l1i1n1  ++  i1n1s1u1l1i1n1.
*t1o1l1b1u1t110  ++  f1r1o1m1Pa1n1c1r1e1a1s1.
*t1o1l1b1u1t120  ++  f1r1o1m1Pa1n1c1r1e1a1s1.
*t1o1l1b1u1t130  ++  f1r1o1m1Pa1n1c1r1e1a1s1.
*c1h1r1o1n1i1Ct1o1l1b1u1t1  ++  f1r1o1m1Pa1n1c1r1e1a1s1.
*n1e1Pr1o1d1u1c1t1i1o1n1  +--  d1a1.
*if no m1s1g1 then n1e1Pr1o1d1u1c1t1i1o1n1  +-+  n1e1.
*n1e12d1h1p1g1  +--  n1e1.
*n1e12Ep1i1n1  +--  n1e1.
*if no m1s1g1 then   n1e12d1h1p1g1  +-+  d1h1p1g1.
*d1h1p1g1  ++  c1r1f1.
*d1h1p1g1  ++  s1n1s1.
*s1t1r1e1s1s1  ++  n1e1Co1n1t1r1o1l1.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1  --  n1e1Co1n1t1r1o1l1.
*b1r1a1i1n1Gl1u1c1o1s1e1  --  n1e1Co1n1t1r1o1l1.
*n1e1Co1n1t1r1o1l1  ++  n1e1Pr1o1d1u1c1t1i1o1n1.
*n1e1Co1n1t1r1o1l1  ++  n1e12d1h1p1g1.
*n1e1  ++  n1e12d1h1p1g1.
*a1l1u1m1i1n1i1u1m1  --  n1e12d1h1p1g1.
*n1e1  +-+  n1e12Ep1i1n1.
*h1g1h1  ++  n1e1Pr1o1d1u1c1t1i1o1n1.
*i1n1s1u1l1i1n1  --  n1e1Pr1o1d1u1c1t1i1o1n1.
*s1w1i1m1s1t1r1  ++  s1t1r1e1s1s1.
*e1t1h1e1r1s1t1r1  ++  s1t1r1e1s1s1.
*y1o1h1  ++  n1e1Pr1o1d1u1c1t1i1o1n1.
*p1a1r1g1  --  n1e12d1h1p1g1.
*g1e1n1t1l1e1  ++  s1t1r1e1s1s1.
*d1i1a1z1  --  n1e1Co1n1t1r1o1l1.
*c1h1r1o1n1i1Cd1i1a1z1  --  n1e1Co1n1t1r1o1l1.
*p1n1s1  ++  v1a1g1u1s1.
*i1n1s1u1l1i1n1  ++  p1n1s1.
*f1i1v1e1HIAA  ++  p1n1s1.
*s1n1s1  --  p1n1s1.
*d1a1  --  p1r1l1Re1l1e1a1s1e1.
*d1a1  --  p1Pr1l1.
*p1r1l1Re1l1e1a1s1e1  +--  p1Pr1l1.
*if no h1y1p1o1x1 then p1r1l1Re1l1e1a1s1e1  +-+  p1r1l1.
*f1i1v1e1HIAA  ++  s1a1t1e1i1t1y1.
*b1r1a1i1n1Gl1u1c1o1s1e1  --  s1a1t1e1i1t1y1.
*if no m1s1g1 then s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1  +-+  s1e1r1o1t1o1n1i1n1.
*s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA  +--  s1e1r1o1t1o1n1i1n1.
*s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA  +-+  f1i1v1e1HIAA.
*h1g1h1  --  s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*t14  --  s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*t14  ++  s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*s1e1r1o1t1o1n1i1n1  ++  s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*b1r1a1i1n1Gl1u1c1o1s1e1  ++  s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*i1n1s1u1l1i1n1  ++  s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*p1n1s1  ++  s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*p1n1s1  ++  s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*p1a1r1g1  --  s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*m1s1g1  --  s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*p1n1s1  --  s1n1s1.
*g1h1Pr1o1d1u1c1t1i1o1n1  +--  p1Hg1h1.
*if h1y1p1o1x1 then  g1h1Pr1o1d1u1c1t1i1o1n1  +-+  h1g1h1.
*h1g1h1In1j1  ++  h1g1h1.
*f1i1v1e1HIAA  ++  g1h1r1h1.
*g1h1r1h1  --  p1Hg1h1.
*g1h1r1h1  ++  g1h1Pr1o1d1u1c1t1i1o1n1.
*g1l1u1c1o1s1e1  ++  g1h1Pr1o1d1u1c1t1i1o1n1.
*g1l1u1c1o1s1e1  ++  p1Hg1h1.
*s1r1if  --  p1Hg1h1.
*s1r1if  --  g1h1Pr1o1d1u1c1t1i1o1n1.
*c1r1f1  ++  s1r1if.

*r1x1= [[], [m1s1g1], [d1i1a1z1], [g1u1a1n1], [p1a1r1g1], [h1y1p1o1x1], [t1w1o1Dg1], [a1c1u1t1Ed1e1x1],
 [g1e1n1t1l1e1],[c1h1r1o1n1i1Cd1e1x1], [s1w1i1m1s1t1r1 ], [  e1t1h1e1r1s1t1r1 ], [  p1t1u1,  y1o1h1 ], [  t1o1l1b1u1t110 ],
 [  t1o1l1b1u1t120 ], [  i1n1s1u1l1i1n110 ], [  i1n1s1u1l1i1n130 ], [  m1s1g1,  p1a1r1g1 ], [  c1h1r1o1n1i1Ct1o1l1b1u1t1 ], 
[  c1h1r1o1n1i1Cg1l1u1c1o1s1e1 ], [  c1h1r1o1n1i1Ci1n1s1u1l1i1n1 ], [  g1e1n1t1l1e1 , y1o1h1 ], [  g1u1a1n1 , t1w1o1Dg1 ],
 [p1t1u1 , s1w1i1m1s1t1r1 ], [  p1t1u1,  e1t1h1e1r1s1t1r1 ], [  d1i1a1z1,  c1h1r1o1n1i1Cd1i1a1z1 ], [  h1y1p1o1x1 , h1g1h1In1j1 ], 
[  a1c1u1t1Ed1e1x1 , s1w1i1m1s1t1r1 ], [c1h1r1o1n1i1Cd1e1x1 , s1w1i1m1s1t1r1 ], [  c1h1r1o1n1i1Cg1l1u1c1o1s1e1 , c1h1r1o1n1i1Ct1o1l1b1u1t1]].

*d1a1=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n1e1=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h1g1h1=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h1v1a1=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a1c1t1h1=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d1h1p1g1=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g1l1u1c1o1s1e1=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i1n1s1u1l1i1n1=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c1o1r1t1i1s1o1l1=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f1i1v1e1HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g1l1u1c1a1g1o1n1=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s1e1r1o1t1o1n1i1n1=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d1o1n1e1.
