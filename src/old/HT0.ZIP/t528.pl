*[a5c5u5t5Ed5e5x5,a5d5r5x5,c5h5r5o5n5i5Cd5e5x5
		,c5h5r5o5n5i5Cd5i5a5z5,c5h5r5o5n5i5Cg5l5u5c5o5s5e5,c5h5r5o5n5i5Ci5n5s5u5l5i5n5
		,c5h5r5o5n5i5Ct5o5l5b5u5t5,d5e5x5,d5i5a5z5
		,e5t5h5e5r5s5t5r5,g5e5n5t5l5e5,g5u5a5n5
		,h5g5h5In5j5,h5y5p5o5x5,i5n5s5u5l5i5n510
		,i5n5s5u5l5i5n530,i5n5s5u5l5i5n5Bo5l5i5s5,m5s5g5
		,p5a5r5g5,p5t5u5,s5t5r5e5s5s5
		,s5w5i5m5s5t5r5,t5o5l5b5u5t510,t5o5l5b5u5t520
		,t5o5l5b5u5t530,t5w5o5Dg5,y5o5h5
                ,a5c5t5h5,a5c5t5h5Pr5o5d5u5c5t5i5o5n5,a5l5u5m5i5n5i5u5m5,b5r5a5i5n5Gl5u5c5o5s5e5
		,b5r5a5i5n5Gl5u5c5o5s5e5Up5t5a5k5e5,c5a5t5e5c5h5o5l5e5,c5a5t5e5c5h5o5l5e5Di5s5p5
		,c5a5t5e5c5h5o5l5e5Pr5o5d5,c5o5r5t5i5c5o5i5d5Pr5o5d5u5c5t5i5o5n5,c5o5r5t5i5s5o5l5
		,c5o5r5t5i5s5o5l5Pr5o5d5u5c5t5i5o5n5,c5r5f5,d5a5
		,d5a52Hv5a5,d5a5Pr5o5d5u5c5t5i5o5n5,d5h5p5g5
		,f5i5v5e5HIAA,f5r5o5m5Gu5t5,f5r5o5m5Li5v5e5r5
		,f5r5o5m5Pa5n5c5r5e5a5s5,g5h5Pr5o5d5u5c5t5i5o5n5,g5h5r5h5
		,g5l5u5c5a5g5o5n5,g5l5u5c5a5g5o5n5Di5s5,g5l5u5c5a5g5o5n5Pr5o5d5
		,g5l5u5c5o5c5o5r5t5i5c5o5i5d5,g5l5u5c5o5s5e5,h5g5h5
		,h5v5a5,i5n5s5u5l5i5n5,n5e5
		,n5e52d5h5p5g5,n5e52Ep5i5n5,n5e5Co5n5t5r5o5l5
		,n5e5Pr5o5d5u5c5t5i5o5n5,p5Hg5h5,p5n5s5
		,p5Pr5l5,p5r5l5,p5r5l5Re5l5e5a5s5e5
		,s5a5t5e5i5t5y5,s5e5r5o5t5o5n5i5n5,s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5
		,s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA,s5n5s5,s5r5if
		,t54,t5e5m5p51,t5e5m5p52
		,t5e5m5p53,t5o5Ki5d5n5e5y5s5,t5o5Ti5s5s5u5e5
		,v5a5g5u5s5].
 

*c5r5f5  ++  a5c5t5h5Pr5o5d5u5c5t5i5o5n5.
*a5c5t5h5Pr5o5d5u5c5t5i5o5n5  +-+  a5c5t5h5.
*h5y5p5o5x5  --  a5c5t5h5Pr5o5d5u5c5t5i5o5n5.
*a5c5t5h5  ++  c5o5r5t5i5s5o5l5Pr5o5d5u5c5t5i5o5n5.
*if no g5u5a5n5 then   s5n5s5  ++  c5o5r5t5i5s5o5l5Pr5o5d5u5c5t5i5o5n5.
*if no a5d5r5x5 then c5o5r5t5i5s5o5l5Pr5o5d5u5c5t5i5o5n5  +-+  c5o5r5t5i5s5o5l5.
*c5o5r5t5i5c5o5i5d5Pr5o5d5u5c5t5i5o5n5  +--  c5o5r5t5i5s5o5l5.
*g5l5u5c5o5c5o5r5t5i5c5o5i5d5  --  a5c5t5h5Pr5o5d5u5c5t5i5o5n5.
*c5o5r5t5i5c5o5i5d5Pr5o5d5u5c5t5i5o5n5  +-+  g5l5u5c5o5c5o5r5t5i5c5o5i5d5.
*d5e5x5  ++  g5l5u5c5o5c5o5r5t5i5c5o5i5d5.
*a5c5u5t5Ed5e5x5  ++  g5l5u5c5o5c5o5r5t5i5c5o5i5d5.
*c5h5r5o5n5i5Cd5e5x5  ++  g5l5u5c5o5c5o5r5t5i5c5o5i5d5.
*if no a5d5r5x5 then c5a5t5e5c5h5o5l5e5Pr5o5d5  +-+  c5a5t5e5c5h5o5l5e5.
*c5a5t5e5c5h5o5l5e5Di5s5p5  +--  c5a5t5e5c5h5o5l5e5.
*if no g5u5a5n5 then s5n5s5  ++  c5a5t5e5c5h5o5l5e5Pr5o5d5.
*d5a5Pr5o5d5u5c5t5i5o5n5  +-+  d5a5.
*d5a52Hv5a5  +--  d5a5.
*p5r5l5  ++  d5a5.
*a5l5u5m5i5n5i5u5m5  --  d5a5Pr5o5d5u5c5t5i5o5n5.
*if no m5s5g5 then d5a52Hv5a5  +-+  h5v5a5.
*p5a5r5g5  --  d5a52Hv5a5.
*g5l5u5c5a5g5o5n5Pr5o5d5  +-+  g5l5u5c5a5g5o5n5.
*g5l5u5c5a5g5o5n5Di5s5  +--  g5l5u5c5a5g5o5n5.
*if no g5u5a5n5 then s5n5s5  ++  g5l5u5c5a5g5o5n5Pr5o5d5.
*g5l5u5c5o5s5e5  --  g5l5u5c5a5g5o5n5Pr5o5d5.
*i5n5s5u5l5i5n5  --  g5l5u5c5a5g5o5n5Pr5o5d5.
*c5h5r5o5n5i5Cg5l5u5c5o5s5e5  ++  g5l5u5c5o5s5e5.
*f5r5o5m5Gu5t5  +-+  g5l5u5c5o5s5e5.
*f5r5o5m5Li5v5e5r5  +-+  g5l5u5c5o5s5e5.
*b5r5a5i5n5Gl5u5c5o5s5e5Up5t5a5k5e5  +--  g5l5u5c5o5s5e5.
*g5l5u5c5o5s5e5  ++  b5r5a5i5n5Gl5u5c5o5s5e5Up5t5a5k5e5.
*t5o5Ti5s5s5u5e5  +--  g5l5u5c5o5s5e5.
*b5r5a5i5n5Gl5u5c5o5s5e5Up5t5a5k5e5  +-+  b5r5a5i5n5Gl5u5c5o5s5e5.
*t5e5m5p51  ++  t5o5Ti5s5s5u5e5.
*g5l5u5c5o5s5e5  ++  t5e5m5p51.
*i5n5s5u5l5i5n5  ++  t5e5m5p51.
*t5e5m5p52  ++  f5r5o5m5Li5v5e5r5.
*i5n5s5u5l5i5n5  --  t5e5m5p52.
*g5l5u5c5o5c5o5r5t5i5c5o5i5d5  ++  t5e5m5p52.
*p5n5s5  --  t5e5m5p52.
*c5a5t5e5c5h5o5l5e5  ++  t5e5m5p52.
*if no g5u5a5n5 then s5n5s5  --  t5e5m5p52.
*g5l5u5c5a5g5o5n5  ++  t5e5m5p52.
*t5w5o5Dg5  --  b5r5a5i5n5Gl5u5c5o5s5e5Up5t5a5k5e5.
*f5r5o5m5Pa5n5c5r5e5a5s5  +-+  i5n5s5u5l5i5n5.
*t5o5Ki5d5n5e5y5s5  +--  i5n5s5u5l5i5n5.
*i5n5s5u5l5i5n5  ++  t5o5Ki5d5n5e5y5s5.
*if g5u5a5n5 then  s5n5s5  --  t5e5m5p53.
*c5a5t5e5c5h5o5l5e5  --  t5e5m5p53.
*g5l5u5c5a5g5o5n5  ++  t5e5m5p53.
*g5l5u5c5o5s5e5  ++  t5e5m5p53.
*p5n5s5  ++  t5e5m5p53.
*t5e5m5p53  ++  f5r5o5m5Pa5n5c5r5e5a5s5.
*i5n5s5u5l5i5n5Bo5l5i5s5  ++  i5n5s5u5l5i5n5.
*i5n5s5u5l5i5n510  ++  i5n5s5u5l5i5n5.
*i5n5s5u5l5i5n530  ++  i5n5s5u5l5i5n5.
*c5h5r5o5n5i5Ci5n5s5u5l5i5n5  ++  i5n5s5u5l5i5n5.
*t5o5l5b5u5t510  ++  f5r5o5m5Pa5n5c5r5e5a5s5.
*t5o5l5b5u5t520  ++  f5r5o5m5Pa5n5c5r5e5a5s5.
*t5o5l5b5u5t530  ++  f5r5o5m5Pa5n5c5r5e5a5s5.
*c5h5r5o5n5i5Ct5o5l5b5u5t5  ++  f5r5o5m5Pa5n5c5r5e5a5s5.
*n5e5Pr5o5d5u5c5t5i5o5n5  +--  d5a5.
*if no m5s5g5 then n5e5Pr5o5d5u5c5t5i5o5n5  +-+  n5e5.
*n5e52d5h5p5g5  +--  n5e5.
*n5e52Ep5i5n5  +--  n5e5.
*if no m5s5g5 then   n5e52d5h5p5g5  +-+  d5h5p5g5.
*d5h5p5g5  ++  c5r5f5.
*d5h5p5g5  ++  s5n5s5.
*s5t5r5e5s5s5  ++  n5e5Co5n5t5r5o5l5.
*g5l5u5c5o5c5o5r5t5i5c5o5i5d5  --  n5e5Co5n5t5r5o5l5.
*b5r5a5i5n5Gl5u5c5o5s5e5  --  n5e5Co5n5t5r5o5l5.
*n5e5Co5n5t5r5o5l5  ++  n5e5Pr5o5d5u5c5t5i5o5n5.
*n5e5Co5n5t5r5o5l5  ++  n5e52d5h5p5g5.
*n5e5  ++  n5e52d5h5p5g5.
*a5l5u5m5i5n5i5u5m5  --  n5e52d5h5p5g5.
*n5e5  +-+  n5e52Ep5i5n5.
*h5g5h5  ++  n5e5Pr5o5d5u5c5t5i5o5n5.
*i5n5s5u5l5i5n5  --  n5e5Pr5o5d5u5c5t5i5o5n5.
*s5w5i5m5s5t5r5  ++  s5t5r5e5s5s5.
*e5t5h5e5r5s5t5r5  ++  s5t5r5e5s5s5.
*y5o5h5  ++  n5e5Pr5o5d5u5c5t5i5o5n5.
*p5a5r5g5  --  n5e52d5h5p5g5.
*g5e5n5t5l5e5  ++  s5t5r5e5s5s5.
*d5i5a5z5  --  n5e5Co5n5t5r5o5l5.
*c5h5r5o5n5i5Cd5i5a5z5  --  n5e5Co5n5t5r5o5l5.
*p5n5s5  ++  v5a5g5u5s5.
*i5n5s5u5l5i5n5  ++  p5n5s5.
*f5i5v5e5HIAA  ++  p5n5s5.
*s5n5s5  --  p5n5s5.
*d5a5  --  p5r5l5Re5l5e5a5s5e5.
*d5a5  --  p5Pr5l5.
*p5r5l5Re5l5e5a5s5e5  +--  p5Pr5l5.
*if no h5y5p5o5x5 then p5r5l5Re5l5e5a5s5e5  +-+  p5r5l5.
*f5i5v5e5HIAA  ++  s5a5t5e5i5t5y5.
*b5r5a5i5n5Gl5u5c5o5s5e5  --  s5a5t5e5i5t5y5.
*if no m5s5g5 then s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5  +-+  s5e5r5o5t5o5n5i5n5.
*s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA  +--  s5e5r5o5t5o5n5i5n5.
*s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA  +-+  f5i5v5e5HIAA.
*h5g5h5  --  s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5.
*t54  --  s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5.
*t54  ++  s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA.
*s5e5r5o5t5o5n5i5n5  ++  s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA.
*b5r5a5i5n5Gl5u5c5o5s5e5  ++  s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5.
*i5n5s5u5l5i5n5  ++  s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5.
*p5n5s5  ++  s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5.
*p5n5s5  ++  s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA.
*p5a5r5g5  --  s5e5r5o5t5o5n5i5n5TOf5i5v5e5HIAA.
*m5s5g5  --  s5e5r5o5t5o5n5i5n5Pr5o5d5u5c5t5i5o5n5.
*p5n5s5  --  s5n5s5.
*g5h5Pr5o5d5u5c5t5i5o5n5  +--  p5Hg5h5.
*if h5y5p5o5x5 then  g5h5Pr5o5d5u5c5t5i5o5n5  +-+  h5g5h5.
*h5g5h5In5j5  ++  h5g5h5.
*f5i5v5e5HIAA  ++  g5h5r5h5.
*g5h5r5h5  --  p5Hg5h5.
*g5h5r5h5  ++  g5h5Pr5o5d5u5c5t5i5o5n5.
*g5l5u5c5o5s5e5  ++  g5h5Pr5o5d5u5c5t5i5o5n5.
*g5l5u5c5o5s5e5  ++  p5Hg5h5.
*s5r5if  --  p5Hg5h5.
*s5r5if  --  g5h5Pr5o5d5u5c5t5i5o5n5.
*c5r5f5  ++  s5r5if.

*r5x5= [[], [m5s5g5], [d5i5a5z5], [g5u5a5n5], [p5a5r5g5], [h5y5p5o5x5], [t5w5o5Dg5], [a5c5u5t5Ed5e5x5],
 [g5e5n5t5l5e5],[c5h5r5o5n5i5Cd5e5x5], [s5w5i5m5s5t5r5 ], [  e5t5h5e5r5s5t5r5 ], [  p5t5u5,  y5o5h5 ], [  t5o5l5b5u5t510 ],
 [  t5o5l5b5u5t520 ], [  i5n5s5u5l5i5n510 ], [  i5n5s5u5l5i5n530 ], [  m5s5g5,  p5a5r5g5 ], [  c5h5r5o5n5i5Ct5o5l5b5u5t5 ], 
[  c5h5r5o5n5i5Cg5l5u5c5o5s5e5 ], [  c5h5r5o5n5i5Ci5n5s5u5l5i5n5 ], [  g5e5n5t5l5e5 , y5o5h5 ], [  g5u5a5n5 , t5w5o5Dg5 ],
 [p5t5u5 , s5w5i5m5s5t5r5 ], [  p5t5u5,  e5t5h5e5r5s5t5r5 ], [  d5i5a5z5,  c5h5r5o5n5i5Cd5i5a5z5 ], [  h5y5p5o5x5 , h5g5h5In5j5 ], 
[  a5c5u5t5Ed5e5x5 , s5w5i5m5s5t5r5 ], [c5h5r5o5n5i5Cd5e5x5 , s5w5i5m5s5t5r5 ], [  c5h5r5o5n5i5Cg5l5u5c5o5s5e5 , c5h5r5o5n5i5Ct5o5l5b5u5t5]].

*d5a5=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n5e5=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h5g5h5=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h5v5a5=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a5c5t5h5=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d5h5p5g5=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g5l5u5c5o5s5e5=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i5n5s5u5l5i5n5=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c5o5r5t5i5s5o5l5=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f5i5v5e5HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g5l5u5c5a5g5o5n5=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s5e5r5o5t5o5n5i5n5=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d5o5n5e5.
