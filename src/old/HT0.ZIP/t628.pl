*[a6c6u6t6Ed6e6x6,a6d6r6x6,c6h6r6o6n6i6Cd6e6x6
		,c6h6r6o6n6i6Cd6i6a6z6,c6h6r6o6n6i6Cg6l6u6c6o6s6e6,c6h6r6o6n6i6Ci6n6s6u6l6i6n6
		,c6h6r6o6n6i6Ct6o6l6b6u6t6,d6e6x6,d6i6a6z6
		,e6t6h6e6r6s6t6r6,g6e6n6t6l6e6,g6u6a6n6
		,h6g6h6In6j6,h6y6p6o6x6,i6n6s6u6l6i6n610
		,i6n6s6u6l6i6n630,i6n6s6u6l6i6n6Bo6l6i6s6,m6s6g6
		,p6a6r6g6,p6t6u6,s6t6r6e6s6s6
		,s6w6i6m6s6t6r6,t6o6l6b6u6t610,t6o6l6b6u6t620
		,t6o6l6b6u6t630,t6w6o6Dg6,y6o6h6
                ,a6c6t6h6,a6c6t6h6Pr6o6d6u6c6t6i6o6n6,a6l6u6m6i6n6i6u6m6,b6r6a6i6n6Gl6u6c6o6s6e6
		,b6r6a6i6n6Gl6u6c6o6s6e6Up6t6a6k6e6,c6a6t6e6c6h6o6l6e6,c6a6t6e6c6h6o6l6e6Di6s6p6
		,c6a6t6e6c6h6o6l6e6Pr6o6d6,c6o6r6t6i6c6o6i6d6Pr6o6d6u6c6t6i6o6n6,c6o6r6t6i6s6o6l6
		,c6o6r6t6i6s6o6l6Pr6o6d6u6c6t6i6o6n6,c6r6f6,d6a6
		,d6a62Hv6a6,d6a6Pr6o6d6u6c6t6i6o6n6,d6h6p6g6
		,f6i6v6e6HIAA,f6r6o6m6Gu6t6,f6r6o6m6Li6v6e6r6
		,f6r6o6m6Pa6n6c6r6e6a6s6,g6h6Pr6o6d6u6c6t6i6o6n6,g6h6r6h6
		,g6l6u6c6a6g6o6n6,g6l6u6c6a6g6o6n6Di6s6,g6l6u6c6a6g6o6n6Pr6o6d6
		,g6l6u6c6o6c6o6r6t6i6c6o6i6d6,g6l6u6c6o6s6e6,h6g6h6
		,h6v6a6,i6n6s6u6l6i6n6,n6e6
		,n6e62d6h6p6g6,n6e62Ep6i6n6,n6e6Co6n6t6r6o6l6
		,n6e6Pr6o6d6u6c6t6i6o6n6,p6Hg6h6,p6n6s6
		,p6Pr6l6,p6r6l6,p6r6l6Re6l6e6a6s6e6
		,s6a6t6e6i6t6y6,s6e6r6o6t6o6n6i6n6,s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6
		,s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA,s6n6s6,s6r6if
		,t64,t6e6m6p61,t6e6m6p62
		,t6e6m6p63,t6o6Ki6d6n6e6y6s6,t6o6Ti6s6s6u6e6
		,v6a6g6u6s6].
 

*c6r6f6  ++  a6c6t6h6Pr6o6d6u6c6t6i6o6n6.
*a6c6t6h6Pr6o6d6u6c6t6i6o6n6  +-+  a6c6t6h6.
*h6y6p6o6x6  --  a6c6t6h6Pr6o6d6u6c6t6i6o6n6.
*a6c6t6h6  ++  c6o6r6t6i6s6o6l6Pr6o6d6u6c6t6i6o6n6.
*if no g6u6a6n6 then   s6n6s6  ++  c6o6r6t6i6s6o6l6Pr6o6d6u6c6t6i6o6n6.
*if no a6d6r6x6 then c6o6r6t6i6s6o6l6Pr6o6d6u6c6t6i6o6n6  +-+  c6o6r6t6i6s6o6l6.
*c6o6r6t6i6c6o6i6d6Pr6o6d6u6c6t6i6o6n6  +--  c6o6r6t6i6s6o6l6.
*g6l6u6c6o6c6o6r6t6i6c6o6i6d6  --  a6c6t6h6Pr6o6d6u6c6t6i6o6n6.
*c6o6r6t6i6c6o6i6d6Pr6o6d6u6c6t6i6o6n6  +-+  g6l6u6c6o6c6o6r6t6i6c6o6i6d6.
*d6e6x6  ++  g6l6u6c6o6c6o6r6t6i6c6o6i6d6.
*a6c6u6t6Ed6e6x6  ++  g6l6u6c6o6c6o6r6t6i6c6o6i6d6.
*c6h6r6o6n6i6Cd6e6x6  ++  g6l6u6c6o6c6o6r6t6i6c6o6i6d6.
*if no a6d6r6x6 then c6a6t6e6c6h6o6l6e6Pr6o6d6  +-+  c6a6t6e6c6h6o6l6e6.
*c6a6t6e6c6h6o6l6e6Di6s6p6  +--  c6a6t6e6c6h6o6l6e6.
*if no g6u6a6n6 then s6n6s6  ++  c6a6t6e6c6h6o6l6e6Pr6o6d6.
*d6a6Pr6o6d6u6c6t6i6o6n6  +-+  d6a6.
*d6a62Hv6a6  +--  d6a6.
*p6r6l6  ++  d6a6.
*a6l6u6m6i6n6i6u6m6  --  d6a6Pr6o6d6u6c6t6i6o6n6.
*if no m6s6g6 then d6a62Hv6a6  +-+  h6v6a6.
*p6a6r6g6  --  d6a62Hv6a6.
*g6l6u6c6a6g6o6n6Pr6o6d6  +-+  g6l6u6c6a6g6o6n6.
*g6l6u6c6a6g6o6n6Di6s6  +--  g6l6u6c6a6g6o6n6.
*if no g6u6a6n6 then s6n6s6  ++  g6l6u6c6a6g6o6n6Pr6o6d6.
*g6l6u6c6o6s6e6  --  g6l6u6c6a6g6o6n6Pr6o6d6.
*i6n6s6u6l6i6n6  --  g6l6u6c6a6g6o6n6Pr6o6d6.
*c6h6r6o6n6i6Cg6l6u6c6o6s6e6  ++  g6l6u6c6o6s6e6.
*f6r6o6m6Gu6t6  +-+  g6l6u6c6o6s6e6.
*f6r6o6m6Li6v6e6r6  +-+  g6l6u6c6o6s6e6.
*b6r6a6i6n6Gl6u6c6o6s6e6Up6t6a6k6e6  +--  g6l6u6c6o6s6e6.
*g6l6u6c6o6s6e6  ++  b6r6a6i6n6Gl6u6c6o6s6e6Up6t6a6k6e6.
*t6o6Ti6s6s6u6e6  +--  g6l6u6c6o6s6e6.
*b6r6a6i6n6Gl6u6c6o6s6e6Up6t6a6k6e6  +-+  b6r6a6i6n6Gl6u6c6o6s6e6.
*t6e6m6p61  ++  t6o6Ti6s6s6u6e6.
*g6l6u6c6o6s6e6  ++  t6e6m6p61.
*i6n6s6u6l6i6n6  ++  t6e6m6p61.
*t6e6m6p62  ++  f6r6o6m6Li6v6e6r6.
*i6n6s6u6l6i6n6  --  t6e6m6p62.
*g6l6u6c6o6c6o6r6t6i6c6o6i6d6  ++  t6e6m6p62.
*p6n6s6  --  t6e6m6p62.
*c6a6t6e6c6h6o6l6e6  ++  t6e6m6p62.
*if no g6u6a6n6 then s6n6s6  --  t6e6m6p62.
*g6l6u6c6a6g6o6n6  ++  t6e6m6p62.
*t6w6o6Dg6  --  b6r6a6i6n6Gl6u6c6o6s6e6Up6t6a6k6e6.
*f6r6o6m6Pa6n6c6r6e6a6s6  +-+  i6n6s6u6l6i6n6.
*t6o6Ki6d6n6e6y6s6  +--  i6n6s6u6l6i6n6.
*i6n6s6u6l6i6n6  ++  t6o6Ki6d6n6e6y6s6.
*if g6u6a6n6 then  s6n6s6  --  t6e6m6p63.
*c6a6t6e6c6h6o6l6e6  --  t6e6m6p63.
*g6l6u6c6a6g6o6n6  ++  t6e6m6p63.
*g6l6u6c6o6s6e6  ++  t6e6m6p63.
*p6n6s6  ++  t6e6m6p63.
*t6e6m6p63  ++  f6r6o6m6Pa6n6c6r6e6a6s6.
*i6n6s6u6l6i6n6Bo6l6i6s6  ++  i6n6s6u6l6i6n6.
*i6n6s6u6l6i6n610  ++  i6n6s6u6l6i6n6.
*i6n6s6u6l6i6n630  ++  i6n6s6u6l6i6n6.
*c6h6r6o6n6i6Ci6n6s6u6l6i6n6  ++  i6n6s6u6l6i6n6.
*t6o6l6b6u6t610  ++  f6r6o6m6Pa6n6c6r6e6a6s6.
*t6o6l6b6u6t620  ++  f6r6o6m6Pa6n6c6r6e6a6s6.
*t6o6l6b6u6t630  ++  f6r6o6m6Pa6n6c6r6e6a6s6.
*c6h6r6o6n6i6Ct6o6l6b6u6t6  ++  f6r6o6m6Pa6n6c6r6e6a6s6.
*n6e6Pr6o6d6u6c6t6i6o6n6  +--  d6a6.
*if no m6s6g6 then n6e6Pr6o6d6u6c6t6i6o6n6  +-+  n6e6.
*n6e62d6h6p6g6  +--  n6e6.
*n6e62Ep6i6n6  +--  n6e6.
*if no m6s6g6 then   n6e62d6h6p6g6  +-+  d6h6p6g6.
*d6h6p6g6  ++  c6r6f6.
*d6h6p6g6  ++  s6n6s6.
*s6t6r6e6s6s6  ++  n6e6Co6n6t6r6o6l6.
*g6l6u6c6o6c6o6r6t6i6c6o6i6d6  --  n6e6Co6n6t6r6o6l6.
*b6r6a6i6n6Gl6u6c6o6s6e6  --  n6e6Co6n6t6r6o6l6.
*n6e6Co6n6t6r6o6l6  ++  n6e6Pr6o6d6u6c6t6i6o6n6.
*n6e6Co6n6t6r6o6l6  ++  n6e62d6h6p6g6.
*n6e6  ++  n6e62d6h6p6g6.
*a6l6u6m6i6n6i6u6m6  --  n6e62d6h6p6g6.
*n6e6  +-+  n6e62Ep6i6n6.
*h6g6h6  ++  n6e6Pr6o6d6u6c6t6i6o6n6.
*i6n6s6u6l6i6n6  --  n6e6Pr6o6d6u6c6t6i6o6n6.
*s6w6i6m6s6t6r6  ++  s6t6r6e6s6s6.
*e6t6h6e6r6s6t6r6  ++  s6t6r6e6s6s6.
*y6o6h6  ++  n6e6Pr6o6d6u6c6t6i6o6n6.
*p6a6r6g6  --  n6e62d6h6p6g6.
*g6e6n6t6l6e6  ++  s6t6r6e6s6s6.
*d6i6a6z6  --  n6e6Co6n6t6r6o6l6.
*c6h6r6o6n6i6Cd6i6a6z6  --  n6e6Co6n6t6r6o6l6.
*p6n6s6  ++  v6a6g6u6s6.
*i6n6s6u6l6i6n6  ++  p6n6s6.
*f6i6v6e6HIAA  ++  p6n6s6.
*s6n6s6  --  p6n6s6.
*d6a6  --  p6r6l6Re6l6e6a6s6e6.
*d6a6  --  p6Pr6l6.
*p6r6l6Re6l6e6a6s6e6  +--  p6Pr6l6.
*if no h6y6p6o6x6 then p6r6l6Re6l6e6a6s6e6  +-+  p6r6l6.
*f6i6v6e6HIAA  ++  s6a6t6e6i6t6y6.
*b6r6a6i6n6Gl6u6c6o6s6e6  --  s6a6t6e6i6t6y6.
*if no m6s6g6 then s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6  +-+  s6e6r6o6t6o6n6i6n6.
*s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA  +--  s6e6r6o6t6o6n6i6n6.
*s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA  +-+  f6i6v6e6HIAA.
*h6g6h6  --  s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6.
*t64  --  s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6.
*t64  ++  s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA.
*s6e6r6o6t6o6n6i6n6  ++  s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA.
*b6r6a6i6n6Gl6u6c6o6s6e6  ++  s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6.
*i6n6s6u6l6i6n6  ++  s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6.
*p6n6s6  ++  s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6.
*p6n6s6  ++  s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA.
*p6a6r6g6  --  s6e6r6o6t6o6n6i6n6TOf6i6v6e6HIAA.
*m6s6g6  --  s6e6r6o6t6o6n6i6n6Pr6o6d6u6c6t6i6o6n6.
*p6n6s6  --  s6n6s6.
*g6h6Pr6o6d6u6c6t6i6o6n6  +--  p6Hg6h6.
*if h6y6p6o6x6 then  g6h6Pr6o6d6u6c6t6i6o6n6  +-+  h6g6h6.
*h6g6h6In6j6  ++  h6g6h6.
*f6i6v6e6HIAA  ++  g6h6r6h6.
*g6h6r6h6  --  p6Hg6h6.
*g6h6r6h6  ++  g6h6Pr6o6d6u6c6t6i6o6n6.
*g6l6u6c6o6s6e6  ++  g6h6Pr6o6d6u6c6t6i6o6n6.
*g6l6u6c6o6s6e6  ++  p6Hg6h6.
*s6r6if  --  p6Hg6h6.
*s6r6if  --  g6h6Pr6o6d6u6c6t6i6o6n6.
*c6r6f6  ++  s6r6if.

*r6x6= [[], [m6s6g6], [d6i6a6z6], [g6u6a6n6], [p6a6r6g6], [h6y6p6o6x6], [t6w6o6Dg6], [a6c6u6t6Ed6e6x6],
 [g6e6n6t6l6e6],[c6h6r6o6n6i6Cd6e6x6], [s6w6i6m6s6t6r6 ], [  e6t6h6e6r6s6t6r6 ], [  p6t6u6,  y6o6h6 ], [  t6o6l6b6u6t610 ],
 [  t6o6l6b6u6t620 ], [  i6n6s6u6l6i6n610 ], [  i6n6s6u6l6i6n630 ], [  m6s6g6,  p6a6r6g6 ], [  c6h6r6o6n6i6Ct6o6l6b6u6t6 ], 
[  c6h6r6o6n6i6Cg6l6u6c6o6s6e6 ], [  c6h6r6o6n6i6Ci6n6s6u6l6i6n6 ], [  g6e6n6t6l6e6 , y6o6h6 ], [  g6u6a6n6 , t6w6o6Dg6 ],
 [p6t6u6 , s6w6i6m6s6t6r6 ], [  p6t6u6,  e6t6h6e6r6s6t6r6 ], [  d6i6a6z6,  c6h6r6o6n6i6Cd6i6a6z6 ], [  h6y6p6o6x6 , h6g6h6In6j6 ], 
[  a6c6u6t6Ed6e6x6 , s6w6i6m6s6t6r6 ], [c6h6r6o6n6i6Cd6e6x6 , s6w6i6m6s6t6r6 ], [  c6h6r6o6n6i6Cg6l6u6c6o6s6e6 , c6h6r6o6n6i6Ct6o6l6b6u6t6]].

*d6a6=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n6e6=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h6g6h6=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h6v6a6=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a6c6t6h6=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d6h6p6g6=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g6l6u6c6o6s6e6=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i6n6s6u6l6i6n6=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c6o6r6t6i6s6o6l6=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f6i6v6e6HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g6l6u6c6a6g6o6n6=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s6e6r6o6t6o6n6i6n6=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d6o6n6e6.
