*[a1c1u1t1Ed1e1x1, a1d1r1x1, c1h1r1o1n1i1Cd1e1x1, c1h1r1o1n1i1Cd1i1a1z1, c1h1r1o1n1i1Cg1l1u1c1o1s1e1, c1h1r1o1n1i1Ci1n1s1u1l1i1n1, c1h1r1o1n1i1Ct1o1l1b1u1t1, d1e1x1, d1i1a1z1, e1t1h1e1r1s1t1r1, g1e1n1t1l1e1, g1u1a1n1, h1g1h1In1j1, h1y1p1o1x1, i1n1s1u1l1i1n110, i1n1s1u1l1i1n130, i1n1s1u1l1i1n1Bo1l1i1s1, m1s1g1, p1a1r1g1, p1t1u1, s1t1r1e1s1s1, s1w1i1m1s1t1r1, t1o1l1b1u1t110, t1o1l1b1u1t120, t1o1l1b1u1t130, t1w1o1Dg1, y1o1h1, a1c1t1h1, a1c1t1h1Pr1o1d1u1c1t1i1o1n1, a1l1u1m1i1n1i1u1m1, b1r1a1i1n1Gl1u1c1o1s1e1, b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1, c1a1t1e1c1h1o1l1e1, c1a1t1e1c1h1o1l1e1Di1s1p1, c1a1t1e1c1h1o1l1e1Pr1o1d1, c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1, c1o1r1t1i1s1o1l1, c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1, c1r1f1, d1a1, d1a12Hv1a1, d1a1Pr1o1d1u1c1t1i1o1n1, d1h1p1g1, f1i1v1e1HIAA, f1r1o1m1Gu1t1, f1r1o1m1Li1v1e1r1, f1r1o1m1Pa1n1c1r1e1a1s1, g1h1Pr1o1d1u1c1t1i1o1n1, g1h1r1h1, g1l1u1c1a1g1o1n1, g1l1u1c1a1g1o1n1Di1s1, g1l1u1c1a1g1o1n1Pr1o1d1, g1l1u1c1o1c1o1r1t1i1c1o1i1d1, g1l1u1c1o1s1e1, h1g1h1, h1v1a1, i1n1s1u1l1i1n1, n1e1, n1e12d1h1p1g1, n1e12Ep1i1n1, n1e1Co1n1t1r1o1l1, n1e1Pr1o1d1u1c1t1i1o1n1, p1Hg1h1, p1n1s1, p1Pr1l1, p1r1l1, p1r1l1Re1l1e1a1s1e1, s1a1t1e1i1t1y1, s1e1r1o1t1o1n1i1n1, s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1, s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA, s1n1s1, s1r1if, t14, t1e1m1p11, t1e1m1p12, t1e1m1p13, t1o1Ki1d1n1e1y1s1, t1o1Ti1s1s1u1e1, v1a1g1u1s1, a2c2u2t2Ed2e2x2, a2d2r2x2, c2h2r2o2n2i2Cd2e2x2, c2h2r2o2n2i2Cd2i2a2z2, c2h2r2o2n2i2Cg2l2u2c2o2s2e2, c2h2r2o2n2i2Ci2n2s2u2l2i2n2, c2h2r2o2n2i2Ct2o2l2b2u2t2, d2e2x2, d2i2a2z2, e2t2h2e2r2s2t2r2, g2e2n2t2l2e2, g2u2a2n2, h2g2h2In2j2, h2y2p2o2x2, i2n2s2u2l2i2n210, i2n2s2u2l2i2n230, i2n2s2u2l2i2n2Bo2l2i2s2, m2s2g2, p2a2r2g2, p2t2u2, s2t2r2e2s2s2, s2w2i2m2s2t2r2, t2o2l2b2u2t210, t2o2l2b2u2t220, t2o2l2b2u2t230, t2w2o2Dg2, y2o2h2, a2c2t2h2, a2c2t2h2Pr2o2d2u2c2t2i2o2n2, a2l2u2m2i2n2i2u2m2, b2r2a2i2n2Gl2u2c2o2s2e2, b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2, c2a2t2e2c2h2o2l2e2, c2a2t2e2c2h2o2l2e2Di2s2p2, c2a2t2e2c2h2o2l2e2Pr2o2d2, c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2, c2o2r2t2i2s2o2l2, c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2, c2r2f2, d2a2, d2a22Hv2a2, d2a2Pr2o2d2u2c2t2i2o2n2, d2h2p2g2, f2i2v2e2HIAA, f2r2o2m2Gu2t2, f2r2o2m2Li2v2e2r2, f2r2o2m2Pa2n2c2r2e2a2s2, g2h2Pr2o2d2u2c2t2i2o2n2, g2h2r2h2, g2l2u2c2a2g2o2n2, g2l2u2c2a2g2o2n2Di2s2, g2l2u2c2a2g2o2n2Pr2o2d2, g2l2u2c2o2c2o2r2t2i2c2o2i2d2, g2l2u2c2o2s2e2, h2g2h2, h2v2a2, i2n2s2u2l2i2n2, n2e2, n2e22d2h2p2g2, n2e22Ep2i2n2, n2e2Co2n2t2r2o2l2, n2e2Pr2o2d2u2c2t2i2o2n2, p2Hg2h2, p2n2s2, p2Pr2l2, p2r2l2, p2r2l2Re2l2e2a2s2e2, s2a2t2e2i2t2y2, s2e2r2o2t2o2n2i2n2, s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2, s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA, s2n2s2, s2r2if, t24, t2e2m2p21, t2e2m2p22, t2e2m2p23, t2o2Ki2d2n2e2y2s2, t2o2Ti2s2s2u2e2, v2a2g2u2s2].

*rx=[[],[c1r1f1]].
*a1c1t1h1=[0,0].

*c1r1f1++a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*a1c1t1h1Pr1o1d1u1c1t1i1o1n1+-+a1c1t1h1.
*h1y1p1o1x1--a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*a1c1t1h1++c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1.
*if no g1u1a1n1 then s1n1s1++c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1.
*if no a1d1r1x1 then c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1+-+c1o1r1t1i1s1o1l1.
*c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1+--c1o1r1t1i1s1o1l1.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1--a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1+-+g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*d1e1x1++g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*a1c1u1t1Ed1e1x1++g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*c1h1r1o1n1i1Cd1e1x1++g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*if no a1d1r1x1 then c1a1t1e1c1h1o1l1e1Pr1o1d1+-+c1a1t1e1c1h1o1l1e1.
*c1a1t1e1c1h1o1l1e1Di1s1p1+--c1a1t1e1c1h1o1l1e1.
*if no g1u1a1n1 then s1n1s1++c1a1t1e1c1h1o1l1e1Pr1o1d1.
*d1a1Pr1o1d1u1c1t1i1o1n1+-+d1a1.
*d1a12Hv1a1+--d1a1.
*p1r1l1++d1a1.
*a1l1u1m1i1n1i1u1m1--d1a1Pr1o1d1u1c1t1i1o1n1.
*if no m1s1g1 then d1a12Hv1a1+-+h1v1a1.
*p1a1r1g1--d1a12Hv1a1.
*g1l1u1c1a1g1o1n1Pr1o1d1+-+g1l1u1c1a1g1o1n1.
*g1l1u1c1a1g1o1n1Di1s1+--g1l1u1c1a1g1o1n1.
*if no g1u1a1n1 then s1n1s1++g1l1u1c1a1g1o1n1Pr1o1d1.
*g1l1u1c1o1s1e1--g1l1u1c1a1g1o1n1Pr1o1d1.
*i1n1s1u1l1i1n1--g1l1u1c1a1g1o1n1Pr1o1d1.
*c1h1r1o1n1i1Cg1l1u1c1o1s1e1++g1l1u1c1o1s1e1.
*f1r1o1m1Gu1t1+-+g1l1u1c1o1s1e1.
*f1r1o1m1Li1v1e1r1+-+g1l1u1c1o1s1e1.
*b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1+--g1l1u1c1o1s1e1.
*g1l1u1c1o1s1e1++b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1.
*t1o1Ti1s1s1u1e1+--g1l1u1c1o1s1e1.
*b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1+-+b1r1a1i1n1Gl1u1c1o1s1e1.
*t1e1m1p11++t1o1Ti1s1s1u1e1.
*g1l1u1c1o1s1e1++t1e1m1p11.
*i1n1s1u1l1i1n1++t1e1m1p11.
*t1e1m1p12++f1r1o1m1Li1v1e1r1.
*i1n1s1u1l1i1n1--t1e1m1p12.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1++t1e1m1p12.
*p1n1s1--t1e1m1p12.
*c1a1t1e1c1h1o1l1e1++t1e1m1p12.
*if no g1u1a1n1 then s1n1s1--t1e1m1p12.
*g1l1u1c1a1g1o1n1++t1e1m1p12.
*t1w1o1Dg1--b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1.
*f1r1o1m1Pa1n1c1r1e1a1s1+-+i1n1s1u1l1i1n1.
*t1o1Ki1d1n1e1y1s1+--i1n1s1u1l1i1n1.
*i1n1s1u1l1i1n1++t1o1Ki1d1n1e1y1s1.
*if g1u1a1n1 then s1n1s1--t1e1m1p13.
*c1a1t1e1c1h1o1l1e1--t1e1m1p13.
*g1l1u1c1a1g1o1n1++t1e1m1p13.
*g1l1u1c1o1s1e1++t1e1m1p13.
*p1n1s1++t1e1m1p13.
*t1e1m1p13++f1r1o1m1Pa1n1c1r1e1a1s1.
*i1n1s1u1l1i1n1Bo1l1i1s1++i1n1s1u1l1i1n1.
*i1n1s1u1l1i1n110++i1n1s1u1l1i1n1.
*i1n1s1u1l1i1n130++i1n1s1u1l1i1n1.
*c1h1r1o1n1i1Ci1n1s1u1l1i1n1++i1n1s1u1l1i1n1.
*t1o1l1b1u1t110++f1r1o1m1Pa1n1c1r1e1a1s1.
*t1o1l1b1u1t120++f1r1o1m1Pa1n1c1r1e1a1s1.
*t1o1l1b1u1t130++f1r1o1m1Pa1n1c1r1e1a1s1.
*c1h1r1o1n1i1Ct1o1l1b1u1t1++f1r1o1m1Pa1n1c1r1e1a1s1.
*n1e1Pr1o1d1u1c1t1i1o1n1+--d1a1.
*if no m1s1g1 then n1e1Pr1o1d1u1c1t1i1o1n1+-+n1e1.
*n1e12d1h1p1g1+--n1e1.
*n1e12Ep1i1n1+--n1e1.
*if no m1s1g1 then n1e12d1h1p1g1+-+d1h1p1g1.
*d1h1p1g1++c1r1f1.
*d1h1p1g1++s1n1s1.
*s1t1r1e1s1s1++n1e1Co1n1t1r1o1l1.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1--n1e1Co1n1t1r1o1l1.
*b1r1a1i1n1Gl1u1c1o1s1e1--n1e1Co1n1t1r1o1l1.
*n1e1Co1n1t1r1o1l1++n1e1Pr1o1d1u1c1t1i1o1n1.
*n1e1Co1n1t1r1o1l1++n1e12d1h1p1g1.
*n1e1++n1e12d1h1p1g1.
*a1l1u1m1i1n1i1u1m1--n1e12d1h1p1g1.
*n1e1+-+n1e12Ep1i1n1.
*h1g1h1++n1e1Pr1o1d1u1c1t1i1o1n1.
*i1n1s1u1l1i1n1--n1e1Pr1o1d1u1c1t1i1o1n1.
*s1w1i1m1s1t1r1++s1t1r1e1s1s1.
*e1t1h1e1r1s1t1r1++s1t1r1e1s1s1.
*y1o1h1++n1e1Pr1o1d1u1c1t1i1o1n1.
*p1a1r1g1--n1e12d1h1p1g1.
*g1e1n1t1l1e1++s1t1r1e1s1s1.
*d1i1a1z1--n1e1Co1n1t1r1o1l1.
*c1h1r1o1n1i1Cd1i1a1z1--n1e1Co1n1t1r1o1l1.
*p1n1s1++v1a1g1u1s1.
*i1n1s1u1l1i1n1++p1n1s1.
*f1i1v1e1HIAA++p1n1s1.
*s1n1s1--p1n1s1.
*d1a1--p1r1l1Re1l1e1a1s1e1.
*d1a1--p1Pr1l1.
*p1r1l1Re1l1e1a1s1e1+--p1Pr1l1.
*if no h1y1p1o1x1 then p1r1l1Re1l1e1a1s1e1+-+p1r1l1.
*f1i1v1e1HIAA++s1a1t1e1i1t1y1.
*b1r1a1i1n1Gl1u1c1o1s1e1--s1a1t1e1i1t1y1.
*if no m1s1g1 then s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1+-+s1e1r1o1t1o1n1i1n1.
*s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA+--s1e1r1o1t1o1n1i1n1.
*s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA+-+f1i1v1e1HIAA.
*h1g1h1--s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*t14--s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*t14++s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*s1e1r1o1t1o1n1i1n1++s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*b1r1a1i1n1Gl1u1c1o1s1e1++s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*i1n1s1u1l1i1n1++s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*p1n1s1++s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*p1n1s1++s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*p1a1r1g1--s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*m1s1g1--s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*p1n1s1--s1n1s1.
*g1h1Pr1o1d1u1c1t1i1o1n1+--p1Hg1h1.
*if h1y1p1o1x1 then g1h1Pr1o1d1u1c1t1i1o1n1+-+h1g1h1.
*h1g1h1In1j1++h1g1h1.
*f1i1v1e1HIAA++g1h1r1h1.
*g1h1r1h1--p1Hg1h1.
*g1h1r1h1++g1h1Pr1o1d1u1c1t1i1o1n1.
*g1l1u1c1o1s1e1++g1h1Pr1o1d1u1c1t1i1o1n1.
*g1l1u1c1o1s1e1++p1Hg1h1.
*s1r1if--p1Hg1h1.
*s1r1if--g1h1Pr1o1d1u1c1t1i1o1n1.
*c1r1f1++s1r1if.
*c2r2f2++a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*a2c2t2h2Pr2o2d2u2c2t2i2o2n2+-+a2c2t2h2.
*h2y2p2o2x2--a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*a2c2t2h2++c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2.
*if no g2u2a2n2 then s2n2s2++c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2.
*if no a2d2r2x2 then c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2+-+c2o2r2t2i2s2o2l2.
*c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2+--c2o2r2t2i2s2o2l2.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2--a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2+-+g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*d2e2x2++g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*a2c2u2t2Ed2e2x2++g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*c2h2r2o2n2i2Cd2e2x2++g2l2u2c2o2c2o2r2t2i2c2o2i2d2.
*if no a2d2r2x2 then c2a2t2e2c2h2o2l2e2Pr2o2d2+-+c2a2t2e2c2h2o2l2e2.
*c2a2t2e2c2h2o2l2e2Di2s2p2+--c2a2t2e2c2h2o2l2e2.
*if no g2u2a2n2 then s2n2s2++c2a2t2e2c2h2o2l2e2Pr2o2d2.
*d2a2Pr2o2d2u2c2t2i2o2n2+-+d2a2.
*d2a22Hv2a2+--d2a2.
*p2r2l2++d2a2.
*a2l2u2m2i2n2i2u2m2--d2a2Pr2o2d2u2c2t2i2o2n2.
*if no m2s2g2 then d2a22Hv2a2+-+h2v2a2.
*p2a2r2g2--d2a22Hv2a2.
*g2l2u2c2a2g2o2n2Pr2o2d2+-+g2l2u2c2a2g2o2n2.
*g2l2u2c2a2g2o2n2Di2s2+--g2l2u2c2a2g2o2n2.
*if no g2u2a2n2 then s2n2s2++g2l2u2c2a2g2o2n2Pr2o2d2.
*g2l2u2c2o2s2e2--g2l2u2c2a2g2o2n2Pr2o2d2.
*i2n2s2u2l2i2n2--g2l2u2c2a2g2o2n2Pr2o2d2.
*c2h2r2o2n2i2Cg2l2u2c2o2s2e2++g2l2u2c2o2s2e2.
*f2r2o2m2Gu2t2+-+g2l2u2c2o2s2e2.
*f2r2o2m2Li2v2e2r2+-+g2l2u2c2o2s2e2.
*b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2+--g2l2u2c2o2s2e2.
*g2l2u2c2o2s2e2++b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2.
*t2o2Ti2s2s2u2e2+--g2l2u2c2o2s2e2.
*b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2+-+b2r2a2i2n2Gl2u2c2o2s2e2.
*t2e2m2p21++t2o2Ti2s2s2u2e2.
*g2l2u2c2o2s2e2++t2e2m2p21.
*i2n2s2u2l2i2n2++t2e2m2p21.
*t2e2m2p22++f2r2o2m2Li2v2e2r2.
*i2n2s2u2l2i2n2--t2e2m2p22.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2++t2e2m2p22.
*p2n2s2--t2e2m2p22.
*c2a2t2e2c2h2o2l2e2++t2e2m2p22.
*if no g2u2a2n2 then s2n2s2--t2e2m2p22.
*g2l2u2c2a2g2o2n2++t2e2m2p22.
*t2w2o2Dg2--b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2.
*f2r2o2m2Pa2n2c2r2e2a2s2+-+i2n2s2u2l2i2n2.
*t2o2Ki2d2n2e2y2s2+--i2n2s2u2l2i2n2.
*i2n2s2u2l2i2n2++t2o2Ki2d2n2e2y2s2.
*if g2u2a2n2 then s2n2s2--t2e2m2p23.
*c2a2t2e2c2h2o2l2e2--t2e2m2p23.
*g2l2u2c2a2g2o2n2++t2e2m2p23.
*g2l2u2c2o2s2e2++t2e2m2p23.
*p2n2s2++t2e2m2p23.
*t2e2m2p23++f2r2o2m2Pa2n2c2r2e2a2s2.
*i2n2s2u2l2i2n2Bo2l2i2s2++i2n2s2u2l2i2n2.
*i2n2s2u2l2i2n210++i2n2s2u2l2i2n2.
*i2n2s2u2l2i2n230++i2n2s2u2l2i2n2.
*c2h2r2o2n2i2Ci2n2s2u2l2i2n2++i2n2s2u2l2i2n2.
*t2o2l2b2u2t210++f2r2o2m2Pa2n2c2r2e2a2s2.
*t2o2l2b2u2t220++f2r2o2m2Pa2n2c2r2e2a2s2.
*t2o2l2b2u2t230++f2r2o2m2Pa2n2c2r2e2a2s2.
*c2h2r2o2n2i2Ct2o2l2b2u2t2++f2r2o2m2Pa2n2c2r2e2a2s2.
*n2e2Pr2o2d2u2c2t2i2o2n2+--d2a2.
*if no m2s2g2 then n2e2Pr2o2d2u2c2t2i2o2n2+-+n2e2.
*n2e22d2h2p2g2+--n2e2.
*n2e22Ep2i2n2+--n2e2.
*if no m2s2g2 then n2e22d2h2p2g2+-+d2h2p2g2.
*d2h2p2g2++c2r2f2.
*d2h2p2g2++s2n2s2.
*s2t2r2e2s2s2++n2e2Co2n2t2r2o2l2.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2--n2e2Co2n2t2r2o2l2.
*b2r2a2i2n2Gl2u2c2o2s2e2--n2e2Co2n2t2r2o2l2.
*n2e2Co2n2t2r2o2l2++n2e2Pr2o2d2u2c2t2i2o2n2.
*n2e2Co2n2t2r2o2l2++n2e22d2h2p2g2.
*n2e2++n2e22d2h2p2g2.
*a2l2u2m2i2n2i2u2m2--n2e22d2h2p2g2.
*n2e2+-+n2e22Ep2i2n2.
*h2g2h2++n2e2Pr2o2d2u2c2t2i2o2n2.
*i2n2s2u2l2i2n2--n2e2Pr2o2d2u2c2t2i2o2n2.
*s2w2i2m2s2t2r2++s2t2r2e2s2s2.
*e2t2h2e2r2s2t2r2++s2t2r2e2s2s2.
*y2o2h2++n2e2Pr2o2d2u2c2t2i2o2n2.
*p2a2r2g2--n2e22d2h2p2g2.
*g2e2n2t2l2e2++s2t2r2e2s2s2.
*d2i2a2z2--n2e2Co2n2t2r2o2l2.
*c2h2r2o2n2i2Cd2i2a2z2--n2e2Co2n2t2r2o2l2.
*p2n2s2++v2a2g2u2s2.
*i2n2s2u2l2i2n2++p2n2s2.
*f2i2v2e2HIAA++p2n2s2.
*s2n2s2--p2n2s2.
*d2a2--p2r2l2Re2l2e2a2s2e2.
*d2a2--p2Pr2l2.
*p2r2l2Re2l2e2a2s2e2+--p2Pr2l2.
*if no h2y2p2o2x2 then p2r2l2Re2l2e2a2s2e2+-+p2r2l2.
*f2i2v2e2HIAA++s2a2t2e2i2t2y2.
*b2r2a2i2n2Gl2u2c2o2s2e2--s2a2t2e2i2t2y2.
*if no m2s2g2 then s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2+-+s2e2r2o2t2o2n2i2n2.
*s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA+--s2e2r2o2t2o2n2i2n2.
*s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA+-+f2i2v2e2HIAA.
*h2g2h2--s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*t24--s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*t24++s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*s2e2r2o2t2o2n2i2n2++s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*b2r2a2i2n2Gl2u2c2o2s2e2++s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*i2n2s2u2l2i2n2++s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*p2n2s2++s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*p2n2s2++s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*p2a2r2g2--s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*m2s2g2--s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*p2n2s2--s2n2s2.
*g2h2Pr2o2d2u2c2t2i2o2n2+--p2Hg2h2.
*if h2y2p2o2x2 then g2h2Pr2o2d2u2c2t2i2o2n2+-+h2g2h2.
*h2g2h2In2j2++h2g2h2.
*f2i2v2e2HIAA++g2h2r2h2.
*g2h2r2h2--p2Hg2h2.
*g2h2r2h2++g2h2Pr2o2d2u2c2t2i2o2n2.
*g2l2u2c2o2s2e2++g2h2Pr2o2d2u2c2t2i2o2n2.
*g2l2u2c2o2s2e2++p2Hg2h2.
*s2r2if--p2Hg2h2.
*s2r2if--g2h2Pr2o2d2u2c2t2i2o2n2.
*c2r2f2++s2r2if.
*c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1---a2d2r2x2.
*i1n1s1u1l1i1n110--g2l2u2c2o2s2e2.
*f1r1o1m1Pa1n1c1r1e1a1s1+--p2a2r2g2.
*t1o1Ki1d1n1e1y1s1---d2h2p2g2.
*s1n1s1++s2e2r2o2t2o2n2i2n2.
*t1e1m1p11--t2w2o2Dg2.
*d1a1+--s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA.
*c1a1t1e1c1h1o1l1e1Di1s1p1++s2n2s2.
*n1e12d1h1p1g1+--p2Pr2l2.
*c1a1t1e1c1h1o1l1e1+-+f2i2v2e2HIAA.
*n1e12Ep1i1n1+-+c2h2r2o2n2i2Cd2i2a2z2.
*i1n1s1u1l1i1n130++a2c2t2h2Pr2o2d2u2c2t2i2o2n2.
*p1r1l1+--c2h2r2o2n2i2Ci2n2s2u2l2i2n2.
*v1a1g1u1s1--+y2o2h2.
*c1h1r1o1n1i1Cg1l1u1c1o1s1e1--s2t2r2e2s2s2.
*t1w1o1Dg1+-+t24.
*b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1++i2n2s2u2l2i2n230.
*h1g1h1--h2g2h2.
*d1a12Hv1a1++c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2.
*p1Pr1l1+--s2a2t2e2i2t2y2.
*t1e1m1p12---e2t2h2e2r2s2t2r2.
*s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA---t2o2l2b2u2t230.
*n1e1Co1n1t1r1o1l1--+g2l2u2c2a2g2o2n2Di2s2.
*a1c1t1h1Pr1o1d1u1c1t1i1o1n1+-+f2r2o2m2Pa2n2c2r2e2a2s2.
*t1o1l1b1u1t110++g2l2u2c2a2g2o2n2Pr2o2d2.
*t1o1l1b1u1t120--+s2w2i2m2s2t2r2.
*d1e1x1--p2r2l2Re2l2e2a2s2e2.
*a1c1t1h1++v2a2g2u2s2.
*a1c1u1t1Ed1e1x1--+g2h2r2h2.
*c1r1f1--+c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2.
*g1l1u1c1a1g1o1n1Pr1o1d1--+t2o2Ki2d2n2e2y2s2.
*s1w1i1m1s1t1r1++c2h2r2o2n2i2Cg2l2u2c2o2s2e2.
*h1g1h1In1j1--+h2y2p2o2x2.
*p1a1r1g1---c2h2r2o2n2i2Ct2o2l2b2u2t2.
*g1h1Pr1o1d1u1c1t1i1o1n1++g2u2a2n2.
*n1e1++t2e2m2p23.
*c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1--a2c2t2h2.
*d1i1a1z1++d2a22Hv2a2.
*d1h1p1g1+-+s2r2if.
*g1l1u1c1o1s1e1+-+p2r2l2.
*g1l1u1c1a1g1o1n1++d2a2Pr2o2d2u2c2t2i2o2n2.
*m1s1g1+--n2e22d2h2p2g2.
*c1h1r1o1n1i1Cd1i1a1z1+--g2h2Pr2o2d2u2c2t2i2o2n2.
*g1l1u1c1a1g1o1n1Di1s1+--p2Hg2h2.
*s1r1if--a2l2u2m2i2n2i2u2m2.
*g1l1u1c1o1c1o1r1t1i1c1o1i1d1--m2s2g2.
*c1h1r1o1n1i1Cd1e1x1--+g2l2u2c2a2g2o2n2.
*t1o1l1b1u1t130+-+b2r2a2i2n2Gl2u2c2o2s2e2.
*e1t1h1e1r1s1t1r1++g2e2n2t2l2e2.
*f1r1o1m1Gu1t1++i2n2s2u2l2i2n2Bo2l2i2s2.
*p1n1s1---i2n2s2u2l2i2n210.
*a1d1r1x1++t2e2m2p21.
*b1r1a1i1n1Gl1u1c1o1s1e1--d2i2a2z2.
*i1n1s1u1l1i1n1Bo1l1i1s1---h2g2h2In2j2.
*d1a1Pr1o1d1u1c1t1i1o1n1--+t2o2l2b2u2t220.
*g1u1a1n1++t2o2l2b2u2t210.
*c1h1r1o1n1i1Ci1n1s1u1l1i1n1--+t2o2Ti2s2s2u2e2.
*g1e1n1t1l1e1++i2n2s2u2l2i2n2.
*n1e1Pr1o1d1u1c1t1i1o1n1+--d2a2.
*t14++f2r2o2m2Li2v2e2r2.
*f1i1v1e1HIAA--+a2c2u2t2Ed2e2x2.
*f1r1o1m1Li1v1e1r1--n2e2Pr2o2d2u2c2t2i2o2n2.
*s1e1r1o1t1o1n1i1n1+-+c2h2r2o2n2i2Cd2e2x2.
*y1o1h1+-+s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2.
*c1h1r1o1n1i1Ct1o1l1b1u1t1++b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2.
*t1e1m1p13--+n2e2.
*i1n1s1u1l1i1n1++d2e2x2.
*h1y1p1o1x1+--n2e22Ep2i2n2.
*c1o1r1t1i1s1o1l1---c2a2t2e2c2h2o2l2e2.
*p1r1l1Re1l1e1a1s1e1--t2e2m2p22.
*s1t1r1e1s1s1--+p2n2s2.
*a1l1u1m1i1n1i1u1m1--f2r2o2m2Gu2t2.
*p1Hg1h1++c2o2r2t2i2s2o2l2.
*y2o2h2--f1r1o1m1Pa1n1c1r1e1a1s1.
*g2l2u2c2o2c2o2r2t2i2c2o2i2d2++s1w1i1m1s1t1r1.
*g2e2n2t2l2e2++g1l1u1c1a1g1o1n1Di1s1.
*a2l2u2m2i2n2i2u2m2++t1e1m1p13.
*f2r2o2m2Gu2t2+--i1n1s1u1l1i1n110.
*i2n2s2u2l2i2n210+-+s1t1r1e1s1s1.
*t2o2l2b2u2t230++s1n1s1.
*g2l2u2c2o2s2e2+-+t1w1o1Dg1.
*i2n2s2u2l2i2n2Bo2l2i2s2++n1e1Co1n1t1r1o1l1.
*f2i2v2e2HIAA--+b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1.
*c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2--+h1g1h1In1j1.
*i2n2s2u2l2i2n230--c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1.
*g2l2u2c2a2g2o2n2+--h1y1p1o1x1.
*n2e22Ep2i2n2--+t14.
*c2h2r2o2n2i2Cg2l2u2c2o2s2e2++h1g1h1.
*p2a2r2g2+-+t1o1l1b1u1t120.
*v2a2g2u2s2--i1n1s1u1l1i1n1Bo1l1i1s1.
*d2a2--+i1n1s1u1l1i1n130.
*p2r2l2++c1a1t1e1c1h1o1l1e1Di1s1p1.
*n2e2Co2n2t2r2o2l2++n1e1.
*a2c2u2t2Ed2e2x2++p1a1r1g1.
*n2e22d2h2p2g2+-+e1t1h1e1r1s1t1r1.
*h2y2p2o2x2--d1a1.
*d2h2p2g2--+f1r1o1m1Li1v1e1r1.
*d2i2a2z2++b1r1a1i1n1Gl1u1c1o1s1e1.
*a2c2t2h2Pr2o2d2u2c2t2i2o2n2++v1a1g1u1s1.
*b2r2a2i2n2Gl2u2c2o2s2e2+-+s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA.
*n2e2Pr2o2d2u2c2t2i2o2n2++t1o1l1b1u1t110.
*a2c2t2h2++s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*s2t2r2e2s2s2+--s1e1r1o1t1o1n1i1n1.
*a2d2r2x2++n1e12d1h1p1g1.
*t2e2m2p23+-+c1h1r1o1n1i1Cd1i1a1z1.
*b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2++n1e1Pr1o1d1u1c1t1i1o1n1.
*d2a22Hv2a2++c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1.
*d2a2Pr2o2d2u2c2t2i2o2n2+-+g1l1u1c1a1g1o1n1Pr1o1d1.
*f2r2o2m2Li2v2e2r2+-+p1n1s1.
*t2o2l2b2u2t210--p1Hg1h1.
*d2e2x2--g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*s2a2t2e2i2t2y2--n1e12Ep1i1n1.
*t2w2o2Dg2--+y1o1h1.
*g2l2u2c2a2g2o2n2Pr2o2d2--+a1l1u1m1i1n1i1u1m1.
*t2e2m2p22--t1o1l1b1u1t130.
*s2r2if---c1h1r1o1n1i1Ci1n1s1u1l1i1n1.
*g2h2Pr2o2d2u2c2t2i2o2n2--f1r1o1m1Gu1t1.
*c2a2t2e2c2h2o2l2e2++g1l1u1c1o1s1e1.
*g2l2u2c2a2g2o2n2Di2s2++a1c1t1h1.
*c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2---m1s1g1.
*t2e2m2p21--t1e1m1p11.
*c2h2r2o2n2i2Ci2n2s2u2l2i2n2+--g1h1Pr1o1d1u1c1t1i1o1n1.
*g2u2a2n2---s1r1if.
*c2h2r2o2n2i2Cd2i2a2z2+--a1c1u1t1Ed1e1x1.
*g2h2r2h2+-+d1a1Pr1o1d1u1c1t1i1o1n1.
*i2n2s2u2l2i2n2--a1c1t1h1Pr1o1d1u1c1t1i1o1n1.
*t24+-+g1e1n1t1l1e1.
*t2o2Ki2d2n2e2y2s2---f1i1v1e1HIAA.
*s2e2r2o2t2o2n2i2n2--c1a1t1e1c1h1o1l1e1.
*c2h2r2o2n2i2Ct2o2l2b2u2t2---c1o1r1t1i1s1o1l1.
*m2s2g2++c1h1r1o1n1i1Cd1e1x1.
*e2t2h2e2r2s2t2r2--+c1h1r1o1n1i1Ct1o1l1b1u1t1.
*s2w2i2m2s2t2r2--a1d1r1x1.
*c2o2r2t2i2s2o2l2--+t1e1m1p12.
*c2r2f2--i1n1s1u1l1i1n1.
*s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA--d1i1a1z1.
*h2g2h2+--c1r1f1.
*t2o2l2b2u2t220+--g1h1r1h1.
*c2a2t2e2c2h2o2l2e2Di2s2p2+-+c1h1r1o1n1i1Cg1l1u1c1o1s1e1.
*p2n2s2--d1a12Hv1a1.
*n2e2--p1r1l1.
*s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2+--g1l1u1c1a1g1o1n1.
*c2h2r2o2n2i2Cd2e2x2+-+t1o1Ti1s1s1u1e1.
*t2o2Ti2s2s2u2e2++s1a1t1e1i1t1y1.
*p2Hg2h2--p1r1l1Re1l1e1a1s1e1.
*s2n2s2--+d1e1x1.
*if s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1 then m2s2g2--+g2l2u2c2a2g2o2n2.
*if t1e1m1p11 then d2e2x2+--c2a2t2e2c2h2o2l2e2Di2s2p2.
*if p1Hg1h1 then p2r2l2Re2l2e2a2s2e2--s2t2r2e2s2s2.
*if g1l1u1c1o1c1o1r1t1i1c1o1i1d1 then c2h2r2o2n2i2Cd2i2a2z2--+n2e2.
*if p1a1r1g1 then h2g2h2In2j2+-+p2Hg2h2.
*if f1r1o1m1Gu1t1 then s2a2t2e2i2t2y2--n2e22Ep2i2n2.
*if n1e1Co1n1t1r1o1l1 then c2r2f2--t24.
*if f1i1v1e1HIAA then b2r2a2i2n2Gl2u2c2o2s2e2+-+t2e2m2p22.
*if i1n1s1u1l1i1n1 then s2w2i2m2s2t2r2--+b2r2a2i2n2Gl2u2c2o2s2e2Up2t2a2k2e2.
*if d1a1 then i2n2s2u2l2i2n2--g2l2u2c2o2s2e2.
*if a1c1t1h1Pr1o1d1u1c1t1i1o1n1 then p2n2s2+--i2n2s2u2l2i2n210.
*if s1e1r1o1t1o1n1i1n1TOf1i1v1e1HIAA then c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2++i2n2s2u2l2i2n2Bo2l2i2s2.
*if v1a1g1u1s1 then s2e2r2o2t2o2n2i2n2Pr2o2d2u2c2t2i2o2n2++p2a2r2g2.
*if s1e1r1o1t1o1n1i1n1 then e2t2h2e2r2s2t2r2++n2e2Pr2o2d2u2c2t2i2o2n2.
*if t1o1Ti1s1s1u1e1 then s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA--g2l2u2c2a2g2o2n2Di2s2.
*if n1e1Pr1o1d1u1c1t1i1o1n1 then p2Pr2l2+--t2o2l2b2u2t220.
*if p1Pr1l1 then v2a2g2u2s2++h2g2h2.
*if g1l1u1c1a1g1o1n1Di1s1 then n2e2Co2n2t2r2o2l2++g2h2Pr2o2d2u2c2t2i2o2n2.
*if d1a12Hv1a1 then f2i2v2e2HIAA---d2a2.
*if p1r1l1Re1l1e1a1s1e1 then y2o2h2--c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2.
*if i1n1s1u1l1i1n110 then t2o2Ti2s2s2u2e2---g2e2n2t2l2e2.
*if c1h1r1o1n1i1Cg1l1u1c1o1s1e1 then p2r2l2--f2r2o2m2Pa2n2c2r2e2a2s2.
*if a1d1r1x1 then c2h2r2o2n2i2Ct2o2l2b2u2t2--d2i2a2z2.
*if m1s1g1 then c2h2r2o2n2i2Cd2e2x2+-+t2o2l2b2u2t230.
*if c2h2r2o2n2i2Ct2o2l2b2u2t2 then d1a1---c1r1f1.
*if c2a2t2e2c2h2o2l2e2 then p1a1r1g1++c1a1t1e1c1h1o1l1e1.
*if c2h2r2o2n2i2Cd2i2a2z2 then c1a1t1e1c1h1o1l1e1Di1s1p1+--c1h1r1o1n1i1Ct1o1l1b1u1t1.
*if t2o2l2b2u2t230 then d1a12Hv1a1++n1e1Pr1o1d1u1c1t1i1o1n1.
*if f2i2v2e2HIAA then h1g1h1In1j1---i1n1s1u1l1i1n1.
*if s2t2r2e2s2s2 then t1o1l1b1u1t120++s1e1r1o1t1o1n1i1n1Pr1o1d1u1c1t1i1o1n1.
*if c2o2r2t2i2c2o2i2d2Pr2o2d2u2c2t2i2o2n2 then g1h1Pr1o1d1u1c1t1i1o1n1--+f1r1o1m1Li1v1e1r1.
*if t24 then n1e1Co1n1t1r1o1l1---g1u1a1n1.
*if p2Hg2h2 then p1n1s1--i1n1s1u1l1i1n130.
*if t2e2m2p21 then g1l1u1c1a1g1o1n1Di1s1++c1o1r1t1i1s1o1l1Pr1o1d1u1c1t1i1o1n1.
*if a2l2u2m2i2n2i2u2m2 then n1e12d1h1p1g1--d1h1p1g1.
*if c2a2t2e2c2h2o2l2e2Di2s2p2 then t1e1m1p11---v1a1g1u1s1.
*if g2h2r2h2 then m1s1g1+--i1n1s1u1l1i1n110.
*if t2o2l2b2u2t210 then c1o1r1t1i1c1o1i1d1Pr1o1d1u1c1t1i1o1n1+-+g1l1u1c1o1c1o1r1t1i1c1o1i1d1.
*if c2h2r2o2n2i2Cd2e2x2 then s1e1r1o1t1o1n1i1n1++g1l1u1c1a1g1o1n1Pr1o1d1.
*if s2e2r2o2t2o2n2i2n2TOf2i2v2e2HIAA then g1h1r1h1++s1r1if.
*if p2r2l2 then t14++c1h1r1o1n1i1Ci1n1s1u1l1i1n1.
*if a2c2t2h2 then f1r1o1m1Gu1t1++g1e1n1t1l1e1.
*if g2l2u2c2o2s2e2 then t1o1l1b1u1t110--y1o1h1.
*if c2o2r2t2i2s2o2l2Pr2o2d2u2c2t2i2o2n2 then h1y1p1o1x1+-+h1g1h1.
*if c2o2r2t2i2s2o2l2 then s1t1r1e1s1s1--d1i1a1z1.
*if i2n2s2u2l2i2n2 then a1c1t1h1+-+s1n1s1.
*if t2o2l2b2u2t220 then b1r1a1i1n1Gl1u1c1o1s1e1Up1t1a1k1e1--+c1h1r1o1n1i1Cd1i1a1z1.
*if s2e2r2o2t2o2n2i2n2 then c1h1r1o1n1i1Cg1l1u1c1o1s1e1--c1o1r1t1i1s1o1l1.
*done.
