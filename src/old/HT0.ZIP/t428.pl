*[a4c4u4t4Ed4e4x4,a4d4r4x4,c4h4r4o4n4i4Cd4e4x4
		,c4h4r4o4n4i4Cd4i4a4z4,c4h4r4o4n4i4Cg4l4u4c4o4s4e4,c4h4r4o4n4i4Ci4n4s4u4l4i4n4
		,c4h4r4o4n4i4Ct4o4l4b4u4t4,d4e4x4,d4i4a4z4
		,e4t4h4e4r4s4t4r4,g4e4n4t4l4e4,g4u4a4n4
		,h4g4h4In4j4,h4y4p4o4x4,i4n4s4u4l4i4n410
		,i4n4s4u4l4i4n430,i4n4s4u4l4i4n4Bo4l4i4s4,m4s4g4
		,p4a4r4g4,p4t4u4,s4t4r4e4s4s4
		,s4w4i4m4s4t4r4,t4o4l4b4u4t410,t4o4l4b4u4t420
		,t4o4l4b4u4t430,t4w4o4Dg4,y4o4h4
                ,a4c4t4h4,a4c4t4h4Pr4o4d4u4c4t4i4o4n4,a4l4u4m4i4n4i4u4m4,b4r4a4i4n4Gl4u4c4o4s4e4
		,b4r4a4i4n4Gl4u4c4o4s4e4Up4t4a4k4e4,c4a4t4e4c4h4o4l4e4,c4a4t4e4c4h4o4l4e4Di4s4p4
		,c4a4t4e4c4h4o4l4e4Pr4o4d4,c4o4r4t4i4c4o4i4d4Pr4o4d4u4c4t4i4o4n4,c4o4r4t4i4s4o4l4
		,c4o4r4t4i4s4o4l4Pr4o4d4u4c4t4i4o4n4,c4r4f4,d4a4
		,d4a42Hv4a4,d4a4Pr4o4d4u4c4t4i4o4n4,d4h4p4g4
		,f4i4v4e4HIAA,f4r4o4m4Gu4t4,f4r4o4m4Li4v4e4r4
		,f4r4o4m4Pa4n4c4r4e4a4s4,g4h4Pr4o4d4u4c4t4i4o4n4,g4h4r4h4
		,g4l4u4c4a4g4o4n4,g4l4u4c4a4g4o4n4Di4s4,g4l4u4c4a4g4o4n4Pr4o4d4
		,g4l4u4c4o4c4o4r4t4i4c4o4i4d4,g4l4u4c4o4s4e4,h4g4h4
		,h4v4a4,i4n4s4u4l4i4n4,n4e4
		,n4e42d4h4p4g4,n4e42Ep4i4n4,n4e4Co4n4t4r4o4l4
		,n4e4Pr4o4d4u4c4t4i4o4n4,p4Hg4h4,p4n4s4
		,p4Pr4l4,p4r4l4,p4r4l4Re4l4e4a4s4e4
		,s4a4t4e4i4t4y4,s4e4r4o4t4o4n4i4n4,s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4
		,s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA,s4n4s4,s4r4if
		,t44,t4e4m4p41,t4e4m4p42
		,t4e4m4p43,t4o4Ki4d4n4e4y4s4,t4o4Ti4s4s4u4e4
		,v4a4g4u4s4].
 

*c4r4f4  ++  a4c4t4h4Pr4o4d4u4c4t4i4o4n4.
*a4c4t4h4Pr4o4d4u4c4t4i4o4n4  +-+  a4c4t4h4.
*h4y4p4o4x4  --  a4c4t4h4Pr4o4d4u4c4t4i4o4n4.
*a4c4t4h4  ++  c4o4r4t4i4s4o4l4Pr4o4d4u4c4t4i4o4n4.
*if no g4u4a4n4 then   s4n4s4  ++  c4o4r4t4i4s4o4l4Pr4o4d4u4c4t4i4o4n4.
*if no a4d4r4x4 then c4o4r4t4i4s4o4l4Pr4o4d4u4c4t4i4o4n4  +-+  c4o4r4t4i4s4o4l4.
*c4o4r4t4i4c4o4i4d4Pr4o4d4u4c4t4i4o4n4  +--  c4o4r4t4i4s4o4l4.
*g4l4u4c4o4c4o4r4t4i4c4o4i4d4  --  a4c4t4h4Pr4o4d4u4c4t4i4o4n4.
*c4o4r4t4i4c4o4i4d4Pr4o4d4u4c4t4i4o4n4  +-+  g4l4u4c4o4c4o4r4t4i4c4o4i4d4.
*d4e4x4  ++  g4l4u4c4o4c4o4r4t4i4c4o4i4d4.
*a4c4u4t4Ed4e4x4  ++  g4l4u4c4o4c4o4r4t4i4c4o4i4d4.
*c4h4r4o4n4i4Cd4e4x4  ++  g4l4u4c4o4c4o4r4t4i4c4o4i4d4.
*if no a4d4r4x4 then c4a4t4e4c4h4o4l4e4Pr4o4d4  +-+  c4a4t4e4c4h4o4l4e4.
*c4a4t4e4c4h4o4l4e4Di4s4p4  +--  c4a4t4e4c4h4o4l4e4.
*if no g4u4a4n4 then s4n4s4  ++  c4a4t4e4c4h4o4l4e4Pr4o4d4.
*d4a4Pr4o4d4u4c4t4i4o4n4  +-+  d4a4.
*d4a42Hv4a4  +--  d4a4.
*p4r4l4  ++  d4a4.
*a4l4u4m4i4n4i4u4m4  --  d4a4Pr4o4d4u4c4t4i4o4n4.
*if no m4s4g4 then d4a42Hv4a4  +-+  h4v4a4.
*p4a4r4g4  --  d4a42Hv4a4.
*g4l4u4c4a4g4o4n4Pr4o4d4  +-+  g4l4u4c4a4g4o4n4.
*g4l4u4c4a4g4o4n4Di4s4  +--  g4l4u4c4a4g4o4n4.
*if no g4u4a4n4 then s4n4s4  ++  g4l4u4c4a4g4o4n4Pr4o4d4.
*g4l4u4c4o4s4e4  --  g4l4u4c4a4g4o4n4Pr4o4d4.
*i4n4s4u4l4i4n4  --  g4l4u4c4a4g4o4n4Pr4o4d4.
*c4h4r4o4n4i4Cg4l4u4c4o4s4e4  ++  g4l4u4c4o4s4e4.
*f4r4o4m4Gu4t4  +-+  g4l4u4c4o4s4e4.
*f4r4o4m4Li4v4e4r4  +-+  g4l4u4c4o4s4e4.
*b4r4a4i4n4Gl4u4c4o4s4e4Up4t4a4k4e4  +--  g4l4u4c4o4s4e4.
*g4l4u4c4o4s4e4  ++  b4r4a4i4n4Gl4u4c4o4s4e4Up4t4a4k4e4.
*t4o4Ti4s4s4u4e4  +--  g4l4u4c4o4s4e4.
*b4r4a4i4n4Gl4u4c4o4s4e4Up4t4a4k4e4  +-+  b4r4a4i4n4Gl4u4c4o4s4e4.
*t4e4m4p41  ++  t4o4Ti4s4s4u4e4.
*g4l4u4c4o4s4e4  ++  t4e4m4p41.
*i4n4s4u4l4i4n4  ++  t4e4m4p41.
*t4e4m4p42  ++  f4r4o4m4Li4v4e4r4.
*i4n4s4u4l4i4n4  --  t4e4m4p42.
*g4l4u4c4o4c4o4r4t4i4c4o4i4d4  ++  t4e4m4p42.
*p4n4s4  --  t4e4m4p42.
*c4a4t4e4c4h4o4l4e4  ++  t4e4m4p42.
*if no g4u4a4n4 then s4n4s4  --  t4e4m4p42.
*g4l4u4c4a4g4o4n4  ++  t4e4m4p42.
*t4w4o4Dg4  --  b4r4a4i4n4Gl4u4c4o4s4e4Up4t4a4k4e4.
*f4r4o4m4Pa4n4c4r4e4a4s4  +-+  i4n4s4u4l4i4n4.
*t4o4Ki4d4n4e4y4s4  +--  i4n4s4u4l4i4n4.
*i4n4s4u4l4i4n4  ++  t4o4Ki4d4n4e4y4s4.
*if g4u4a4n4 then  s4n4s4  --  t4e4m4p43.
*c4a4t4e4c4h4o4l4e4  --  t4e4m4p43.
*g4l4u4c4a4g4o4n4  ++  t4e4m4p43.
*g4l4u4c4o4s4e4  ++  t4e4m4p43.
*p4n4s4  ++  t4e4m4p43.
*t4e4m4p43  ++  f4r4o4m4Pa4n4c4r4e4a4s4.
*i4n4s4u4l4i4n4Bo4l4i4s4  ++  i4n4s4u4l4i4n4.
*i4n4s4u4l4i4n410  ++  i4n4s4u4l4i4n4.
*i4n4s4u4l4i4n430  ++  i4n4s4u4l4i4n4.
*c4h4r4o4n4i4Ci4n4s4u4l4i4n4  ++  i4n4s4u4l4i4n4.
*t4o4l4b4u4t410  ++  f4r4o4m4Pa4n4c4r4e4a4s4.
*t4o4l4b4u4t420  ++  f4r4o4m4Pa4n4c4r4e4a4s4.
*t4o4l4b4u4t430  ++  f4r4o4m4Pa4n4c4r4e4a4s4.
*c4h4r4o4n4i4Ct4o4l4b4u4t4  ++  f4r4o4m4Pa4n4c4r4e4a4s4.
*n4e4Pr4o4d4u4c4t4i4o4n4  +--  d4a4.
*if no m4s4g4 then n4e4Pr4o4d4u4c4t4i4o4n4  +-+  n4e4.
*n4e42d4h4p4g4  +--  n4e4.
*n4e42Ep4i4n4  +--  n4e4.
*if no m4s4g4 then   n4e42d4h4p4g4  +-+  d4h4p4g4.
*d4h4p4g4  ++  c4r4f4.
*d4h4p4g4  ++  s4n4s4.
*s4t4r4e4s4s4  ++  n4e4Co4n4t4r4o4l4.
*g4l4u4c4o4c4o4r4t4i4c4o4i4d4  --  n4e4Co4n4t4r4o4l4.
*b4r4a4i4n4Gl4u4c4o4s4e4  --  n4e4Co4n4t4r4o4l4.
*n4e4Co4n4t4r4o4l4  ++  n4e4Pr4o4d4u4c4t4i4o4n4.
*n4e4Co4n4t4r4o4l4  ++  n4e42d4h4p4g4.
*n4e4  ++  n4e42d4h4p4g4.
*a4l4u4m4i4n4i4u4m4  --  n4e42d4h4p4g4.
*n4e4  +-+  n4e42Ep4i4n4.
*h4g4h4  ++  n4e4Pr4o4d4u4c4t4i4o4n4.
*i4n4s4u4l4i4n4  --  n4e4Pr4o4d4u4c4t4i4o4n4.
*s4w4i4m4s4t4r4  ++  s4t4r4e4s4s4.
*e4t4h4e4r4s4t4r4  ++  s4t4r4e4s4s4.
*y4o4h4  ++  n4e4Pr4o4d4u4c4t4i4o4n4.
*p4a4r4g4  --  n4e42d4h4p4g4.
*g4e4n4t4l4e4  ++  s4t4r4e4s4s4.
*d4i4a4z4  --  n4e4Co4n4t4r4o4l4.
*c4h4r4o4n4i4Cd4i4a4z4  --  n4e4Co4n4t4r4o4l4.
*p4n4s4  ++  v4a4g4u4s4.
*i4n4s4u4l4i4n4  ++  p4n4s4.
*f4i4v4e4HIAA  ++  p4n4s4.
*s4n4s4  --  p4n4s4.
*d4a4  --  p4r4l4Re4l4e4a4s4e4.
*d4a4  --  p4Pr4l4.
*p4r4l4Re4l4e4a4s4e4  +--  p4Pr4l4.
*if no h4y4p4o4x4 then p4r4l4Re4l4e4a4s4e4  +-+  p4r4l4.
*f4i4v4e4HIAA  ++  s4a4t4e4i4t4y4.
*b4r4a4i4n4Gl4u4c4o4s4e4  --  s4a4t4e4i4t4y4.
*if no m4s4g4 then s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4  +-+  s4e4r4o4t4o4n4i4n4.
*s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA  +--  s4e4r4o4t4o4n4i4n4.
*s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA  +-+  f4i4v4e4HIAA.
*h4g4h4  --  s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4.
*t44  --  s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4.
*t44  ++  s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA.
*s4e4r4o4t4o4n4i4n4  ++  s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA.
*b4r4a4i4n4Gl4u4c4o4s4e4  ++  s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4.
*i4n4s4u4l4i4n4  ++  s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4.
*p4n4s4  ++  s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4.
*p4n4s4  ++  s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA.
*p4a4r4g4  --  s4e4r4o4t4o4n4i4n4TOf4i4v4e4HIAA.
*m4s4g4  --  s4e4r4o4t4o4n4i4n4Pr4o4d4u4c4t4i4o4n4.
*p4n4s4  --  s4n4s4.
*g4h4Pr4o4d4u4c4t4i4o4n4  +--  p4Hg4h4.
*if h4y4p4o4x4 then  g4h4Pr4o4d4u4c4t4i4o4n4  +-+  h4g4h4.
*h4g4h4In4j4  ++  h4g4h4.
*f4i4v4e4HIAA  ++  g4h4r4h4.
*g4h4r4h4  --  p4Hg4h4.
*g4h4r4h4  ++  g4h4Pr4o4d4u4c4t4i4o4n4.
*g4l4u4c4o4s4e4  ++  g4h4Pr4o4d4u4c4t4i4o4n4.
*g4l4u4c4o4s4e4  ++  p4Hg4h4.
*s4r4if  --  p4Hg4h4.
*s4r4if  --  g4h4Pr4o4d4u4c4t4i4o4n4.
*c4r4f4  ++  s4r4if.

*r4x4= [[], [m4s4g4], [d4i4a4z4], [g4u4a4n4], [p4a4r4g4], [h4y4p4o4x4], [t4w4o4Dg4], [a4c4u4t4Ed4e4x4],
 [g4e4n4t4l4e4],[c4h4r4o4n4i4Cd4e4x4], [s4w4i4m4s4t4r4 ], [  e4t4h4e4r4s4t4r4 ], [  p4t4u4,  y4o4h4 ], [  t4o4l4b4u4t410 ],
 [  t4o4l4b4u4t420 ], [  i4n4s4u4l4i4n410 ], [  i4n4s4u4l4i4n430 ], [  m4s4g4,  p4a4r4g4 ], [  c4h4r4o4n4i4Ct4o4l4b4u4t4 ], 
[  c4h4r4o4n4i4Cg4l4u4c4o4s4e4 ], [  c4h4r4o4n4i4Ci4n4s4u4l4i4n4 ], [  g4e4n4t4l4e4 , y4o4h4 ], [  g4u4a4n4 , t4w4o4Dg4 ],
 [p4t4u4 , s4w4i4m4s4t4r4 ], [  p4t4u4,  e4t4h4e4r4s4t4r4 ], [  d4i4a4z4,  c4h4r4o4n4i4Cd4i4a4z4 ], [  h4y4p4o4x4 , h4g4h4In4j4 ], 
[  a4c4u4t4Ed4e4x4 , s4w4i4m4s4t4r4 ], [c4h4r4o4n4i4Cd4e4x4 , s4w4i4m4s4t4r4 ], [  c4h4r4o4n4i4Cg4l4u4c4o4s4e4 , c4h4r4o4n4i4Ct4o4l4b4u4t4]].

*d4a4=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n4e4=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h4g4h4=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h4v4a4=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a4c4t4h4=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d4h4p4g4=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g4l4u4c4o4s4e4=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i4n4s4u4l4i4n4=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c4o4r4t4i4s4o4l4=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f4i4v4e4HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g4l4u4c4a4g4o4n4=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s4e4r4o4t4o4n4i4n4=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d4o4n4e4.
