:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,2,ll,200
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,3,ll,300
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,4,ll,400
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,5,ll,500
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,6,ll,600
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,7,ll,700
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,8,ll,800
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,9,ll,900
:- dynamic defined/1.
k,23:6:55,n,100,k,1,x,10,ll,1000
:- dynamic defined/1.
k,23:6:55,n,100,k,2,x,1,ll,100
