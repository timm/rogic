*[a9c9u9t9Ed9e9x9,a9d9r9x9,c9h9r9o9n9i9Cd9e9x9
		,c9h9r9o9n9i9Cd9i9a9z9,c9h9r9o9n9i9Cg9l9u9c9o9s9e9,c9h9r9o9n9i9Ci9n9s9u9l9i9n9
		,c9h9r9o9n9i9Ct9o9l9b9u9t9,d9e9x9,d9i9a9z9
		,e9t9h9e9r9s9t9r9,g9e9n9t9l9e9,g9u9a9n9
		,h9g9h9In9j9,h9y9p9o9x9,i9n9s9u9l9i9n910
		,i9n9s9u9l9i9n930,i9n9s9u9l9i9n9Bo9l9i9s9,m9s9g9
		,p9a9r9g9,p9t9u9,s9t9r9e9s9s9
		,s9w9i9m9s9t9r9,t9o9l9b9u9t910,t9o9l9b9u9t920
		,t9o9l9b9u9t930,t9w9o9Dg9,y9o9h9
                ,a9c9t9h9,a9c9t9h9Pr9o9d9u9c9t9i9o9n9,a9l9u9m9i9n9i9u9m9,b9r9a9i9n9Gl9u9c9o9s9e9
		,b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9,c9a9t9e9c9h9o9l9e9,c9a9t9e9c9h9o9l9e9Di9s9p9
		,c9a9t9e9c9h9o9l9e9Pr9o9d9,c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9,c9o9r9t9i9s9o9l9
		,c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9,c9r9f9,d9a9
		,d9a92Hv9a9,d9a9Pr9o9d9u9c9t9i9o9n9,d9h9p9g9
		,f9i9v9e9HIAA,f9r9o9m9Gu9t9,f9r9o9m9Li9v9e9r9
		,f9r9o9m9Pa9n9c9r9e9a9s9,g9h9Pr9o9d9u9c9t9i9o9n9,g9h9r9h9
		,g9l9u9c9a9g9o9n9,g9l9u9c9a9g9o9n9Di9s9,g9l9u9c9a9g9o9n9Pr9o9d9
		,g9l9u9c9o9c9o9r9t9i9c9o9i9d9,g9l9u9c9o9s9e9,h9g9h9
		,h9v9a9,i9n9s9u9l9i9n9,n9e9
		,n9e92d9h9p9g9,n9e92Ep9i9n9,n9e9Co9n9t9r9o9l9
		,n9e9Pr9o9d9u9c9t9i9o9n9,p9Hg9h9,p9n9s9
		,p9Pr9l9,p9r9l9,p9r9l9Re9l9e9a9s9e9
		,s9a9t9e9i9t9y9,s9e9r9o9t9o9n9i9n9,s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9
		,s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA,s9n9s9,s9r9if
		,t94,t9e9m9p91,t9e9m9p92
		,t9e9m9p93,t9o9Ki9d9n9e9y9s9,t9o9Ti9s9s9u9e9
		,v9a9g9u9s9].
 

*c9r9f9  ++  a9c9t9h9Pr9o9d9u9c9t9i9o9n9.
*a9c9t9h9Pr9o9d9u9c9t9i9o9n9  +-+  a9c9t9h9.
*h9y9p9o9x9  --  a9c9t9h9Pr9o9d9u9c9t9i9o9n9.
*a9c9t9h9  ++  c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9.
*if no g9u9a9n9 then   s9n9s9  ++  c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9.
*if no a9d9r9x9 then c9o9r9t9i9s9o9l9Pr9o9d9u9c9t9i9o9n9  +-+  c9o9r9t9i9s9o9l9.
*c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9  +--  c9o9r9t9i9s9o9l9.
*g9l9u9c9o9c9o9r9t9i9c9o9i9d9  --  a9c9t9h9Pr9o9d9u9c9t9i9o9n9.
*c9o9r9t9i9c9o9i9d9Pr9o9d9u9c9t9i9o9n9  +-+  g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*d9e9x9  ++  g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*a9c9u9t9Ed9e9x9  ++  g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*c9h9r9o9n9i9Cd9e9x9  ++  g9l9u9c9o9c9o9r9t9i9c9o9i9d9.
*if no a9d9r9x9 then c9a9t9e9c9h9o9l9e9Pr9o9d9  +-+  c9a9t9e9c9h9o9l9e9.
*c9a9t9e9c9h9o9l9e9Di9s9p9  +--  c9a9t9e9c9h9o9l9e9.
*if no g9u9a9n9 then s9n9s9  ++  c9a9t9e9c9h9o9l9e9Pr9o9d9.
*d9a9Pr9o9d9u9c9t9i9o9n9  +-+  d9a9.
*d9a92Hv9a9  +--  d9a9.
*p9r9l9  ++  d9a9.
*a9l9u9m9i9n9i9u9m9  --  d9a9Pr9o9d9u9c9t9i9o9n9.
*if no m9s9g9 then d9a92Hv9a9  +-+  h9v9a9.
*p9a9r9g9  --  d9a92Hv9a9.
*g9l9u9c9a9g9o9n9Pr9o9d9  +-+  g9l9u9c9a9g9o9n9.
*g9l9u9c9a9g9o9n9Di9s9  +--  g9l9u9c9a9g9o9n9.
*if no g9u9a9n9 then s9n9s9  ++  g9l9u9c9a9g9o9n9Pr9o9d9.
*g9l9u9c9o9s9e9  --  g9l9u9c9a9g9o9n9Pr9o9d9.
*i9n9s9u9l9i9n9  --  g9l9u9c9a9g9o9n9Pr9o9d9.
*c9h9r9o9n9i9Cg9l9u9c9o9s9e9  ++  g9l9u9c9o9s9e9.
*f9r9o9m9Gu9t9  +-+  g9l9u9c9o9s9e9.
*f9r9o9m9Li9v9e9r9  +-+  g9l9u9c9o9s9e9.
*b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9  +--  g9l9u9c9o9s9e9.
*g9l9u9c9o9s9e9  ++  b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9.
*t9o9Ti9s9s9u9e9  +--  g9l9u9c9o9s9e9.
*b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9  +-+  b9r9a9i9n9Gl9u9c9o9s9e9.
*t9e9m9p91  ++  t9o9Ti9s9s9u9e9.
*g9l9u9c9o9s9e9  ++  t9e9m9p91.
*i9n9s9u9l9i9n9  ++  t9e9m9p91.
*t9e9m9p92  ++  f9r9o9m9Li9v9e9r9.
*i9n9s9u9l9i9n9  --  t9e9m9p92.
*g9l9u9c9o9c9o9r9t9i9c9o9i9d9  ++  t9e9m9p92.
*p9n9s9  --  t9e9m9p92.
*c9a9t9e9c9h9o9l9e9  ++  t9e9m9p92.
*if no g9u9a9n9 then s9n9s9  --  t9e9m9p92.
*g9l9u9c9a9g9o9n9  ++  t9e9m9p92.
*t9w9o9Dg9  --  b9r9a9i9n9Gl9u9c9o9s9e9Up9t9a9k9e9.
*f9r9o9m9Pa9n9c9r9e9a9s9  +-+  i9n9s9u9l9i9n9.
*t9o9Ki9d9n9e9y9s9  +--  i9n9s9u9l9i9n9.
*i9n9s9u9l9i9n9  ++  t9o9Ki9d9n9e9y9s9.
*if g9u9a9n9 then  s9n9s9  --  t9e9m9p93.
*c9a9t9e9c9h9o9l9e9  --  t9e9m9p93.
*g9l9u9c9a9g9o9n9  ++  t9e9m9p93.
*g9l9u9c9o9s9e9  ++  t9e9m9p93.
*p9n9s9  ++  t9e9m9p93.
*t9e9m9p93  ++  f9r9o9m9Pa9n9c9r9e9a9s9.
*i9n9s9u9l9i9n9Bo9l9i9s9  ++  i9n9s9u9l9i9n9.
*i9n9s9u9l9i9n910  ++  i9n9s9u9l9i9n9.
*i9n9s9u9l9i9n930  ++  i9n9s9u9l9i9n9.
*c9h9r9o9n9i9Ci9n9s9u9l9i9n9  ++  i9n9s9u9l9i9n9.
*t9o9l9b9u9t910  ++  f9r9o9m9Pa9n9c9r9e9a9s9.
*t9o9l9b9u9t920  ++  f9r9o9m9Pa9n9c9r9e9a9s9.
*t9o9l9b9u9t930  ++  f9r9o9m9Pa9n9c9r9e9a9s9.
*c9h9r9o9n9i9Ct9o9l9b9u9t9  ++  f9r9o9m9Pa9n9c9r9e9a9s9.
*n9e9Pr9o9d9u9c9t9i9o9n9  +--  d9a9.
*if no m9s9g9 then n9e9Pr9o9d9u9c9t9i9o9n9  +-+  n9e9.
*n9e92d9h9p9g9  +--  n9e9.
*n9e92Ep9i9n9  +--  n9e9.
*if no m9s9g9 then   n9e92d9h9p9g9  +-+  d9h9p9g9.
*d9h9p9g9  ++  c9r9f9.
*d9h9p9g9  ++  s9n9s9.
*s9t9r9e9s9s9  ++  n9e9Co9n9t9r9o9l9.
*g9l9u9c9o9c9o9r9t9i9c9o9i9d9  --  n9e9Co9n9t9r9o9l9.
*b9r9a9i9n9Gl9u9c9o9s9e9  --  n9e9Co9n9t9r9o9l9.
*n9e9Co9n9t9r9o9l9  ++  n9e9Pr9o9d9u9c9t9i9o9n9.
*n9e9Co9n9t9r9o9l9  ++  n9e92d9h9p9g9.
*n9e9  ++  n9e92d9h9p9g9.
*a9l9u9m9i9n9i9u9m9  --  n9e92d9h9p9g9.
*n9e9  +-+  n9e92Ep9i9n9.
*h9g9h9  ++  n9e9Pr9o9d9u9c9t9i9o9n9.
*i9n9s9u9l9i9n9  --  n9e9Pr9o9d9u9c9t9i9o9n9.
*s9w9i9m9s9t9r9  ++  s9t9r9e9s9s9.
*e9t9h9e9r9s9t9r9  ++  s9t9r9e9s9s9.
*y9o9h9  ++  n9e9Pr9o9d9u9c9t9i9o9n9.
*p9a9r9g9  --  n9e92d9h9p9g9.
*g9e9n9t9l9e9  ++  s9t9r9e9s9s9.
*d9i9a9z9  --  n9e9Co9n9t9r9o9l9.
*c9h9r9o9n9i9Cd9i9a9z9  --  n9e9Co9n9t9r9o9l9.
*p9n9s9  ++  v9a9g9u9s9.
*i9n9s9u9l9i9n9  ++  p9n9s9.
*f9i9v9e9HIAA  ++  p9n9s9.
*s9n9s9  --  p9n9s9.
*d9a9  --  p9r9l9Re9l9e9a9s9e9.
*d9a9  --  p9Pr9l9.
*p9r9l9Re9l9e9a9s9e9  +--  p9Pr9l9.
*if no h9y9p9o9x9 then p9r9l9Re9l9e9a9s9e9  +-+  p9r9l9.
*f9i9v9e9HIAA  ++  s9a9t9e9i9t9y9.
*b9r9a9i9n9Gl9u9c9o9s9e9  --  s9a9t9e9i9t9y9.
*if no m9s9g9 then s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9  +-+  s9e9r9o9t9o9n9i9n9.
*s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA  +--  s9e9r9o9t9o9n9i9n9.
*s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA  +-+  f9i9v9e9HIAA.
*h9g9h9  --  s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*t94  --  s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*t94  ++  s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*s9e9r9o9t9o9n9i9n9  ++  s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*b9r9a9i9n9Gl9u9c9o9s9e9  ++  s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*i9n9s9u9l9i9n9  ++  s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*p9n9s9  ++  s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*p9n9s9  ++  s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*p9a9r9g9  --  s9e9r9o9t9o9n9i9n9TOf9i9v9e9HIAA.
*m9s9g9  --  s9e9r9o9t9o9n9i9n9Pr9o9d9u9c9t9i9o9n9.
*p9n9s9  --  s9n9s9.
*g9h9Pr9o9d9u9c9t9i9o9n9  +--  p9Hg9h9.
*if h9y9p9o9x9 then  g9h9Pr9o9d9u9c9t9i9o9n9  +-+  h9g9h9.
*h9g9h9In9j9  ++  h9g9h9.
*f9i9v9e9HIAA  ++  g9h9r9h9.
*g9h9r9h9  --  p9Hg9h9.
*g9h9r9h9  ++  g9h9Pr9o9d9u9c9t9i9o9n9.
*g9l9u9c9o9s9e9  ++  g9h9Pr9o9d9u9c9t9i9o9n9.
*g9l9u9c9o9s9e9  ++  p9Hg9h9.
*s9r9if  --  p9Hg9h9.
*s9r9if  --  g9h9Pr9o9d9u9c9t9i9o9n9.
*c9r9f9  ++  s9r9if.

*r9x9= [[], [m9s9g9], [d9i9a9z9], [g9u9a9n9], [p9a9r9g9], [h9y9p9o9x9], [t9w9o9Dg9], [a9c9u9t9Ed9e9x9],
 [g9e9n9t9l9e9],[c9h9r9o9n9i9Cd9e9x9], [s9w9i9m9s9t9r9 ], [  e9t9h9e9r9s9t9r9 ], [  p9t9u9,  y9o9h9 ], [  t9o9l9b9u9t910 ],
 [  t9o9l9b9u9t920 ], [  i9n9s9u9l9i9n910 ], [  i9n9s9u9l9i9n930 ], [  m9s9g9,  p9a9r9g9 ], [  c9h9r9o9n9i9Ct9o9l9b9u9t9 ], 
[  c9h9r9o9n9i9Cg9l9u9c9o9s9e9 ], [  c9h9r9o9n9i9Ci9n9s9u9l9i9n9 ], [  g9e9n9t9l9e9 , y9o9h9 ], [  g9u9a9n9 , t9w9o9Dg9 ],
 [p9t9u9 , s9w9i9m9s9t9r9 ], [  p9t9u9,  e9t9h9e9r9s9t9r9 ], [  d9i9a9z9,  c9h9r9o9n9i9Cd9i9a9z9 ], [  h9y9p9o9x9 , h9g9h9In9j9 ], 
[  a9c9u9t9Ed9e9x9 , s9w9i9m9s9t9r9 ], [c9h9r9o9n9i9Cd9e9x9 , s9w9i9m9s9t9r9 ], [  c9h9r9o9n9i9Cg9l9u9c9o9s9e9 , c9h9r9o9n9i9Ct9o9l9b9u9t9]].

*d9a9=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n9e9=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h9g9h9=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h9v9a9=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a9c9t9h9=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d9h9p9g9=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g9l9u9c9o9s9e9=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i9n9s9u9l9i9n9=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c9o9r9t9i9s9o9l9=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f9i9v9e9HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g9l9u9c9a9g9o9n9=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s9e9r9o9t9o9n9i9n9=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d9o9n9e9.
