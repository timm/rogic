*[a8c8u8t8Ed8e8x8,a8d8r8x8,c8h8r8o8n8i8Cd8e8x8
		,c8h8r8o8n8i8Cd8i8a8z8,c8h8r8o8n8i8Cg8l8u8c8o8s8e8,c8h8r8o8n8i8Ci8n8s8u8l8i8n8
		,c8h8r8o8n8i8Ct8o8l8b8u8t8,d8e8x8,d8i8a8z8
		,e8t8h8e8r8s8t8r8,g8e8n8t8l8e8,g8u8a8n8
		,h8g8h8In8j8,h8y8p8o8x8,i8n8s8u8l8i8n810
		,i8n8s8u8l8i8n830,i8n8s8u8l8i8n8Bo8l8i8s8,m8s8g8
		,p8a8r8g8,p8t8u8,s8t8r8e8s8s8
		,s8w8i8m8s8t8r8,t8o8l8b8u8t810,t8o8l8b8u8t820
		,t8o8l8b8u8t830,t8w8o8Dg8,y8o8h8
                ,a8c8t8h8,a8c8t8h8Pr8o8d8u8c8t8i8o8n8,a8l8u8m8i8n8i8u8m8,b8r8a8i8n8Gl8u8c8o8s8e8
		,b8r8a8i8n8Gl8u8c8o8s8e8Up8t8a8k8e8,c8a8t8e8c8h8o8l8e8,c8a8t8e8c8h8o8l8e8Di8s8p8
		,c8a8t8e8c8h8o8l8e8Pr8o8d8,c8o8r8t8i8c8o8i8d8Pr8o8d8u8c8t8i8o8n8,c8o8r8t8i8s8o8l8
		,c8o8r8t8i8s8o8l8Pr8o8d8u8c8t8i8o8n8,c8r8f8,d8a8
		,d8a82Hv8a8,d8a8Pr8o8d8u8c8t8i8o8n8,d8h8p8g8
		,f8i8v8e8HIAA,f8r8o8m8Gu8t8,f8r8o8m8Li8v8e8r8
		,f8r8o8m8Pa8n8c8r8e8a8s8,g8h8Pr8o8d8u8c8t8i8o8n8,g8h8r8h8
		,g8l8u8c8a8g8o8n8,g8l8u8c8a8g8o8n8Di8s8,g8l8u8c8a8g8o8n8Pr8o8d8
		,g8l8u8c8o8c8o8r8t8i8c8o8i8d8,g8l8u8c8o8s8e8,h8g8h8
		,h8v8a8,i8n8s8u8l8i8n8,n8e8
		,n8e82d8h8p8g8,n8e82Ep8i8n8,n8e8Co8n8t8r8o8l8
		,n8e8Pr8o8d8u8c8t8i8o8n8,p8Hg8h8,p8n8s8
		,p8Pr8l8,p8r8l8,p8r8l8Re8l8e8a8s8e8
		,s8a8t8e8i8t8y8,s8e8r8o8t8o8n8i8n8,s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8
		,s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA,s8n8s8,s8r8if
		,t84,t8e8m8p81,t8e8m8p82
		,t8e8m8p83,t8o8Ki8d8n8e8y8s8,t8o8Ti8s8s8u8e8
		,v8a8g8u8s8].
 

*c8r8f8  ++  a8c8t8h8Pr8o8d8u8c8t8i8o8n8.
*a8c8t8h8Pr8o8d8u8c8t8i8o8n8  +-+  a8c8t8h8.
*h8y8p8o8x8  --  a8c8t8h8Pr8o8d8u8c8t8i8o8n8.
*a8c8t8h8  ++  c8o8r8t8i8s8o8l8Pr8o8d8u8c8t8i8o8n8.
*if no g8u8a8n8 then   s8n8s8  ++  c8o8r8t8i8s8o8l8Pr8o8d8u8c8t8i8o8n8.
*if no a8d8r8x8 then c8o8r8t8i8s8o8l8Pr8o8d8u8c8t8i8o8n8  +-+  c8o8r8t8i8s8o8l8.
*c8o8r8t8i8c8o8i8d8Pr8o8d8u8c8t8i8o8n8  +--  c8o8r8t8i8s8o8l8.
*g8l8u8c8o8c8o8r8t8i8c8o8i8d8  --  a8c8t8h8Pr8o8d8u8c8t8i8o8n8.
*c8o8r8t8i8c8o8i8d8Pr8o8d8u8c8t8i8o8n8  +-+  g8l8u8c8o8c8o8r8t8i8c8o8i8d8.
*d8e8x8  ++  g8l8u8c8o8c8o8r8t8i8c8o8i8d8.
*a8c8u8t8Ed8e8x8  ++  g8l8u8c8o8c8o8r8t8i8c8o8i8d8.
*c8h8r8o8n8i8Cd8e8x8  ++  g8l8u8c8o8c8o8r8t8i8c8o8i8d8.
*if no a8d8r8x8 then c8a8t8e8c8h8o8l8e8Pr8o8d8  +-+  c8a8t8e8c8h8o8l8e8.
*c8a8t8e8c8h8o8l8e8Di8s8p8  +--  c8a8t8e8c8h8o8l8e8.
*if no g8u8a8n8 then s8n8s8  ++  c8a8t8e8c8h8o8l8e8Pr8o8d8.
*d8a8Pr8o8d8u8c8t8i8o8n8  +-+  d8a8.
*d8a82Hv8a8  +--  d8a8.
*p8r8l8  ++  d8a8.
*a8l8u8m8i8n8i8u8m8  --  d8a8Pr8o8d8u8c8t8i8o8n8.
*if no m8s8g8 then d8a82Hv8a8  +-+  h8v8a8.
*p8a8r8g8  --  d8a82Hv8a8.
*g8l8u8c8a8g8o8n8Pr8o8d8  +-+  g8l8u8c8a8g8o8n8.
*g8l8u8c8a8g8o8n8Di8s8  +--  g8l8u8c8a8g8o8n8.
*if no g8u8a8n8 then s8n8s8  ++  g8l8u8c8a8g8o8n8Pr8o8d8.
*g8l8u8c8o8s8e8  --  g8l8u8c8a8g8o8n8Pr8o8d8.
*i8n8s8u8l8i8n8  --  g8l8u8c8a8g8o8n8Pr8o8d8.
*c8h8r8o8n8i8Cg8l8u8c8o8s8e8  ++  g8l8u8c8o8s8e8.
*f8r8o8m8Gu8t8  +-+  g8l8u8c8o8s8e8.
*f8r8o8m8Li8v8e8r8  +-+  g8l8u8c8o8s8e8.
*b8r8a8i8n8Gl8u8c8o8s8e8Up8t8a8k8e8  +--  g8l8u8c8o8s8e8.
*g8l8u8c8o8s8e8  ++  b8r8a8i8n8Gl8u8c8o8s8e8Up8t8a8k8e8.
*t8o8Ti8s8s8u8e8  +--  g8l8u8c8o8s8e8.
*b8r8a8i8n8Gl8u8c8o8s8e8Up8t8a8k8e8  +-+  b8r8a8i8n8Gl8u8c8o8s8e8.
*t8e8m8p81  ++  t8o8Ti8s8s8u8e8.
*g8l8u8c8o8s8e8  ++  t8e8m8p81.
*i8n8s8u8l8i8n8  ++  t8e8m8p81.
*t8e8m8p82  ++  f8r8o8m8Li8v8e8r8.
*i8n8s8u8l8i8n8  --  t8e8m8p82.
*g8l8u8c8o8c8o8r8t8i8c8o8i8d8  ++  t8e8m8p82.
*p8n8s8  --  t8e8m8p82.
*c8a8t8e8c8h8o8l8e8  ++  t8e8m8p82.
*if no g8u8a8n8 then s8n8s8  --  t8e8m8p82.
*g8l8u8c8a8g8o8n8  ++  t8e8m8p82.
*t8w8o8Dg8  --  b8r8a8i8n8Gl8u8c8o8s8e8Up8t8a8k8e8.
*f8r8o8m8Pa8n8c8r8e8a8s8  +-+  i8n8s8u8l8i8n8.
*t8o8Ki8d8n8e8y8s8  +--  i8n8s8u8l8i8n8.
*i8n8s8u8l8i8n8  ++  t8o8Ki8d8n8e8y8s8.
*if g8u8a8n8 then  s8n8s8  --  t8e8m8p83.
*c8a8t8e8c8h8o8l8e8  --  t8e8m8p83.
*g8l8u8c8a8g8o8n8  ++  t8e8m8p83.
*g8l8u8c8o8s8e8  ++  t8e8m8p83.
*p8n8s8  ++  t8e8m8p83.
*t8e8m8p83  ++  f8r8o8m8Pa8n8c8r8e8a8s8.
*i8n8s8u8l8i8n8Bo8l8i8s8  ++  i8n8s8u8l8i8n8.
*i8n8s8u8l8i8n810  ++  i8n8s8u8l8i8n8.
*i8n8s8u8l8i8n830  ++  i8n8s8u8l8i8n8.
*c8h8r8o8n8i8Ci8n8s8u8l8i8n8  ++  i8n8s8u8l8i8n8.
*t8o8l8b8u8t810  ++  f8r8o8m8Pa8n8c8r8e8a8s8.
*t8o8l8b8u8t820  ++  f8r8o8m8Pa8n8c8r8e8a8s8.
*t8o8l8b8u8t830  ++  f8r8o8m8Pa8n8c8r8e8a8s8.
*c8h8r8o8n8i8Ct8o8l8b8u8t8  ++  f8r8o8m8Pa8n8c8r8e8a8s8.
*n8e8Pr8o8d8u8c8t8i8o8n8  +--  d8a8.
*if no m8s8g8 then n8e8Pr8o8d8u8c8t8i8o8n8  +-+  n8e8.
*n8e82d8h8p8g8  +--  n8e8.
*n8e82Ep8i8n8  +--  n8e8.
*if no m8s8g8 then   n8e82d8h8p8g8  +-+  d8h8p8g8.
*d8h8p8g8  ++  c8r8f8.
*d8h8p8g8  ++  s8n8s8.
*s8t8r8e8s8s8  ++  n8e8Co8n8t8r8o8l8.
*g8l8u8c8o8c8o8r8t8i8c8o8i8d8  --  n8e8Co8n8t8r8o8l8.
*b8r8a8i8n8Gl8u8c8o8s8e8  --  n8e8Co8n8t8r8o8l8.
*n8e8Co8n8t8r8o8l8  ++  n8e8Pr8o8d8u8c8t8i8o8n8.
*n8e8Co8n8t8r8o8l8  ++  n8e82d8h8p8g8.
*n8e8  ++  n8e82d8h8p8g8.
*a8l8u8m8i8n8i8u8m8  --  n8e82d8h8p8g8.
*n8e8  +-+  n8e82Ep8i8n8.
*h8g8h8  ++  n8e8Pr8o8d8u8c8t8i8o8n8.
*i8n8s8u8l8i8n8  --  n8e8Pr8o8d8u8c8t8i8o8n8.
*s8w8i8m8s8t8r8  ++  s8t8r8e8s8s8.
*e8t8h8e8r8s8t8r8  ++  s8t8r8e8s8s8.
*y8o8h8  ++  n8e8Pr8o8d8u8c8t8i8o8n8.
*p8a8r8g8  --  n8e82d8h8p8g8.
*g8e8n8t8l8e8  ++  s8t8r8e8s8s8.
*d8i8a8z8  --  n8e8Co8n8t8r8o8l8.
*c8h8r8o8n8i8Cd8i8a8z8  --  n8e8Co8n8t8r8o8l8.
*p8n8s8  ++  v8a8g8u8s8.
*i8n8s8u8l8i8n8  ++  p8n8s8.
*f8i8v8e8HIAA  ++  p8n8s8.
*s8n8s8  --  p8n8s8.
*d8a8  --  p8r8l8Re8l8e8a8s8e8.
*d8a8  --  p8Pr8l8.
*p8r8l8Re8l8e8a8s8e8  +--  p8Pr8l8.
*if no h8y8p8o8x8 then p8r8l8Re8l8e8a8s8e8  +-+  p8r8l8.
*f8i8v8e8HIAA  ++  s8a8t8e8i8t8y8.
*b8r8a8i8n8Gl8u8c8o8s8e8  --  s8a8t8e8i8t8y8.
*if no m8s8g8 then s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8  +-+  s8e8r8o8t8o8n8i8n8.
*s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA  +--  s8e8r8o8t8o8n8i8n8.
*s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA  +-+  f8i8v8e8HIAA.
*h8g8h8  --  s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8.
*t84  --  s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8.
*t84  ++  s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA.
*s8e8r8o8t8o8n8i8n8  ++  s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA.
*b8r8a8i8n8Gl8u8c8o8s8e8  ++  s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8.
*i8n8s8u8l8i8n8  ++  s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8.
*p8n8s8  ++  s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8.
*p8n8s8  ++  s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA.
*p8a8r8g8  --  s8e8r8o8t8o8n8i8n8TOf8i8v8e8HIAA.
*m8s8g8  --  s8e8r8o8t8o8n8i8n8Pr8o8d8u8c8t8i8o8n8.
*p8n8s8  --  s8n8s8.
*g8h8Pr8o8d8u8c8t8i8o8n8  +--  p8Hg8h8.
*if h8y8p8o8x8 then  g8h8Pr8o8d8u8c8t8i8o8n8  +-+  h8g8h8.
*h8g8h8In8j8  ++  h8g8h8.
*f8i8v8e8HIAA  ++  g8h8r8h8.
*g8h8r8h8  --  p8Hg8h8.
*g8h8r8h8  ++  g8h8Pr8o8d8u8c8t8i8o8n8.
*g8l8u8c8o8s8e8  ++  g8h8Pr8o8d8u8c8t8i8o8n8.
*g8l8u8c8o8s8e8  ++  p8Hg8h8.
*s8r8if  --  p8Hg8h8.
*s8r8if  --  g8h8Pr8o8d8u8c8t8i8o8n8.
*c8r8f8  ++  s8r8if.

*r8x8= [[], [m8s8g8], [d8i8a8z8], [g8u8a8n8], [p8a8r8g8], [h8y8p8o8x8], [t8w8o8Dg8], [a8c8u8t8Ed8e8x8],
 [g8e8n8t8l8e8],[c8h8r8o8n8i8Cd8e8x8], [s8w8i8m8s8t8r8 ], [  e8t8h8e8r8s8t8r8 ], [  p8t8u8,  y8o8h8 ], [  t8o8l8b8u8t810 ],
 [  t8o8l8b8u8t820 ], [  i8n8s8u8l8i8n810 ], [  i8n8s8u8l8i8n830 ], [  m8s8g8,  p8a8r8g8 ], [  c8h8r8o8n8i8Ct8o8l8b8u8t8 ], 
[  c8h8r8o8n8i8Cg8l8u8c8o8s8e8 ], [  c8h8r8o8n8i8Ci8n8s8u8l8i8n8 ], [  g8e8n8t8l8e8 , y8o8h8 ], [  g8u8a8n8 , t8w8o8Dg8 ],
 [p8t8u8 , s8w8i8m8s8t8r8 ], [  p8t8u8,  e8t8h8e8r8s8t8r8 ], [  d8i8a8z8,  c8h8r8o8n8i8Cd8i8a8z8 ], [  h8y8p8o8x8 , h8g8h8In8j8 ], 
[  a8c8u8t8Ed8e8x8 , s8w8i8m8s8t8r8 ], [c8h8r8o8n8i8Cd8e8x8 , s8w8i8m8s8t8r8 ], [  c8h8r8o8n8i8Cg8l8u8c8o8s8e8 , c8h8r8o8n8i8Ct8o8l8b8u8t8]].

*d8a8=[10,5,10,-,20,10,10,-,-,-,10,15,-,9,10,-,-,20,10,7,10,-,-,10,10,10,10,-,-,10].
*n8e8=[10,10,5,7,20,10,8,10,15,15,10,8,3,9,10,11,10,20,10,10,9,5,7,9,10,10,10,10,10,10].
*h8g8h8=[10,-,-,-,-,-,-,-,-,-,-,-,-,-,-,50,5,-,-,-,-,-,-,-,-,-,-,-,-,-].
*h8v8a8=[10,10,10,-,2,10,20,-,-,-,12,12,-,11,10,-,-,2,10,10,10,-,-,18,20,10,10,-,-,10].
*a8c8t8h8=[-,10,-,20,-,-,-,-,10,8,1,20,20,20,-,-,-,-,-,-,-,-,30,-,20,20,10,-,45,1].
*d8h8p8g8=[10,10,12,30,2,10,20,15,10,10,20,23,30,11,10,9,20,2,10,10,11,15,21,15,23,10,10,20,21,10].
*g8l8u8c8o8s8e8=[10,-,-,5,-,-,20,-,-,-,-,-,-,5,5,5,3,-,7,12,5,-,9,-,-,-,-,-,-,8].
*i8n8s8u8l8i8n8=[10,-,-,5,-,-,15,-,-,-,-,-,-,50,20,-,-,-,10,10,20,-,10,-,-,-,-,-,-,10].
*c8o8r8t8i8s8o8l8=[10,-,90,50,-,-,50,10,8,5,100,100,20,50,40,8,9,-,10,10,25,30,50,90,90,45,-,50,6,10].
*f8i8v8e8HIAA=[10,10,5,-,2,20,10,-,10,-,9,10,9,10,10,20,-,2,15,7,10,9,-,18,18,5,10,-,-,15].
*g8l8u8c8a8g8o8n8=[10,-,-,-,-,-,15,-,-,-,-,-,-,10,10,10,50,-,10,10,-,-,-,-,-,-,-,-,-,10].
*s8e8r8o8t8o8n8i8n8=[10,15,20,-,20,10,12,-,10,-,12,12,11,10,10,10,-,20,10,10,10,11,-,12,12,20,10,-,-,10].

*d8o8n8e8.
