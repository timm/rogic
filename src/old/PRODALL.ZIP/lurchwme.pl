%%%% Working Memory
%<
wme(Term,Key,Value) :- whatevered(Term,Key,_,Value).
%>
%<
wmeNew(w([start],[])).
wmeNew(Inits,w([start],Inits)).
wmeHas(X,w(P,L0),w(P,[X|L])) :- less1(L0,X,L).
wmeAdd(X,w(P,L), w(P,[X|L])).
wmeHolds(w(_,L),L).
%wmePush(Step,w(P,L),w([Step|P],L)).
%wmePop(Step,w([_|P],L),w(P,L)).

%step(X,W0,W) :- wmePush(
%>
%%A bounded working memory.
/*
Heres a working memory of a key-value pairs with a
 maximum
size, plus knowledge of the  maximum values seen so far.
The memory is sorted on keys so we optimize insertions.
*/
%Primitive accessors to named fields.
%<
b_(contents,A0,A, b(A0,B,C), b(A,B,C)).
b_(maxU,    B0,B, b(A,B0,C), b(A,B,C)).
b_(maxSize, C0,C, b(A,B,C0), b(A,B,C)).
%>
%Other accessors to handle common tasks.
%<
%For example- set a field;
%<
b_(X is Y) --> b_(X,_,Y).
%>
%or access a fieldl
%<
b_(X=Y)    --> b_(X,Y,Y).
%>
%or test if we are full;
%<
b_(full)    --> b_(maxSize=S),b_(contents=L),{length(L,S)}.
%>
%or initialize a new memory:
%<
b_(init(Max))-->
	b_(contents is []),
	b_(maxU is -9999999),
	b_(maxSize is Max).
%>
%or find the minumum value seen so far;
%<
b_(min(Key=Value))-->
	b_(contents=[Key=Value|_]).
%>
%or returns all the values;
%<
b_(values(L)) --> b_(contents=L0), {maplist(arg(2),L0,L)}.
%>
%<
%or run some command without changing the memory;
%<
b_(Com,X) :- b_(Com,X,X).
%>
%<
badd(U=X) --> b_(full) -> badd(full,U=X) ; badd(space,U=X).
%>
%If we are full, then after adding something, we delete the smallest item
%(which will be the head of the list):
%<
badd(full,U=X)  -->
	badd(space,U=X),
	b_(contents,[_|T],T).
%>
%If we try to add a new key=value pair to a full working memory, and
%it is less that the minimum value, we should just ignore it.
%Actually, this just happends automatically: the new minimum value will
%always be the left-most item and this is deleted after insertion by
%the above clause.
%
%If we have the space, then add in the new item and
%then update our knowledge of the maximum key seen so far.
%<
badd(space,U=X) -->
	b_(contents,Old,New),
	{koset_add(Old,U=X,New)},
	b_(maxU,Max0,Max),
	{Max is max(Max0,U)}.
%>
%<
badds(N,L,B) :- b_(init(N),_,B0),badds1(L,B0,B).
badds1([],B,B).
badds1([H|T]) --> badd(H), badds1(T).
%>
%Example predicate:
%<
egb:-
	egb(B),
	print(B),nl.

egb(B) :-
	Eg=[10=10,12=12,5=5,1=1,4=4,7=7,9=9,10=10.1,100=100,60=60],
	badds(4,Eg,B).
%>