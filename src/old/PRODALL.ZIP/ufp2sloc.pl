upf2sloc('1st generation default',320).
upf2sloc('2nd generation default',107).
upf2sloc('3rd generation default',80).
upf2sloc('4th generation default',20).
upf2sloc('5th generation default',5).
upf2sloc('aas macro',91).
upf2sloc('abap/4',16).
upf2sloc('accel',19).
upf2sloc('access',38).
upf2sloc('actor',21).
upf2sloc('acumen',28).
upf2sloc('ada 83',71).
upf2sloc('ada 95',49).
upf2sloc('adr/dl',40).
upf2sloc('adr/ideal/pdl',20).
upf2sloc('ads/batch',20).
upf2sloc('ads/online',20).
upf2sloc('ai shell default',49).
upf2sloc('ai shells',49).
upf2sloc('algol 68',107).
upf2sloc('algol w',107).
upf2sloc('ambush',32).
upf2sloc('aml',49).
upf2sloc('amppl ii',64).
upf2sloc('ansi basic',64).
upf2sloc('ansi cobol 74',107).
upf2sloc('ansi cobol 85',91).
upf2sloc('ansi sql',13).
upf2sloc('answer/db',13).
upf2sloc('apl 360/370',32).
upf2sloc('apl default',32).
upf2sloc('apl*plus',32).
upf2sloc('applesoft basic',128).
upf2sloc('application builder',20).
upf2sloc('application manager',36).
upf2sloc('aps',17).
upf2sloc('apt',71).
upf2sloc('aptools',20).
upf2sloc('arc',49).
upf2sloc('ariel',107).
upf2sloc('arity',49).
upf2sloc('arity prolog',64).
upf2sloc('art',49).
upf2sloc('art-im',46).
upf2sloc('art enterprise',46).
upf2sloc('artemis',40).
upf2sloc('as/set',19).
upf2sloc('asi/inquiry',13).
upf2sloc('ask windows',46).
upf2sloc('assembly (basic)',320).
upf2sloc('assembly (macro)',213).
upf2sloc('associative default',64).
upf2sloc('autocoder',320).
upf2sloc('awk',21).
upf2sloc('aztec c',128).
upf2sloc('balm',107).
upf2sloc('base sas',53).
upf2sloc('basic',107).
upf2sloc('basic a',128).
upf2sloc('basic assembly',320).
upf2sloc('berkeley pascal',91).
upf2sloc('better basic',91).
upf2sloc('bliss',107).
upf2sloc('bmsgen',36).
upf2sloc('boeingcalc',6).
upf2sloc('bteq',13).
upf2sloc('c',128).
upf2sloc('c set 2',91).
upf2sloc('c++',53).
upf2sloc('c86plus',128).
upf2sloc('ca-dbfast',40).
upf2sloc('ca-earl',28).
upf2sloc('cast',49).
upf2sloc('cbasic',91).
upf2sloc('cdadl',20).
upf2sloc('cellsim',46).
upf2sloc('centerline c++',53).
upf2sloc('chili',107).
upf2sloc('chill',107).
upf2sloc('cics',46).
upf2sloc('clarion',58).
upf2sloc('clascal',80).
upf2sloc('cli',32).
upf2sloc('clipper',19).
upf2sloc('clipper db',40).
upf2sloc('clos',21).
upf2sloc('clout',40).
upf2sloc('cms2',107).
upf2sloc('cmsgen',19).
upf2sloc('cobol',107).
upf2sloc('cobol ii',107).
upf2sloc('cobol/400',91).
upf2sloc('cobra',20).
upf2sloc('codecenter',36).
upf2sloc('cofac',36).
upf2sloc('cogen',36).
upf2sloc('cognos',36).
upf2sloc('cogo',71).
upf2sloc('comal',80).
upf2sloc('comit ii',64).
upf2sloc('common lisp',64).
upf2sloc('concurrent pascal',80).
upf2sloc('conniver',64).
upf2sloc('coral 66',107).
upf2sloc('corvet',19).
upf2sloc('corvision',15).
upf2sloc('cpl',160).
upf2sloc('crystal reports',20).
upf2sloc('csl',49).
upf2sloc('csp',53).
upf2sloc('cssl',46).
upf2sloc('culprit',13).
upf2sloc('cxpert',49).
upf2sloc('cygnet',19).
upf2sloc('data base default',40).
upf2sloc('dataflex',40).
upf2sloc('datatrieve',20).
upf2sloc('dbase iii',40).
upf2sloc('dbase iv',36).
upf2sloc('dcl',213).
upf2sloc('dec-rally',40).
upf2sloc('decision support default',36).
upf2sloc('delphi',29).
upf2sloc('dl/1',40).
upf2sloc('dna-4',19).
upf2sloc('dos batch files',128).
upf2sloc('dsp assembly',160).
upf2sloc('dtabl',46).
upf2sloc('dtipt',46).
upf2sloc('dyana',71).
upf2sloc('dynamo-iii',46).
upf2sloc('easel',29).
upf2sloc('easy',49).
upf2sloc('easytrieve +',13).
upf2sloc('eclipse',49).
upf2sloc('ed-scheme 3.4',53).
upf2sloc('eda/sql',12).
upf2sloc('eiffel',21).
upf2sloc('enform',46).
upf2sloc('english-based default',53).
upf2sloc('ensemble',29).
upf2sloc('epos',20).
upf2sloc('erlang',40).
upf2sloc('esf',40).
upf2sloc('espadvisor',49).
upf2sloc('espl/i',71).
upf2sloc('euclid',107).
upf2sloc('excel 1-2',6).
upf2sloc('excel 3-4',6).
upf2sloc('excel 5',6).
upf2sloc('express',36).
upf2sloc('exsys',49).
upf2sloc('extended common lisp',56).
upf2sloc('eznomad',36).
upf2sloc('facets',20).
upf2sloc('factorylink iv',29).
upf2sloc('fame',36).
upf2sloc('filemaker pro',36).
upf2sloc('flavors',29).
upf2sloc('flex',46).
upf2sloc('flexgen',29).
upf2sloc('focus',40).
upf2sloc('foil',53).
upf2sloc('forte',18).
upf2sloc('forth',64).
upf2sloc('fortran 66',128).
upf2sloc('fortran 77',107).
upf2sloc('fortran 90',80).
upf2sloc('fortran 95',71).
upf2sloc('fortran',107).
upf2sloc('fortran ii',128).
upf2sloc('foundation',29).
upf2sloc('foxpro 1',40).
upf2sloc('foxpro 2.5',34).
upf2sloc('framework',6).
upf2sloc('g2',49).
upf2sloc('gamma',16).
upf2sloc('genascript',27).
upf2sloc('gener/ol',13).
upf2sloc('genexus',15).
upf2sloc('genifer',19).
upf2sloc('geode 2.0',16).
upf2sloc('gfa basic',34).
upf2sloc('gml',46).
upf2sloc('golden common lisp',64).
upf2sloc('gpss',46).
upf2sloc('guest',28).
upf2sloc('guru',49).
upf2sloc('gw basic',98).
upf2sloc('haskell',38).
upf2sloc('high c',128).
upf2sloc('hlevel',58).
upf2sloc('hp basic',128).
upf2sloc('html 2.0',16).
upf2sloc('html 3.0',15).
upf2sloc('huron',16).
upf2sloc('ibm adf i',20).
upf2sloc('ibm adf ii',18).
upf2sloc('ibm advanced basic',98).
upf2sloc('ibm cics/vs',40).
upf2sloc('ibm compiled basic',91).
upf2sloc('ibm vs cobol',107).
upf2sloc('ibm vs cobol ii',91).
upf2sloc('ices',71).
upf2sloc('icon',80).
upf2sloc('idms',40).
upf2sloc('ief',14).
upf2sloc('iew',14).
upf2sloc('ifps/plus',32).
upf2sloc('imprs',40).
upf2sloc('informix',40).
upf2sloc('ingres',40).
upf2sloc('inquire',13).
upf2sloc('insight2',49).
upf2sloc('install/1',16).
upf2sloc('intellect',53).
upf2sloc('interlisp',58).
upf2sloc('interpreted basic',107).
upf2sloc('interpreted c',128).
upf2sloc('iqlisp',58).
upf2sloc('iqrp',13).
upf2sloc('janus',71).
upf2sloc('java',53).
upf2sloc('jcl',221).
upf2sloc('joss',107).
upf2sloc('jovial',107).
upf2sloc('kappa',40).
upf2sloc('kbms',49).
upf2sloc('kcl',64).
upf2sloc('kee',49).
upf2sloc('keyplus',40).
upf2sloc('kl',64).
upf2sloc('klo',64).
upf2sloc('knowol',49).
upf2sloc('krl',58).
upf2sloc('ksh',21).
upf2sloc('ladder logic',36).
upf2sloc('lambit/l',64).
upf2sloc('lattice c',128).
upf2sloc('liana',128).
upf2sloc('lilith',71).
upf2sloc('linc ii',14).
upf2sloc('lisp',64).
upf2sloc('loglisp',58).
upf2sloc('loops',21).
upf2sloc('lotus 123 dos',6).
upf2sloc('lotus macros',107).
upf2sloc('lucid 3d',6).
upf2sloc('lyric',53).
upf2sloc('m',16).
upf2sloc('macforth',64).
upf2sloc('mach1',40).
upf2sloc('machine language',640).
upf2sloc('macro assembly',213).
upf2sloc('maestro',16).
upf2sloc('magec',16).
upf2sloc('magik',21).
upf2sloc('make',21).
upf2sloc('mantis',40).
upf2sloc('mapper',53).
upf2sloc('mark iv',40).
upf2sloc('mark v',36).
upf2sloc('mathcad',5).
upf2sloc('mdl',36).
upf2sloc('mentor',53).
upf2sloc('mesa',107).
upf2sloc('microfocus cobol',80).
upf2sloc('microforth',64).
upf2sloc('microsoft c',128).
upf2sloc('microstep',20).
upf2sloc('miranda',40).
upf2sloc('model 204',38).
upf2sloc('modula 2',80).
upf2sloc('mosaic',6).
upf2sloc('ms c ++ v. 7',53).
upf2sloc('ms compiled basic',91).
upf2sloc('msl',64).
upf2sloc('mulisp',64).
upf2sloc('mumps',19).
upf2sloc('nastran',71).
upf2sloc('natural 1',53).
upf2sloc('natural 2',46).
upf2sloc('natural construct',25).
upf2sloc('natural language',3200).
upf2sloc('netron/cap',19).
upf2sloc('nexpert',49).
upf2sloc('nial',49).
upf2sloc('nomad2',40).
upf2sloc('non-procedural default',36).
upf2sloc('notes vip',36).
upf2sloc('nroff',53).
upf2sloc('object-oriented default',29).
upf2sloc('object assembler',64).
upf2sloc('object lisp',29).
upf2sloc('object logo',29).
upf2sloc('object pascal',29).
upf2sloc('object star',16).
upf2sloc('objective-c',27).
upf2sloc('objectview',25).
upf2sloc('ogl',80).
upf2sloc('omnis 7',40).
upf2sloc('oodl',29).
upf2sloc('ops',46).
upf2sloc('ops5',58).
upf2sloc('oracle',40).
upf2sloc('oracle developer/2000',23).
upf2sloc('oscar',107).
upf2sloc('pacbase',15).
upf2sloc('pace',40).
upf2sloc('paradox/pal',36).
upf2sloc('pascal',91).
upf2sloc('pc focus',36).
upf2sloc('pdl millenium',21).
upf2sloc('pdp-11 ade',53).
upf2sloc('perl',21).
upf2sloc('persistance object builder',21).
upf2sloc('pilot',53).
upf2sloc('pl/i',80).
upf2sloc('pl/m',71).
upf2sloc('pl/s',91).
upf2sloc('planit',53).
upf2sloc('planner',64).
upf2sloc('planperfect 1',7).
upf2sloc('plato',53).
upf2sloc('polyforth',64).
upf2sloc('pop',58).
upf2sloc('poplog',58).
upf2sloc('power basic',49).
upf2sloc('powerbuilder',16).
upf2sloc('powerhouse',14).
upf2sloc('ppl (plus)',40).
upf2sloc('pro-c',27).
upf2sloc('pro-iv',58).
upf2sloc('problem-oriented default',71).
upf2sloc('procedural default',107).
upf2sloc('professional pascal',91).
upf2sloc('program generator default',16).
upf2sloc('progress v4',36).
upf2sloc('prolog',64).
upf2sloc('prose',107).
upf2sloc('proteus',107).
upf2sloc('qbasic',58).
upf2sloc('qbe',13).
upf2sloc('qmf',15).
upf2sloc('qnial',49).
upf2sloc('quattro',6).
upf2sloc('quattro pro',6).
upf2sloc('query default',13).
upf2sloc('quick basic 1',64).
upf2sloc('quick basic 2',61).
upf2sloc('quick basic 3',58).
upf2sloc('quick c',128).
upf2sloc('quickbuild',28).
upf2sloc('quiz',15).
upf2sloc('rally',40).
upf2sloc('ramis ii',40).
upf2sloc('rapidgen',28).
upf2sloc('ratfor',91).
upf2sloc('rdb',40).
upf2sloc('realia',46).
upf2sloc('realizer 1.0',40).
upf2sloc('realizer 2.0',36).
upf2sloc('relate/3000',40).
upf2sloc('reuse default',5).
upf2sloc('rexx (mvs)',80).
upf2sloc('rexx (os/2)',46).
upf2sloc('rm basic',91).
upf2sloc('rm cobol',107).
upf2sloc('rm fortran',107).
upf2sloc('rpg i',80).
upf2sloc('rpg ii',58).
upf2sloc('rpg iii',56).
upf2sloc('rt-expert 1.4',58).
upf2sloc('s-plus',32).
upf2sloc('sail',107).
upf2sloc('sapiens',16).
upf2sloc('sas',32).
upf2sloc('savvy',13).
upf2sloc('sbasic',91).
upf2sloc('sceptre',71).
upf2sloc('scheme',53).
upf2sloc('screen painter default',6).
upf2sloc('sequal',12).
upf2sloc('shell',21).
upf2sloc('simplan',36).
upf2sloc('simscript',46).
upf2sloc('simula',46).
upf2sloc('simula 67',46).
upf2sloc('simulation default',46).
upf2sloc('smalltalk 286',21).
upf2sloc('smalltalk 80',21).
upf2sloc('smalltalk/v',21).
upf2sloc('snap',80).
upf2sloc('snobol2-4',128).
upf2sloc('softscreen',14).
upf2sloc('solo',58).
upf2sloc('speakeasy',36).
upf2sloc('spinnaker ppl',36).
upf2sloc('spreadsheet default',6).
upf2sloc('sps',320).
upf2sloc('spss',32).
upf2sloc('sql',13).
upf2sloc('sql-windows',12).
upf2sloc('statistical default',32).
upf2sloc('strategem',36).
upf2sloc('stress',71).
upf2sloc('strongly typed default',91).
upf2sloc('style',46).
upf2sloc('superbase 1.3',36).
upf2sloc('surpass',6).
upf2sloc('sybase',40).
upf2sloc('symantec c++',29).
upf2sloc('symbolang',64).
upf2sloc('synchroworks',18).
upf2sloc('synon/2e',19).
upf2sloc('system-w',36).
upf2sloc('tandem access language',91).
upf2sloc('tcl',64).
upf2sloc('telon',16).
upf2sloc('tessaract',40).
upf2sloc('the twin',6).
upf2sloc('themis',13).
upf2sloc('ti-ief',14).
upf2sloc('topspeed c ++',29).
upf2sloc('transform',15).
upf2sloc('translisp plus',56).
upf2sloc('treet',64).
upf2sloc('treetran',64).
upf2sloc('trs80 basic ii,iii',128).
upf2sloc('true basic',64).
upf2sloc('turbo c',128).
upf2sloc('turbo c++',53).
upf2sloc('turbo expert',49).
upf2sloc('turbo pascal >5',49).
upf2sloc('turbo pascal 1-4',80).
upf2sloc('turbo pascal 4-5',71).
upf2sloc('turbo prolog',80).
upf2sloc('turing',80).
upf2sloc('tutor',53).
upf2sloc('twaice',49).
upf2sloc('ucsd pascal',91).
upf2sloc('ufo/ims',36).
upf2sloc('uhelp',32).
upf2sloc('uniface',16).
upf2sloc('unix shell scripts',21).
upf2sloc('vax acms',58).
upf2sloc('vax ade',40).
upf2sloc('vectran',107).
upf2sloc('vhdl',19).
upf2sloc('visible c',49).
upf2sloc('visible cobol',40).
upf2sloc('visicalc 1',9).
upf2sloc('visual 4.0',29).
upf2sloc('visual basic 1',46).
upf2sloc('visual basic 2',43).
upf2sloc('visual basic 3',40).
upf2sloc('visual basic 4',36).
upf2sloc('visual basic 5',29).
upf2sloc('visual basic dos',40).
upf2sloc('visual c++',34).
upf2sloc('visual cobol',20).
upf2sloc('visual objects',16).
upf2sloc('visualage',21).
upf2sloc('visualgen',18).
upf2sloc('vs-rexx',32).
upf2sloc('vulcan',64).
upf2sloc('vz programmer',36).
upf2sloc('warp x',40).
upf2sloc('watcom c',128).
upf2sloc('watcom c/386',128).
upf2sloc('waterloo c',128).
upf2sloc('waterloo pascal',91).
upf2sloc('watfiv',85).
upf2sloc('watfor',91).
upf2sloc('whip',91).
upf2sloc('wizard',28).
upf2sloc('xlisp',64).
upf2sloc('yacc',53).
upf2sloc('yacc++',53).
upf2sloc('zbasic',91).
upf2sloc('zim',19).
upf2sloc('zlisp',64).
