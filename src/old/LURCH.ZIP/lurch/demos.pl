demo(1) :- 
	go(acceptance of system).