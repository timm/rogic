% operator stuff
:- op(1200, xfx, means).
:- op(999, xfx, if).
:- op(998, xfy, or).
:- op(997, xfy, and).
:- op(996, xfy, with).
:- op(995,  fy, not).
:- op(3,    fx, critical).

:- op(3,    fx, veryCritical). 
:- op(3,   xfx, says).
:- op(3,   xfx, by).


:- op(2,   xfx, of).

/*
:- op(701,  fx,      ?).
:- op(701,  fx,      !).
:- op(601,  xfx,      add).
:- op(5,  xfx,      scores).

:- op(3,    fx, initialize).
:- op(3,    fx, calculate).
:- op(1,    fx,     --).
:- op(1,    fx,     ~-).
:- op(1,    fx,     #).
:- op(1,    fx,     eq).
:- op(1,    fx,     ~+).
:- op(1,    fx,    ++).
*/
%---------------------------------------------