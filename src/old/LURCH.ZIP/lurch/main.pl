%:- load_files(

:- [ops,lib,choices,lurch,ranges,  
    arch,demos
   ].
 
:- [score].

%	[silent(true)]).

