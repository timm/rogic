% score loads files that contain the costs and benefits
% predicates


:- [combine1,costs1,benefits1].