score((,),min).
score((;),average).