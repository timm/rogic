:- load_files( [ random_util
	       , random_graph
               ], [silent(true)] ).

