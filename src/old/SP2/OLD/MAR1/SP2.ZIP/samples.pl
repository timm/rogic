sgoal(a).
tgoal(e).
