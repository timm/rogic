schema(splay).
schema(assert).
%schema(avl).
%schema(oset).

asserts(40).
retracts(20).

shasThesis :-
	asserts(A), retracts(R), 
	tell('results.dat'),
	(shasThesis1(A,R) ; true)
	told,
	!.

shasThesis1(A,R0) :-
	schema(S),
	[S],
	wmeSetup,
	wmeInit(W0),
	R is A + R0,
	generateTests(T,A,R),
	Start is cputime,
	runTests(T,W0,W),	
	Time is cputime - Start,
	print(S), write(','), print(Time),nl.
	fail.
shasThesis1(_,_).


generateTests(L,A,R) :-
	bagof(Test,A^R^generateTest(Test,A,R),L).

runTests([],W,W).
runTests([test(Command,Key,Value)|Rest],W0,W) :-
	wme(Command,Key,Value,W0,W1),
	runTests(Rest,W1,W).	

generateTest(test(Command,Key,Value),A,R,F) :-
	Random is random(100),
	(Random < A
	->	generateAssert(Command,Key,Value)
	|	(Random < R
                ->     generateRetract(Command,Key,Value)
		|      generateFind(Command,Key,Value)).

generateAssert(assert,a,1).
generateAssert(retract,a,1).
generateAssert(find,a,1).

