:-   op(50,xf,++), op(50,xf,--),    op(50,xfx,in).    

