% do any global set up required to
% use the wme
wmeSetup :-
        dynamic wme/2.
 
% empty all contents of Wmes
wmeReset(Wmes,Wmes) :-
        retractall(wme(_,_)).
 
%return a fresh wme
wmeInit(_) :- wmeReset(_,_).

wmesAssert(Key,Term, Wmes0,Wmes) :-
                                   term2Triples(Term,Triples),
                                   identity(Term,Key),
                                   oset_addels(Wmes0,Triples,Wmes).
wmesRetract(Key,Term,Wmes0,Wmes) :-
                                   oset_delel(Wmes0,Key-Term,Wmes).
wmesFind(Key,Term,Wmes,Wmes)    :-  oset_el(Key-Term,Wmes).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

oset_addels(Adds,Out) :-
	oset_addels(Adds,[],Out).

oset_addels([],Out,Out).
oset_addels([H|T],In,Out) :-
	oset_addel(In,H,Temp),
	oset_addels(T,Temp,Out).

% oset_addel(+Set, +El, -Add)  
%   ordered set element addition
% ------------------------------
oset_addel([], El, [El]). 
oset_addel([H|T], El, Add) :-
    compare(Order, H, El),
    addel(Order, H, T, El, Add).

addel(<, H, T,  El, [H|Add]) :-
    oset_addel(T, El, Add).
addel(=, H, T, _El, [H|T]). 
addel(>, H, T,  El, [El,H|T]).


% oset_delel(+Set, +el, -Del)  
%   ordered set element deletion
% ------------------------------
oset_delel([], _El, []).
oset_delel([H-Value1|T], El-Value2, Del) :-
    compare(Order, H, El),
    delel(Order, H,Value1, T, El, Value2,Del).

delel(<,  H, Value1,T,  El, Value2,[H-Value1|Del]) :-
    oset_delel(T, El-Value2, Del).
delel(=, _H, Value, T, _El, Value,T).
delel(>,  H, Value, T, _El, _Value,[H-Value|T]).

% oset
oset_el(Key1-Value1,[Key2-Value2|T]) :-
	compare(Order,Key1,Key2),
	findel(Order,Key1,Value1,Value2,T).

findel(=,_,Value,Value,_).
findel(>,Key,Value,_,T) :- oset_el(Key-Value,T).



