% do any global set up required to
% use the wme
wme(setup) :-
	dynamic wmePrimitive/2.

% empty all contents of Wmes
wme(reset,Wmes,Wmes) :-
	retractall(wmePrimitive(_,_)).

%return a fresh wme
wme(init,_) :- wmeReset(_,_).

wme(assert,Key,Value, Wmes,Wmes) :- assert(wmePrimitive(Key,Value)).
wme(retract,Key,Value,Wmes,Wmes) :- retract(wmePrimitive(Key,Value)).
wme(find,Key,Value,Wmes,Wmes)    :- wmePrimitive(Key,Value).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
