
% initialise wme for list in front.
wmesInits_Oset([]).

% to find a term in a List
wmesFind_Oset(Id,Term,W,Y) :- 
	 oset_member(W,Term,Y),
	 arg(1,Term,Id).

oset_member([],_Term,[]).
oset_member([H|T],Term,Value):-
             compare(Order,H,Term),
             extract(Order,H,T,Term,Value).

extract(<,H,T,Term,[H|Value]):-
             oset_member(T,Term,Value).
extract(=,_H,T,_Term,T).
extract(>,H,T,_Term,[H|T]).

%Extract a field from a term in alist.
wmesExtract_Oset(_Id,Field,Term,Value) :-
        o1(Term,Field,Value).


% Insert a term into a list.
wmesAssert_Oset(Id,Term,W,[Term|W]) :-
        arg(1,Term,Id).

% Delete an term from a List.
del_term([],_Term,[]).
del_term([H|T],Term,W):-
	compare(Order,H,Term),
	delete(Order,H,T,Term,W).
delete(<,H,T,Term,[H|W]):- del_Term(T,Term,W).
delete(=,_H,T,_Term,T).
delete(>,H,T,_Term,[H|T]).
