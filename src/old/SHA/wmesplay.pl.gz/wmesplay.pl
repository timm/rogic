  % do any global set up required to
% use the wme
wmeSetup :-
        dynamic wme/2.
 
% empty all contents of Wmes
wmeReset(Wmes,Wmes) :-
        retractall(wme(_,_)).
 
%return a fresh wme
wmeInit(_) :- wmeReset(_,_).

wmesAssert(Key,Value, Wmes0,Wmes) :- insert(Key-Value,Wmes0,Wmes).
wmesRetract(Key,Value,Wmes0,Wmes) :- delete(Key-Value,Wmes0,Wmes).
wmesFind(Key,Value,Wmes0,Wmes)    :- access(Key-Value,Wmes0,Wmes).

 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  access(V, Item, Tree, NewTree):-
    bst(access(V), Item, Tree, NewTree).
  insert(Item, Tree, NewTree):-
    bst(insert, Item, Tree, NewTree).
  del(Item, Tree, NewTree):-
    bst(access(true), Item, Tree, n(Item, Left,Right)),
    join(Left, Right, NewTree).
  join(Left, Right, New):-
    join(L-L, Left, Right, New).
  split(Item, Tree, Left, Right):-
    bst(access(true),Item, Tree, n(Item, Left, Right)).


  less(e(X,_V), e(Y, _V1)):- !, X < Y.
  less(X, Y):- integer(X), integer(Y), !, X < Y.


  bst(Op, Item, Tree, NewTree):-
    bst(Op, Item, L-L, Tree, R-R, NewTree).


  bst(access(Null), _Item, _L, null, _R, _Tree):- !, Null=null.
  bst(access(true), Item, Left-A, n(Item, A, B), Right-B,
      n(Item, Left, Right)).
  bst(insert, Item, Left-A, n(Item, A, B), Right-B,
      n(Item, Left, Right)).


  bst(access(Null), Item, Left-_L, n(X, null, B), Right-B,
      n(X, Left, Right)):-
    less(Item, X), !, Null=null.
  bst(Op, Item, Left, n(X, n(Item, A1, A2), B), R-n(X, NR,B),
      New):-
    less(Item, X), !,
    bst(Op, Item, Left, n(Item, A1, A2), R-NR, New).



%Zig-Zig:
  bst(Op, Item, Left, n(X, n(Y, Z, B), C),
      R-n(Y, NR, n(X, B, C)), New):-
     less(Item, X), less(Item, Y), !,
     bst(Op, Item, Left, Z, R-NR, New).
%Zig-Zag:
  bst(Op, Item, L-n(Y, A, NL), n(X, n(Y, A, Z), C),
      R-n(X, NR, C), New):-
    less(Item, X), less(Y,Item),!,
    bst(Op,Item, L-NL, Z, R-NR, New).



%Zag
  bst(access(Null), Item, Left-B, n(X, B, null), Right-_R,
      n(X, Left, Right)):-
    less(X, Item), !, Null=null.  % end of the road.
  bst(Op, Item, L-n(X, B, NL), n(X, B, n(Item, A1, A2)),
      Right, New):-
    less(X, Item), !,
    bst(Op, Item, L-NL, n(Item, A1, A2), Right, New).
%Zag-Zag
  bst(Op, Item, L-n(Y, n(X, C, B), NL), n(X, C, n(Y, B, Z)), Right, New):-
    less(X, Item), less(Y,Item),!,
    bst(Op, Item, L-NL, Z, Right, New).
%Zag-Zig
  bst(Op, Item, L-n(X, A, NL), n(X, A, n(Y, Z, C)), R-n(Y, NR, C), New):-
    less(X, Item), less(Item, Y),!,
    bst(Op, Item, L-NL, Z, R-NR, New).


  join(Left-A, n(X, A, var), Right, n(X, Left, Right)):-!.
  join(Left-n(X, A, B), n(X, A, n(Y, B, var)), Right,
       n(Y, Left, Right)):- !.
  join(Left-n(Y, n(X, C, B), NL), n(X, C, n(Y, B, n(Z, A1, A2))),
      Right, New):-
    join(Left-NL, n(Z, A1, A2), Right, New).


