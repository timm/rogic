:- [go].
emp(id,a,b,c).
wmesInits_Assert(_).
wmesAssert(Id,Term):- arg(1,Term,Id), assert(Term),print(Term),nl,fail.
wmesExtract_Assert(_Id,Field,Term,Value) :-
       % o(Term,Field,Value).
	o0(Field,Term,Value).
wmesFind_Assert(Id, Table, Term,W,W) :-   % find assert
        meta(Table,Term,_,_),
        Term,
        arg(1,Term,Id).


