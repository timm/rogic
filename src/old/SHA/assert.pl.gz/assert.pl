
:-[o].

wmesInits_Assert(_) :-  % new working memory for asserts
        meta(_,Term,_,_),
        retractall(Term),
        functor(Term,F,A),
        (dynamic F/A),
        fail.
wmesInits_Assert(_).


wmesAssert_Assert(Id,Term,W,W) :-
        arg(1,Term,Id),
        assert(Term).

wmesExtract_Assert(_Id,Field,Term,Value) :-
        %o1(Term,Field,Value).
	o(Field,Term,Value).

wmesFind_Assert(Id, Table, Term,W,W) :-   % find assert
        meta(Table,Term,_,_),
        Term,
        arg(1,Term,Id).

