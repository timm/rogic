:- [prorec,wmeoset3].

:- defRecord(emp,[id,name,dob,shoeSize]).

term2Triple(Term,ID-(Field=Value)) :-
	identity(Term,ID),
	o1(Term,Field,Value).

term2Triples(Term,Triples) :-
	bagof(Triple,Term^term2Triple(Term,Triple),Triples).

makeEmp(E) :-
	flag(id,Next,Next+1),
	create(emp,[id=Next],E).

identity(Term,Id) :-
	arg(1,Term,Id).
