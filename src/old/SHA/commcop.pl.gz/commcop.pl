shaTest(Type) :-
        retractall(b),
        retractall(c),
        retractall(c3),
        defRecord(timeControl,[
                        type=Type,
                        repeats=100,
			nTables=10, % e.g. emp,person
                        size=3, % size of each table.
			wmeSize =100, % size of wme
                        accessed=24,
                        tableName=fact]),
        create(timeControl,Control),
        shaTest1(Control),
        !.
 
shaTest1(Control) :-
        o([size==S,   nTables==NTables,
	   wmeSize==WmeSize,
           %type== Type, accessed==Percent,
           %repeats==R,
		tableName==Table],Control),
	makeNTables(NTables,S,Table,W0,Com0,W1),
	Com0,
	makeNAsserts(WmeSize,W1,Com,W2),
	printl(Com).


makeNAsserts(0,W,true,W).
makeNAsserts(N0,W0,
	[W0-wmeNewTerm(Table,Key,Term,W0,W1)-W1|Rest],
	W):-
	N0 > 0,
	randomExample(Table-Term,Key),
	N is N0 -1,
	makeNAsserts(N,W1,Rest,W).

printl([]).
printl([X|Y]) :- tab(8), print(X), nl,
	printl(Y).

printa((X,Y)) :- !, printa(X),printa(Y).
printa(X)     :- tab(8), print(X), nl.
/*
sss :- 
        assert(Type),
        wmesInits(Wme0),
        flag(id,Id,Id+1), % lok at swi prolog manual
        create(Table,id=Id,New),
        wmesAssert(Id,New,Wme0,Wme1),
        Get is integer(S * (Percent/100)),
        shaTest2(R,Get,Table,Names,Wme1,_Wme).
*/

makeNTables(0,_,_,W,true,W).
makeNTables(N0,S,Table0,W,
	(defRecord(Table,[id|Fields]),Rest),W) :-
	N0 > 0,
	gensym(Table0,Table),
        randomFields(S,Fields,_),
	N is N0 - 1,
	makeNTables(N,S,Table0,W,Rest,W).

randomFields(0,[],[]).
randomFields(N0,[F=N0|Fields],[F|Names]) :-
        gensym(field,F),
        N0 > 0,
        N is N0 - 1,
        randomFields(N,Fields,Names).
 
examples(All) :-
	bagof(Table-Eg,example(Table,Eg),All).

randomExample(Table-Eg,Id) :-
	examples(All),
	random_members(All,1,[Table-Eg]),
	arg(1,Eg,Id),
	flag(id,Id,Id+1),
	Eg =.. [Table,Id|Rest],
	randomContents(Rest).

randomContents([]).
randomContents([1|T]) :- randomContents(T).

% generate random def records)

command_item(Item) :-
	X is random(1),
	command_item(X,Item).

command_item(0,W0-wmesAssert(Key,Term,W0,W)-W) :-
	% get a random eg
	randomExample(_-Term,Key).
command_item(1,W0-wmesFind(Id,Table,X,W0,W)-W) :-
	randomExample(Table-X,Id).
%command_item(2,W0-wmeRetract(Id,Table)-W).


random_members(List,N,Members) :-
        length(List,Max),
        random_numbers(N,Max,Numbers),
        random_members1(Numbers,1,List,Members).
 
random_members1([],_,_,[]).
random_members1([N|Rest],N,[H|T],[H|Others]) :- !,
        N1 is N + 1,
        random_members1(Rest,N1,T,Others).
random_members1([H|Rest],N,[_|T],Out) :-
        N1 is N + 1,
        random_members1([H|Rest],N1,T,Out).
 
random_numbers(N,Max,S) :-
        set_new(S0),
        random_numbers(N,Max,S0,S).
 
random_numbers(0,_,S,S) :- !.
random_numbers(N,Max,S0,S) :-
        Random is random(Max) + 1,
        (set_newel(S0,Random,S1)
        ->      N1 is N - 1,
                random_numbers(N1,Max,S1,S)
        ;       random_numbers(N,Max,S0,S)).
 
set_new([]).
 
 
 
%----- set add new element
% fails if new element already in set.
set_newel([], El, [El]).
set_newel([H|T], El, Add) :-
        compare(Order, H, El), newel(Order, H, T, El, Add).
 
newel(<, H, T,  El, [H|Add]) :- set_newel(T, El, Add).
%newel(=, H, T, _El, [H|T]).
newel(>, H, T,  El, [El,H|T]).

