%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% extract from a term the required field
wmesExtractB(Id,Field,Term,Value) :-
        arg(1,Term,Id),wmesExtracts(Field,Term,Value).
%        o(Field==Value,Term). % use o1 instead!!

wmesExtractC(Id,Field,Term,Value) :-
         arg(1,Term,Id), wmesExtracts(Field,Term,Value).
%        o(Field==Value,Term).
 
wmesExtractC3(Id,Field,Term,Value) :-
         isTriple(Id), wmesExtracts(Field,Term,Value).
%        triple(Id,Field,Value).
 
wmesExtracts([],_Term,[]).
wmesExtracts([Field|Fields],Term,[Value|Values]) :-
        wmesExtract(Field,Term,Value),
        wmesExtracts(Fields,Term,Values).
wmesExtract([],_Term,[]).
wmesExtract([H|T],Term,Value):-
             compare(Order,H,Term),
             extract(Order,H,T,Term,Value).
extract(<,H,T,Term,[H|Value]):-
             wmesExtract(T,Term,Value).
extract(=,_H,T,_Term,T).
extract(>,H,T,_Term,[H|T]).
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

