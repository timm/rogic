/*\documentclass[twocolumn,global]{svjour}
\usepackage{prod}\begin{document}

\theprogram{_NAME} 
\thetocdepth{_DEPTH} % e.g. 2
\thewp{_PATHNAME}
\theref{_REF_FILE}
\thetitle{_TITLE}
\theauthor{_AUTHOR1\inst{1},_AUTHOR2\inst{2}}
\theinstitute{_WHERE_AUTHOR1_WORKS;\\
          \url{author1@email1.com},
          \url{http://where.to.find.author1}
             \and
             _WHERE_AUTHOR2_WORKS}
\thereference{_REFERENCE \url{_DOWNLOAD_SITE}}
\theacknowledgement{_ACKNOWLEDGEMENTS}}
\theabstract{_ONE_PARAGRAPH_SUMMARY}
*/

/*
_BODY_OF_DOCUMENT
*/

/*
\theend
\end{document}
*/
