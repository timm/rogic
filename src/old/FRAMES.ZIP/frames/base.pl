:- ensure_loaded(lib).
:- ops([xfx/(:-)
       ,fx/(<>)
       ,xfy/(,)
       ,xfx/(o)
       ,fx/(o)
       ,xfx/if
       ,xfy/and
       ,xfy/rany
       ,xfy/with
       ,xfx/(=)
       ,xfx/(:=)
       ,xfx/(has)
       ,xfx/[in,at]
       ]).

