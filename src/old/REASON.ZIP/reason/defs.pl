/*

=head1 Accessor

Been at this one for years.

=head1 Header

=head2 Operators */

 :- op(800, xfy, with).
 :- op(700, xfx,  :=).
 :- op(1,   fx,  in).
 :- op(1,   fx,  the).
 :- op(1,   fx,  our). /*

=head2 Flags */

 :- dynamic       def/2.
 :- discontiguous def/2.
 :- multifile     def/2.  /*

=head1 Body 

=head2 Error Handler */

 illegal(T,F) :- 
	aboutTerm(T,GT,PT),
	aboutTerm(F,GF,PF),
	\+ legal(GT,GF,T,F),
	write('% E> '), 
        illegal1('badness in "~w" of "~w"\n',[PF,PT]).

 illegal1(Err,Args) :-
	source_location(Path,Line),
	file_base_name(Path,File),
	format('~w, line ~w: ',[File,Line]),
	format(Err,Args),!.
 illegal1(Err,Args) :- 
	format(Err,Args).

 aboutTerm(X,0,(?)) :- var(X).
 aboutTerm(X,1,X) :- nonvar(X).

 legal(0,0,_,_).
 legal(0,1,_,_).
 legal(1,0,T,_) :- def(T,_).
 legal(1,1,T,the F) :- def(T,Fs), member(F,Fs).
 legal(0,1,_,our X) :- meta(X).
 legal(1,1,_,our X) :- meta(X). /*

=head2 Interpreter */

 meta(fields).

 at(our fields,_,Fields,This=In,This=In) :- 
	\+ illegal(This,our fields), 
	def(This,Fields).
 at(the Field,Old,New,This=In,This=Out) :-
	\+ illegal(This,the Field),
	def(This,Fields),
	at1(Fields,Field,Old,New,In,Out).

 at1([Field|_],Field,Old,New,[Old|Rest],[New|Rest]).
 at1([_|Fields],Field,Old,New,[H|T0],[H|T1]) :-
	at1(Fields,Field,Old,New,T0,T1). 

 in(This,This=L,This=L) :-
	\+ illegal(This,_),
	def(This,Fs), length(Fs,N), length(L,N).

 at(X)   :- at(X,_,_).
 at(X,Y) :- at(X,_,Y).

 at(F/V0/V)   --> at(F,V0,V). 
 at(F := V)   --> at(F/_/V).
 at(F=V)      --> at(F/V/V). 
 at(F is N)   --> at(F/_/V),   {V is N}.
 at(F+N)      --> at(F/V0/V),  {V is V0+N}.
 at(+F)       --> at(F/V0/V),  {V is V0+1}.
 at(-F)       --> at(F/V0/V),  {V is V0-1}.
 at(F >= V)   --> at(F/V1/V1), {V1 >= V}.
 at(F >  V)   --> at(F/V1/V1), {V1 >  V}.
 at(F <  V)   --> at(F/V1/V1), {V1 <  V}.
 at(F =< V)   --> at(F/V1/V1), {V1 =< V}.
 at(F \= V)   --> at(F/V1/V1), {V1 \= V}.
 at(X with Y) --> at(X),at(Y).
 at(in X)     --> in(X).  