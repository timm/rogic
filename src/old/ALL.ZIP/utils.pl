inside(X,X)     :- atomic(X),!.
inside(X,X)     :- var(X),!.
inside([H|T],X) :- !,member(Y,[H|T]), inside(Y,X).
inside(Term,X) :-
	arg(_,Term,Arg),
	inside(Arg,X).

runiv(Term0, Swaps,Term) :-
        Term0 =..L0,
        once(maplist(runiv1(Swaps), L0, L)),
	Term =.. L.

runiv1(_,H,H)  :- var(H).
runiv1(Swaps,Old,New)  :- atomic(Old), member(Old/New,Swaps),!.
runiv1(_,H,H) :- atomic(H).
runiv1(Swaps,H0,H) :- runiv(H0,Swaps,H).

sum([H|T],X) :- sum(T,H,X).
sum([],   X,  X).
sum([H|T],X,Out) :- Temp is H + X, sum(T,Temp,Out).

sumof(X,Y,Z) :- bagof(X,Y,Temp), sum(Temp,Z).

