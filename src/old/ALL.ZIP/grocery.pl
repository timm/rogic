%%%%%%%%%%%%
def(grocery,g,[name is ''            of string
              ,type is bag(plastic)  of [bag(plastic) 
                                        ,jar
                                        ,box(cardboard)
                                        ,bottle(cardboard) 
                                        ,bottle
                                        ] 
              ,size is small         of [small
                                        ,medium
                                        ,large
                                        ]
              ,frozen is n           of [y
                                        ,n
                                        ]
             ]).

g volume(V) --> g volumes(Vs), g size = S,  S/V in Vs.

g volumes([small/1, medium/2, large/3]) --> [].

%%%%%%%%%%%%
def(bagger,b,[todo is [] of is_list
             ,bags is [] of is_list]).

b test1 --> todo is [bread, glop, granola
                     ,granola,iceCream,potatoChips].


def(bag,bag,[items is []]).

bag volume(V) --> sumof(V,W0^W^bag(volume1(V),W0,W),V).
bag item(I)  -->   bag item in I.
bag volume1(V) --> bag item(I), {g(volume(V),I,_)}.
 
