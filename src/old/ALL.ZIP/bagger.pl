{X} :- load_files(X,[silent(true)]).

%%%%%%%%%%%%%%%%%%%%%
:- op(998,xfx,in).   
:- op(701,xfy,of).
:- discontiguous touch/3,def/3.    
:- {utils},{pansion}.

:-
        format('~s\n\n',["Welcome to BAGGER (Version 0.1);
Copyright (c) 2001 Tim Menzies (tim@menzies.com).
Copy policy: GPL-2 (see www.gnu.org)
Remember, chips need Pepsi. "]).

