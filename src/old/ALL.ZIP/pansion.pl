% every box gets the following tools
% '#S' is the accessor atom
% '#F' is the functor of the bag
% '#I' is the intialization list

'#S'(new)      --> '#S'('#I').
'#S'(X is A)   --> '#F'(X,_,A,_).
'#S'(reset(X)) --> '#F'(X,_,A,A).
'#S'(X=A)      --> '#F'(X,A,A,_).
'#S'(X ^ A ^ B)--> '#F'(X,A,B,_).
'#S'(+ X)      --> '#F'(X,Y,Z,_), {Z is Y + 1}.
'#S'(- X)      --> '#F'(X,Y,Z,_), {Z is Y - 1}.
'#S'(X * Y)    --> '#F'(X,Old,Z,_), {Z is Old * Y}.
'#S'(X + Y)    --> '#F'(X,Old,Z,_), {Z is Old + Y}.
'#S'(X / Y)    --> '#F'(X,Old,Z,_), {Z is Old / Y}.
'#S'(X - Y)    --> '#F'(X,Old,Z,_), {Z is Old - Y}.
'#S'(X >= Y)   --> '#F'(X,Z,Z,_), {Z >= Y}.
'#S'(X >  Y)   --> '#F'(X,Z,Z,_), {Z >  Y}.
'#S'(X <  Y)   --> '#F'(X,Z,Z,_), {Z <  Y}.
'#S'(X =< Y)   --> '#F'(X,Z,Z,_), {Z =< Y}.
'#S'(X << H)   --> '#F'(X,T,[H|T],_).
'#S'(X >> H)   --> '#F'(X,[H|T],T,_).
'#S'(X in V)   --> '#F'(X,A,A,_), member(V,A).
'#S'([])       --> [].
'#S'([H|T])    --> '#S'(H), '#S'(T).
'#S'(show)     --> nl, 
    '#S'(numbervars), 
    '#S'(X=Y),
    format('~12P = ~w\n',[X,Y]),
    fail.
'#S'(show)     --> [].
'#S'(numbervars,W,W) :- numbervars(W,0,_).
'#S'(W0/W,W0,W).
'#S'(w(W),W,W).
'#S'(copy(Y),X,X) :- copy_term(X,Y).
'#S'(bad(X)) --> '#F'(X,A,A,_), \+ '#S'(ok(X,A)).
'#S'(oks) --> \+ '#S'(bad(_)).
'#R'(ok('#X'))    --> '#F'('#X',A,A,_), {range('#Type',A)}.
'#R'(ok('#X',Value)) --> {range('#Type',Value)}.

term_expansion(def(F,A,L),[def(F,A,L)|Out]) :- 
    defWme(def(F,A,L),Out).

defWme(def(F,A,L),Out) :-
	length(L,Arity),
	bagof(One,F^A^L^Arity^defWme1(F,A,Arity,L,One),Out).

defWme1(Functor,_,Arity,Fields,X) :-
	nth1(N,Fields,Name is Default of _),
	functor(In, Functor,Arity),
	functor(Out,Functor,Arity),
	joinArgs(N,Old,New,In,Out),
	X =.. [Functor,Name,Old,New
              ,Default,In,Out].
defWme1(Functor,_,Arity,_,
       (portray(X) :- nonvar(X),X=Y,
                      write(sack(Functor)))) :-
	functor(Y,Functor,Arity).
defWme1(_,A,_,_,(:- discontiguous A/3)).
defWme1(_,A,_,_,(:- op(999,fx,A))).
% optimiser stuff
defWme1(Functor,Access,Arity,_, (touch(Wme0,Action,Wme1):- X)):-
	functor(Wme0, Functor,Arity),
	X    =.. [Access,Action,Wme0,Wme1].
defWme1(Functor,Access,_,_, (goal_expansion(Goal,X):-nonvar(A))):-	
	Goal =.. [Access,A = B,In,Out],
        X    =.. [Functor,A,B,B,_,In,Out].
defWme1(Functor,Access,_,_, (goal_expansion(Goal,X):-nonvar(A))):-	
	Goal =.. [Access,A ^ B ^ C,In,Out],
        X    =.. [Functor,A,B,C,_,In,Out].
defWme1(Functor,Access,_,_,  (goal_expansion(Goal,X):-nonvar(A))):-
        Goal =.. [Access,A is B,In,Out],
        X    =.. [Functor,A,_,B,_,In,Out].
defWme1(Functor,Access,_,Fields,Out) :-
        maplist(arg(1),Fields,Inits),
	clause('#S'(A,B,C),D),
	runiv(('#S'(A,B,C) :- D),
                ['#F'/Functor
                ,'#I'/Inits
                ,'#S'/Access
                ],Out).
defWme1(Functor,Access,_,Fields,Out) :-
        member(Field is _ of Range,Fields),
	rangeType(Range,Type),
	clause('#R'(A,B,C),D),
        runiv(('#R'(A,B,C) :- D),
                ['#R'/Access
                ,'#X'/Field
                ,'#Type'/Type
                ,'#F'/Functor
                ],Out).

rangeType(X,X) :- atom(X). 

rangeType([X],eq(X)) :- atom(X).
rangeType([X - Y],between(X,Y)).
rangeType([X,Y|Z],member([X,Y|Z])).

/*too clever!
rangeType(list of Y, list of Y).
range(F           ,C) :-     
	functor(C,F,A), 
	def(F,_,Fields), 
	length(Fields,A),
        touch(C,oks,_).
range(list of Y,      Cs) :-  member(C,Cs), range(Y,C).
*/

range(eq(C)       ,C).
range(between(A,B),C) :- A =< C, C >= B.
range(member(L)   ,C) :- member(C,L).
range(string      ,C) :- atom(C).
range(number      ,C) :- numeric(C).
range(atom        ,C) :- atomic(C).

	
joinArgs(N,Old,New,T1,T2) :-
    T1 =.. [_|L0],
    T2 =.. [_|L],
    joinArgs(1,N,L0,Old,New,L).
joinArgs(N,N,[Old|Rest],Old,New,[New|Rest]).
joinArgs(N0,N1,[X|L0],Old,New,[X|L]) :-
    N0 < N1,
    N2 is N0 + 1,
    joinArgs(N2,N1,L0,Old,New,L).

goal_expansion(=(X,Y,W,W),X=Y).
goal_expansion(in(X,L,W,W),member(X,L)).
goal_expansion(say(X,A,A),print(X)).
goal_expansion(sayln(X,A,A),(print(X),nl)).
goal_expansion(nl(X,X),nl).
goal_expansion(format(A,B,C,C),format(A,B)).
goal_expansion(fail(X,X),fail).
goal_expansion(bagof(X,Y,Z,W,W),bagof(X,Y,Z)).
goal_expansion(sumof(X,Y,Z,W,W),sumof(X,Y,Z)).



