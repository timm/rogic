%name = '6. x-shape with strings (1 of 3 inexplicable)'.

ll <- aa.
bb <- ll.                       
nn <- mm.
bb <- nn.                            
cc <- bb.
dd <- cc.
ee <- dd.                          
vv <- bb. 
gg <- ff.
hh <- gg.
ii <- bb.
jj <- ii.
kk <- jj.

[rx= [[mm], [aa]]
,ee = [10,  15]
,hh = [10,  15]
,kk = [10,   5]
].