cc <- aa.
cc <- bb.

[rx= [[aa],   [bb]]
,cc= [  10,    10 ]
].