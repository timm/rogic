% simplest
b <- a.

[rx   = [[], [a]]
,b    = [0,  1]
].