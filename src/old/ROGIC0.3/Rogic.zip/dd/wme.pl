wme=[time   := 1
    ,id
    ,route  :=[1=[]]
    ].

wme+reset       --> o time := 1, o route :=[1=[]].
wme+prove(G,Id) --> o reset, o id := Id, o G.

wme+proveSteady(O) -->
	{aoIndex(val,O,X),
	clause(o(X,wme, 1,_,_),o(hop(_,  Up),_,_)),
	clause(o(X,wme,-1,_,_),o(hop(_,Down),_,_))},
	o assert(val of O = 0) o Up o Down.

wme+assert(G) -->
	o hop(G,true).
wme+hop(G,Then) -->
	o time=T,
	o id=Id,
	o now(Now),
	o assume(G,T,Id,Id1),
	({Id1 < Id} 
	->   o push(G)
	;    {\+ member(G,Now)},
	     o push(G),
	     o Then).

wme+push(G) -->  
	o route was [T=Now|Then] now [T=[G|Now]|Then].
wme+now(Now) -->
	o time=T
	o route was R now [T=Now|R1],
	{less1(R,T=Now,R1)}. 
wme+assume(A of O = NewV,T,_,Id1) -->
	{a(A,O,T,Id1,OldV),
	!, 
	OldV=NewV}.
wme+assume(A of O = V,T,Id,Id) -->  
	{assert(a(A,O,T,Id,V))}.
wme+assume(A of O  = V,T,Id,_) --> 
	{retract(a(A,O,T,Id,V))}, 	
	fail.

wme+plus(1,1).
wme+plus(-1,-1).
wme+minus(1,-1).
wme+minus(-1,1).
