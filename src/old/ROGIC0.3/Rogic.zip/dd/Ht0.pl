ht0=[runs        := 10
    ,runtime
    ,i 
    ,nGoals      := 0
    ,maxProved   := 0
    ,goals
    ,nProved     := 0
    ,wme
    ].
   
ht0+ht0 -->
	o runtime is cputime,
	o runs = R,
	o scenario(Ins,Goals),
	o zaps(Ins),
	o ht0(R,Goals),
	o runtime = Time,
	o runtime is cputime - Time,
	o sort(goals),
	o show.
ht0+zaps(Ins) -->
	{retractall(in(_,_,_))},
	o zap(Ins,_).
ht0*zap(A of O = V) -->
	{assert(in(A,O,V))}.
ht0+ht0(Runs,G0)=Max--> 
	o i := Runs,
	o prep(G0,G),
	o goals := G,
	o run,
	o maxProved=Max.
ht0+scenario(In,Goals) -->
	o scenarios(S),
	{getScenario(S,In,Goals)}.
ht0*prep(AOV) = Out --> 
	o +nGoals so N,
	{o new(goal) o id := N o aov := AOV o as Out}.
	
ht0+run   --> o i=0,!.
ht0+run   --> o notes, o reset, o proves, o -i, o run.
ht0+reset --> {retractall(a(_,_,_,_,_))}, o nProved := 0.
ht0+notes --> 
	o nProved=NProved,
	o nGoals=All,
	New is NProved/All,
	o maxProved=Old,
	{compare(Change,New,Old)
	,print(Change),write(' '),flush_output(user)},
	o update(Change,New).
ht0+update(>,New) -->
	o maxProved is New,
	{retractall(best(_)),
	 forall(a(A,B,C,D,E),
	        assert(best(A,B,C,D,E)))}. 
ht0+update(= , _).
ht0+update(<,_).
ht0+update(>,New) -->
	o maxProved is New,
	{retractall(best(_)),
	 forall(a(A,B,C,D,E),
	assert(best(A,B,C,D,E)))}.
ht0+proves -->
	o sort(goals) so G0,
	{o new(wme) o as Wme},
	o wme := Wme, 
	o prove(G0,G),
	o goals := G.

ht0*prove(G0)=G -->
	{o as G0 o id=Id o aov=AOV},
	o wme keep prove(AOV,Id)
	-> o wme ask route=R,
	   {o as G0 o yeah o route := R o as G},
	   o +nProved
	;  {o as G0 o boo o route := [] o as G}.
	