goal=[weight := 0,id,aov,proved,route].
	
goal+yeah   --> o proved := t, o incw.
goal+boo    --> o proved := f, o decw.
goal+inc(X) --> X is 1 + random(10^4)/10^6.
goal+incw   --> o inc(X), o weight + X.
goal+decw   --> o inc(X), o weight - X.