:- op(1,fx,d).

d 0   :- run(t000).
d 1   :- run(t001).
d std :- run(std1).
d 4   :- run(t4no).
d 6   :- run(t6twox).
d 7   :- run(t7twoins).
d 9   :- run(t9loops).
d 10  :- run('10bath').
d 16  :- run('16sym').

