:- op(1004, xfx,   if).
:- op(950,fx,if).
:- op(90,fy,no).
:- op(800,xfx,then).
:- op(1005,  fx,    *). 
:- op(1002, xfy,   or).
:- op(1001, xfy,  and). 
:- op(1001, xfx,   ::).
:- op(999,  xfy,  ror).
:- op(998,  xfy, rand).
:- op(750,  xfx, ++).
:- op(750,  xfx, -+).
