:- t(loading(usualStuff)).

%control stuff
*thrashes  is 1.   %1
*fiddles   is 1.   %1
*forgets   is 100. %100
*watch     is t.   %t
*trust     is t.   %t
*even      is t.
*model     is unnamed.

%type
* uds = [-1,0,1].
* bool= [-1,1].

