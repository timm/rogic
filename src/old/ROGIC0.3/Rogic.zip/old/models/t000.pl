:- [usual].

* model is 'simplest
#1: 1-[b=1]'.

%vars
* bool : a,b.

%rules
*b + a.

%obs
*rx   = [[], [a]]
,
[b    = [0,  1]
].

*end.


